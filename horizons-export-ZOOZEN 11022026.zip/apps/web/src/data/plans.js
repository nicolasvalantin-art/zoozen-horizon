export const plansData = [
  {
    id: 'basique',
    name: 'Basique',
    price: 'Gratuit',
    period: null,
    description: 'Parfait pour un animal',
    features: [
      '1 profil d\'animal',
      'Jusqu\'à 2 photos',
      'Médaille QR',
      'Notifications de scan basiques',
      'Masquage du numéro de téléphone'
    ],
    cta: 'Activer le plan gratuit'
  },
  {
    id: 'standard',
    name: 'Standard',
    price: '4.99€',
    period: 'mois',
    description: 'Idéal pour plusieurs animaux',
    features: [
      'Jusqu\'à 3 profils d\'animaux',
      'Jusqu\'à 5 photos par animal',
      'Médailles QR',
      'Notifications de scan prioritaires',
      'Masquage du numéro de téléphone',
      'Notifications par e-mail'
    ],
    cta: 'S\'abonner'
  },
  {
    id: 'premium',
    name: 'Premium',
    price: '9.99€',
    period: 'mois',
    description: 'La protection ultime',
    features: [
      'Profils d\'animaux illimités',
      'Jusqu\'à 5 photos par animal',
      'Médailles QR',
      'Notifications de scan en temps réel',
      'Masquage du numéro de téléphone',
      'Notifications par e-mail',
      'Support prioritaire'
    ],
    cta: 'S\'abonner'
  }
];