import React, { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { Send, MapPin, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import pb from '@/lib/pocketbaseClient';
import { toast } from 'sonner';

export default function LocationShareModal({ isOpen, onClose, petName }) {
  const { collarId } = useParams();
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [loadingGps, setLoadingGps] = useState(false);
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  const fetchAndSendLocation = useCallback(() => {
    setLat(null);
    setLng(null);
    setErrorMsg(null);
    setSent(false);
    setLoadingGps(true);
    setSending(false);

    if (!navigator.geolocation) {
      setErrorMsg("La géolocalisation n'est pas supportée par votre navigateur.");
      setLoadingGps(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        setLat(latitude);
        setLng(longitude);
        setLoadingGps(false);

        setSending(true);
        try {
          // Direct PocketBase record creation instead of broken email API
          await pb.collection('pet_found_notifications').create({
            petId: collarId,
            latitude: latitude,
            longitude: longitude,
            timestamp: new Date().toISOString(),
            address: "Position partagée via le bouton de localisation rapide"
          }, { $autoCancel: false });

          setSent(true);
          toast.success('Localisation envoyée avec succès');
        } catch (error) {
          console.error('Failed to send location automatically:', error);
          setErrorMsg(error.message || "Échec de l'envoi de la position.");
          toast.error("Impossible d'informer le propriétaire.");
        } finally {
          setSending(false);
        }
      },
      (error) => {
        console.error("GPS Error:", error);
        let msg = "Impossible d'obtenir votre position.";
        if (error.code === 1) msg = "Vous avez refusé l'accès à la position GPS.";
        else if (error.code === 2) msg = "Position GPS indisponible.";
        else if (error.code === 3) msg = "Délai d'attente dépassé.";
        
        setErrorMsg(msg);
        setLoadingGps(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }, [collarId]);

  useEffect(() => {
    if (isOpen) {
      fetchAndSendLocation();
    }
  }, [isOpen, fetchAndSendLocation]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            <MapPin className="w-5 h-5 text-primary" />
            Partage de position
          </DialogTitle>
          <DialogDescription className="text-slate-500">
            Nous tentons de localiser votre appareil pour envoyer la position exacte au propriétaire.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          <div className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
            {(loadingGps || sending) ? (
              <div className="h-[250px] flex flex-col items-center justify-center text-slate-500 p-6 text-center">
                <Loader2 className="w-10 h-10 animate-spin mb-4 text-primary" />
                <p className="text-base font-medium text-slate-700">
                  {loadingGps ? "Recherche de votre position GPS..." : "Envoi de la position au propriétaire..."}
                </p>
                {loadingGps && (
                  <p className="text-sm mt-2 text-slate-500">
                    Veuillez autoriser l'accès à la localisation si demandé par votre navigateur.
                  </p>
                )}
              </div>
            ) : errorMsg ? (
              <div className="h-[250px] flex flex-col items-center justify-center text-destructive p-6 text-center bg-destructive/5">
                <AlertCircle className="w-10 h-10 mb-4" />
                <p className="text-base font-medium">{errorMsg}</p>
              </div>
            ) : sent && lat && lng ? (
              <div className="relative h-[250px] w-full flex flex-col">
                <div className="bg-emerald-50 text-emerald-700 p-3 text-sm font-semibold text-center border-b border-emerald-100 flex items-center justify-center gap-2 z-10">
                  <Send className="w-4 h-4" />
                  Localisation envoyée avec succès
                </div>
                <div className="flex-1 w-full relative">
                  <iframe 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    src={`https://maps.google.com/maps?q=${lat},${lng}&z=15&output=embed`} 
                    allowFullScreen
                    title="Carte de localisation"
                    className="absolute inset-0"
                  />
                </div>
              </div>
            ) : null}
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button type="button" variant="outline" onClick={onClose} className="w-full sm:w-auto">
            Fermer
          </Button>
          {errorMsg && (
            <Button onClick={fetchAndSendLocation} className="w-full sm:w-auto">
              Réessayer
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}