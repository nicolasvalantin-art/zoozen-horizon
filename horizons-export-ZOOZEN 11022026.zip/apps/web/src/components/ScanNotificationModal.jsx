import React, { useState, useRef, useEffect } from 'react';
import { Send, Mail, Phone, MapPin, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import pb from '@/lib/pocketbaseClient';
import { toast } from 'sonner';

export default function ScanNotificationModal({ isOpen, onClose, petId, petName, initialLat = null, initialLng = null }) {
  const [loading, setLoading] = useState(false);
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoError, setGeoError] = useState(null);
  const [lat, setLat] = useState(initialLat);
  const [lng, setLng] = useState(initialLng);
  
  const emailInputRef = useRef(null);
  const phoneInputRef = useRef(null);
  const messageInputRef = useRef(null);

  useEffect(() => {
    if (isOpen && initialLat === null && initialLng === null) {
      setGeoLoading(true);
      setGeoError(null);
      
      if (!navigator.geolocation) {
        setGeoError("La géolocalisation n'est pas supportée par votre navigateur.");
        setGeoLoading(false);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLat(position.coords.latitude);
          setLng(position.coords.longitude);
          setGeoLoading(false);
        },
        (error) => {
          console.warn("Geolocation error in modal:", error);
          let msg = "Impossible d'obtenir votre position.";
          if (error.code === 1) msg = "Accès à la position refusé.";
          else if (error.code === 2) msg = "Position indisponible.";
          else if (error.code === 3) msg = "Délai d'attente dépassé.";
          setGeoError(msg);
          setGeoLoading(false);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else if (isOpen) {
      setLat(initialLat);
      setLng(initialLng);
    }
  }, [isOpen, initialLat, initialLng]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (lat === null || lng === null) {
      toast.error("Impossible d'envoyer la notification sans coordonnées GPS.");
      return;
    }

    const email = emailInputRef.current?.value || '';
    const phone = phoneInputRef.current?.value || '';
    const message = messageInputRef.current?.value || '';

    if (!email.trim() && !phone.trim()) {
      toast.error('Veuillez fournir un email ou un numéro de téléphone');
      return;
    }

    if (!message.trim()) {
      toast.error('Veuillez entrer un message');
      return;
    }

    setLoading(true);
    try {
      await pb.collection('pet_found_notifications').create({
        petId: petId,
        latitude: lat,
        longitude: lng,
        address: `Contact: ${email || phone} - Message: ${message}`,
        timestamp: new Date().toISOString()
      }, { $autoCancel: false });

      toast.success('Notification envoyée au propriétaire avec votre position');
      
      if (emailInputRef.current) emailInputRef.current.value = '';
      if (phoneInputRef.current) phoneInputRef.current.value = '';
      if (messageInputRef.current) messageInputRef.current.value = '';
      
      onClose();
    } catch (error) {
      console.error('Failed to send notification:', error);
      toast.error("Échec de l'envoi de la notification. Veuillez réessayer.");
    } finally {
      setLoading(false);
    }
  };

  const isSubmitDisabled = loading || geoLoading || lat === null || lng === null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-xl">J'ai trouvé {petName}</DialogTitle>
          <DialogDescription className="text-slate-500">
            Envoyez un message au propriétaire. Votre position GPS sera jointe pour l'aider à retrouver son animal.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mb-2">
          {geoLoading ? (
            <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 p-3 rounded-lg">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Acquisition de votre position GPS...</span>
            </div>
          ) : geoError ? (
            <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{geoError}</span>
            </div>
          ) : lat && lng ? (
            <div className="flex items-center gap-2 text-sm text-emerald-700 bg-emerald-50 p-3 rounded-lg">
              <MapPin className="w-4 h-4 shrink-0" />
              <span>Position acquise : {lat.toFixed(4)}, {lng.toFixed(4)}</span>
            </div>
          ) : null}
        </div>

        <form onSubmit={handleSubmit}>
          <div className="space-y-5 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-700 font-semibold">Votre email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    id="email"
                    type="email"
                    ref={emailInputRef}
                    placeholder="jean@exemple.com"
                    className="pl-9"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="phone" className="text-slate-700 font-semibold">Votre téléphone</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <Input
                    id="phone"
                    type="tel"
                    ref={phoneInputRef}
                    placeholder="06 12 34 56 78"
                    className="pl-9"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="message" className="text-slate-700 font-semibold">
                Votre message <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="message"
                ref={messageInputRef}
                placeholder="Bonjour, j'ai trouvé votre animal près du parc. Il va bien et est en sécurité..."
                rows={4}
                className="resize-none"
                required
              />
            </div>
          </div>
          <DialogFooter className="gap-2 sm:gap-0 mt-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={loading} className="w-full sm:w-auto">
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitDisabled} className="w-full sm:w-auto">
              {loading ? (
                'Envoi...'
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer la notification
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}