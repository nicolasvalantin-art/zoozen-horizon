import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { toast } from 'sonner';

export default function ProtectedRoute({ children, requireAdmin = false }) {
  const { isAuthenticated, initialLoading, currentUser } = useAuth();

  useEffect(() => {
    // Show error toast if user is authenticated but lacks admin privileges
    if (!initialLoading && isAuthenticated && requireAdmin && currentUser?.role !== 'admin') {
      toast.error("Accès refusé. Vous n'avez pas les permissions d'administrateur.");
    }
  }, [initialLoading, isAuthenticated, requireAdmin, currentUser]);

  if (initialLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (requireAdmin && currentUser?.role !== 'admin') {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
}