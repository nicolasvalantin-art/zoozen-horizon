import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PhoneOff, Phone } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import PlanFeatureList from '@/components/PlanFeatureList.jsx';

export default function PlanCard({ plan, isRecommended, currentPlan, renderCheckout }) {
  const [phoneVisibility, setPhoneVisibility] = useState('visible');
  const isCurrentPlan = currentPlan === plan.id;

  return (
    <Card className={`relative flex flex-col h-full transition-all duration-300 ${
      isRecommended 
        ? 'border-primary shadow-lg lg:scale-105 z-10 bg-card' 
        : 'bg-muted/30 border-transparent shadow-sm hover:shadow-md'
    }`}>
      {isRecommended && (
        <div className="absolute -top-4 left-0 right-0 flex justify-center">
          <Badge className="bg-primary text-primary-foreground text-xs font-bold px-3 py-1 uppercase tracking-wider">
            Recommandé
          </Badge>
        </div>
      )}

      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
        <div className="mt-4 flex items-baseline justify-center text-4xl font-extrabold" style={{ letterSpacing: '-0.02em' }}>
          {plan.price}
          {plan.period && <span className="text-xl text-muted-foreground font-medium ml-1">/{plan.period}</span>}
        </div>
        <CardDescription className="mt-2">{plan.description}</CardDescription>
      </CardHeader>

      <CardContent className="flex-grow space-y-6">
        <PlanFeatureList features={plan.features} />

        <div className="p-4 bg-background border rounded-xl flex items-start space-x-4">
          <div className="mt-0.5 shrink-0">
            {phoneVisibility === 'visible' ? (
              <Phone className="w-5 h-5 text-muted-foreground" />
            ) : (
              <PhoneOff className="w-5 h-5 text-muted-foreground" />
            )}
          </div>
          <div className="flex-grow space-y-1">
            <div className="flex items-center justify-between">
              <Label htmlFor={`visibility-${plan.id}`} className="text-sm font-semibold cursor-pointer">
                Numéro public
              </Label>
              <Switch
                id={`visibility-${plan.id}`}
                checked={phoneVisibility === 'visible'}
                onCheckedChange={(checked) => setPhoneVisibility(checked ? 'visible' : 'hidden')}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              {phoneVisibility === 'visible' 
                ? 'Votre numéro sera visible lors du scan.' 
                : 'Votre numéro sera masqué aux personnes scannant la médaille.'}
            </p>
          </div>
        </div>
      </CardContent>

      <CardFooter className="mt-auto pt-6">
        {isCurrentPlan ? (
          <div className="w-full text-center py-2 px-4 bg-muted text-muted-foreground rounded-md font-medium text-sm">
            Forfait actuel
          </div>
        ) : (
          renderCheckout(phoneVisibility)
        )}
      </CardFooter>
    </Card>
  );
}