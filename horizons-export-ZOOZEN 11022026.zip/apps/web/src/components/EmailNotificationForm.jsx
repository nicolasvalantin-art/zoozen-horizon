import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import { Loader2, Bell } from 'lucide-react';
import pb from '@/lib/pocketbaseClient.js';

export default function EmailNotificationForm() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
      toast.error('Veuillez entrer une adresse email valide.');
      return;
    }

    setIsLoading(true);
    try {
      await pb.collection('maintenance_notifications').create({ 
        email 
      }, { 
        $autoCancel: false 
      });
      
      toast.success("Merci ! Nous vous préviendrons dès notre retour.");
      setEmail('');
    } catch (err) {
      console.error('Erreur lors de l\'inscription:', err);
      toast.error('Une erreur est survenue. Vous êtes peut-être déjà inscrit(e).');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex w-full max-w-md flex-col sm:flex-row gap-3 mt-6">
      <div className="relative flex-grow">
        <Input
          type="email"
          placeholder="Votre adresse email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          aria-label="Adresse email pour la notification"
          className="h-12 w-full bg-white/10 border-white/20 text-white placeholder:text-white/50 focus-visible:ring-white/30 transition-all duration-300 rounded-xl"
        />
      </div>
      <Button 
        type="submit" 
        disabled={isLoading} 
        className="h-12 px-6 rounded-xl bg-white text-slate-900 hover:bg-slate-100 hover:scale-[1.02] active:scale-[0.98] transition-all duration-300 shrink-0 font-medium"
      >
        {isLoading ? (
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
        ) : (
          <Bell className="w-4 h-4 mr-2" />
        )}
        Être notifié
      </Button>
    </form>
  );
}