import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Mail } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-muted text-muted-foreground border-t">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center space-x-2 mb-4 group inline-flex">
              <img 
                src="https://horizons-cdn.hostinger.com/47c25bd4-6f6e-46b5-8c91-5800b9b716a9/0c58e232f26ae518431a1a749df261ae.png" 
                alt="Zoozen Paw Logo" 
                className="h-10 w-10 object-contain transition-transform duration-200 group-hover:scale-105"
              />
              <span className="font-bold text-xl text-foreground group-hover:text-primary transition-colors duration-200">
                Zoozen
              </span>
            </Link>
            <p className="text-sm leading-relaxed max-w-md">
              Protégez vos animaux avec des médailles QR intelligentes. Recevez des notifications instantanées lorsque votre animal est retrouvé, partout dans le monde.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <span className="font-semibold text-foreground block mb-4">Liens rapides</span>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="hover:text-primary transition-colors duration-200">
                  Accueil
                </Link>
              </li>
              <li>
                <Link to="/plans" className="hover:text-primary transition-colors duration-200">
                  Tarifs
                </Link>
              </li>
              <li>
                <Link to="/dashboard" className="hover:text-primary transition-colors duration-200">
                  Tableau de bord
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-primary transition-colors duration-200">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <span className="font-semibold text-foreground block mb-4">Légal</span>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/privacy-policy" className="hover:text-primary transition-colors duration-200">
                  Politique de confidentialité
                </Link>
              </li>
              <li>
                <Link to="/terms-of-service" className="hover:text-primary transition-colors duration-200">
                  Conditions d'utilisation
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-border flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p className="text-sm">
            © 2026 Zoozen. Tous droits réservés.
          </p>
          <div className="flex items-center space-x-4">
            <a href="#" className="hover:text-primary transition-colors duration-200" aria-label="Facebook">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="#" className="hover:text-primary transition-colors duration-200" aria-label="Twitter">
              <Twitter className="w-5 h-5" />
            </a>
            <a href="#" className="hover:text-primary transition-colors duration-200" aria-label="Instagram">
              <Instagram className="w-5 h-5" />
            </a>
            <Link to="/contact" className="hover:text-primary transition-colors duration-200" aria-label="Contact">
              <Mail className="w-5 h-5" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}