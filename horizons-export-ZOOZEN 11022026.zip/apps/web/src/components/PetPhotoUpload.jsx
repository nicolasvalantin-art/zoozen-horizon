import React, { useState } from 'react';
import { Upload, X, Image as ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/AuthContext.jsx';

export default function PetPhotoUpload({ photos, onChange, maxPhotos = 2 }) {
  const { currentUser } = useAuth();
  const [previews, setPreviews] = useState([]);
  const [dragActive, setDragActive] = useState(false);

  // Determine max photos based on subscription
  const effectiveMaxPhotos = currentUser?.subscription_plan === 'premium' ? 5 : maxPhotos;

  const handleFiles = (files) => {
    const validFiles = Array.from(files).filter(file => {
      if (!file.type.startsWith('image/')) {
        return false;
      }
      if (file.size > 20 * 1024 * 1024) { // 20MB max
        return false;
      }
      return true;
    });

    const remainingSlots = effectiveMaxPhotos - (photos?.length || 0);
    const filesToAdd = validFiles.slice(0, remainingSlots);

    // Create previews
    const newPreviews = filesToAdd.map(file => ({
      file,
      url: URL.createObjectURL(file)
    }));

    setPreviews([...previews, ...newPreviews]);
    onChange([...(photos || []), ...filesToAdd]);
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleFiles(e.target.files);
    }
  };

  const removePhoto = (index) => {
    const newPreviews = previews.filter((_, i) => i !== index);
    const newPhotos = photos.filter((_, i) => i !== index);
    setPreviews(newPreviews);
    onChange(newPhotos);
  };

  const canAddMore = (photos?.length || 0) < effectiveMaxPhotos;

  return (
    <div className="space-y-4">
      {/* Upload Area */}
      {canAddMore && (
        <div
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
            dragActive 
              ? 'border-primary bg-primary/5' 
              : 'border-border hover:border-primary/50'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            type="file"
            id="photo-upload"
            className="hidden"
            accept="image/*"
            multiple
            onChange={handleChange}
          />
          <label htmlFor="photo-upload" className="cursor-pointer">
            <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
            <p className="font-medium mb-1">Drop photos here or click to upload</p>
            <p className="text-sm text-muted-foreground">
              Max {effectiveMaxPhotos} photos, up to 20MB each
            </p>
            {currentUser?.subscription_plan === 'basique' && (
              <p className="text-xs text-muted-foreground mt-2">
                Upgrade to Premium for up to 5 photos
              </p>
            )}
          </label>
        </div>
      )}

      {/* Photo Previews */}
      {previews.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {previews.map((preview, index) => (
            <div key={index} className="relative aspect-square rounded-xl overflow-hidden bg-muted group">
              <img 
                src={preview.url} 
                alt={`Preview ${index + 1}`}
                className="w-full h-full object-cover"
              />
              <Button
                type="button"
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200"
                onClick={() => removePhoto(index)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}

      {!canAddMore && (
        <p className="text-sm text-muted-foreground text-center">
          Maximum number of photos reached
        </p>
      )}
    </div>
  );
}