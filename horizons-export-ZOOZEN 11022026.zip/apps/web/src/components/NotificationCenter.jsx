import React, { useState, useEffect, useRef } from 'react';
import { Bell, MapPin, MessageSquare, Dog } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';

export default function NotificationCenter() {
  const { currentUser } = useAuth();
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const fetchRef = useRef(false);

  useEffect(() => {
    if (!currentUser) return;
    
    // Prevent duplicate fetching in strict mode
    if (fetchRef.current) return;
    fetchRef.current = true;

    const fetchScans = async () => {
      try {
        setLoading(true);
        // Optimize: Single query avoiding N+1 loops, relying on pocketbase relation filters
        const scanRecords = await pb.collection('scans').getList(1, 20, {
          filter: `pet_id.owner_id = "${currentUser.id}"`,
          sort: '-created',
          expand: 'pet_id',
          $autoCancel: false
        });
        
        setScans(scanRecords.items);
      } catch (error) {
        if (error.status !== 404) {
          console.error('Failed to fetch scans for notification center:', error);
        }
      } finally {
        setLoading(false);
      }
    };

    fetchScans();
  }, [currentUser]);

  const getPetPhotoUrl = (pet) => {
    if (pet?.photos?.length > 0) {
      // Use the correct PocketBase file URL method: pb.files.getURL (uppercase URL)
      return pb.files.getURL(pet, pet.photos[0], { thumb: '100x100' });
    }
    return null;
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bell className="w-5 h-5 mr-2" />
            Activité récente des scans
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-start gap-4">
              <Skeleton className="w-10 h-10 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Bell className="w-5 h-5 mr-2" />
          Activité récente des scans
        </CardTitle>
      </CardHeader>
      <CardContent>
        {scans.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
            <p className="text-muted-foreground">Aucun scan pour le moment</p>
            <p className="text-sm text-muted-foreground mt-1">
              Les scans apparaîtront ici quand quelqu'un trouvera votre animal
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {scans.map((scan) => (
              <div key={scan.id} className="border-b border-border/50 pb-4 last:border-0 last:pb-0">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-10 h-10 border border-border">
                      <AvatarImage src={getPetPhotoUrl(scan.expand?.pet_id)} />
                      <AvatarFallback className="bg-muted">
                        <Dog className="w-5 h-5 text-muted-foreground" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium">
                        {scan.expand?.pet_id?.name || 'Animal inconnu'} a été scanné
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(scan.created).toLocaleString('fr-FR', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </p>
                    </div>
                  </div>
                </div>
                
                {scan.scanner_location && (
                  <div className="flex items-start text-sm text-muted-foreground mt-2 ml-13 pl-[52px]">
                    <MapPin className="w-4 h-4 mr-1 flex-shrink-0 mt-0.5" />
                    <span>{scan.scanner_location}</span>
                  </div>
                )}
                
                {scan.message && (
                  <div className="mt-3 ml-13 pl-[52px]">
                    <div className="bg-muted p-3 rounded-lg flex items-start text-sm text-foreground">
                      <MessageSquare className="w-4 h-4 mr-2 flex-shrink-0 mt-0.5 text-primary" />
                      <p>{scan.message}</p>
                    </div>
                  </div>
                )}
                
                {scan.scanner_contact && (
                  <div className="mt-2 ml-13 pl-[52px]">
                    <p className="text-sm text-muted-foreground bg-muted/50 inline-block px-2 py-1 rounded">
                      Contact : {scan.scanner_contact}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}