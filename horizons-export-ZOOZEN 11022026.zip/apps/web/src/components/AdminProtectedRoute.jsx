import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAdminAuth } from '@/contexts/AdminAuthContext.jsx';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminProtectedRoute({ children }) {
  const { isAdminAuthenticated, loading } = useAdminAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-slate-50 flex flex-col items-center justify-center space-y-4">
        <Skeleton className="h-12 w-12 rounded-full" />
        <p className="text-slate-500 font-medium">Vérification des accès administrateur...</p>
      </div>
    );
  }

  if (!isAdminAuthenticated) {
    // Redirect to login but save the attempted URL for potential post-login redirect
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  return children;
}