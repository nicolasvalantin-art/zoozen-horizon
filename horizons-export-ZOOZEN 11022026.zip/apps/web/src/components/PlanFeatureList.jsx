import React from 'react';
import { Check } from 'lucide-react';

export default function PlanFeatureList({ features }) {
  return (
    <ul className="space-y-3">
      {features.map((feature, idx) => (
        <li key={idx} className="flex items-start text-sm">
          <Check className="w-5 h-5 text-primary mr-3 shrink-0" />
          <span className="text-muted-foreground">{feature}</span>
        </li>
      ))}
    </ul>
  );
}