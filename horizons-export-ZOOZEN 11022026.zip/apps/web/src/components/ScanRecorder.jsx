import { useEffect, useRef } from 'react';
import pb from '@/lib/pocketbaseClient';

export default function ScanRecorder({ collarId }) {
  const recorded = useRef(false);

  useEffect(() => {
    if (!collarId || recorded.current) return;
    
    const recordScan = async () => {
      try {
        recorded.current = true;
        
        // 1. Find the badge
        const badge = await pb.collection('badges').getFirstListItem(`badge_code="${collarId}"`, {
          $autoCancel: false
        });
        
        if (!badge || !badge.pet_id) return;

        // 2. Get location if available
        let latitude = 0;
        let longitude = 0;
        
        if ('geolocation' in navigator) {
          try {
            const position = await new Promise((resolve, reject) => {
              navigator.geolocation.getCurrentPosition(resolve, reject, { timeout: 5000 });
            });
            latitude = position.coords.latitude;
            longitude = position.coords.longitude;
          } catch (geoErr) {
            console.log('Geolocation not available or denied');
          }
        }

        // 3. Record scan in PocketBase
        await pb.collection('scans').create({
          pet_id: badge.pet_id,
          badge_id: badge.id,
          latitude,
          longitude,
          device_type: navigator.userAgent,
          browser: navigator.vendor
        }, { $autoCancel: false });

        // Note: Removed redundant apiServerClient.fetch POST to /pets/{id}/scan
        
      } catch (error) {
        console.error('Failed to record scan:', error);
      }
    };

    recordScan();
  }, [collarId]);

  return null;
}