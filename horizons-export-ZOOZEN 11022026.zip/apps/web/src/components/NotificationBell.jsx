import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';

export default function NotificationBell() {
  const { currentUser } = useAuth();
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [recentScans, setRecentScans] = useState([]);
  const fetchRef = useRef(false);

  useEffect(() => {
    if (!currentUser) return;
    
    // CRITICAL FIX: Disable API calls entirely on preview or public scan pages.
    // Preview pages must be 100% READ-ONLY and completely isolated from unnecessary state updates or fetches.
    // This prevents any accidental 404s, unauthorized fetches, or unwanted mutations.
    const isRestrictedPage = location.pathname.includes('/preview') || location.pathname.includes('/scan/');
    if (isRestrictedPage) {
      console.log('NotificationBell: Fetch aborted. Running in restricted/preview route.');
      return;
    }

    // Deduplication guard
    if (fetchRef.current) return;
    fetchRef.current = true;

    const fetchRecentScans = async () => {
      try {
        // Optimized single query using dot-notation relation filter
        const scans = await pb.collection('scans').getList(1, 5, {
          filter: `pet_id.owner_id = "${currentUser.id}"`,
          sort: '-created',
          expand: 'pet_id',
          $autoCancel: false
        });

        setRecentScans(scans.items);
        setUnreadCount(scans.items.length);
      } catch (error) {
        // Suppress 404 logs for empty relations
        if (error.status !== 404) {
          console.error('Failed to fetch recent scans:', error);
        }
      } finally {
        // Reset ref after a short delay to allow subsequent fetches if needed (e.g. navigation back)
        setTimeout(() => {
          fetchRef.current = false;
        }, 2000);
      }
    };

    fetchRecentScans();
  }, [currentUser, location.pathname]);

  if (!currentUser) return null;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-5 h-5" />
          {unreadCount > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 text-xs"
            >
              {unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <h3 className="font-semibold">Scans récents</h3>
          {recentScans.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucun scan récent</p>
          ) : (
            <div className="space-y-3">
              {recentScans.map((scan) => (
                <div key={scan.id} className="text-sm border-b pb-3 last:border-0">
                  <p className="font-medium">
                    {scan.expand?.pet_id?.name || 'Animal inconnu'} a été scanné
                  </p>
                  <p className="text-muted-foreground text-xs mt-1">
                    {new Date(scan.created).toLocaleString('fr-FR')}
                  </p>
                  {scan.scanner_location && (
                    <p className="text-muted-foreground text-xs mt-1">
                      Lieu: {scan.scanner_location}
                    </p>
                  )}
                  {scan.message && (
                    <p className="text-sm mt-2 bg-muted p-2 rounded-md">
                      {scan.message}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}