import React from 'react';
import { Link } from 'react-router-dom';
import { Edit, Eye, Trash2, Dog, Cat, Bird, Rabbit, Phone, User as UserIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import pb from '@/lib/pocketbaseClient';
import { maskPhoneNumber } from '@/utils/PhoneNumberMasker.js';

const petIcons = {
  dog: Dog,
  cat: Cat,
  bird: Bird,
  rabbit: Rabbit,
  other: Dog
};

const petTypeTranslations = {
  dog: 'Chien',
  cat: 'Chat',
  rabbit: 'Lapin',
  bird: 'Oiseau',
  other: 'Autre'
};

export default function PetCard({ pet, onDelete }) {
  const Icon = petIcons[pet.type] || Dog;
  
  // Use the correct PocketBase file URL method: pb.files.getURL (uppercase URL)
  const photoUrl = pet.photos && pet.photos.length > 0 
    ? pb.files.getURL(pet, pet.photos[0], { thumb: '300x300' })
    : null;

  // Default to visible if privacy setting is not explicitly 'hidden'
  const isPhoneVisible = pet.expand?.owner_id?.phone_visibility !== 'hidden';
  const displayPhone = pet.phone_number 
    ? (isPhoneVisible ? pet.phone_number : maskPhoneNumber(pet.phone_number))
    : null;

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-200 flex flex-col h-full">
      <div className="aspect-square bg-muted relative">
        {photoUrl ? (
          <img 
            src={photoUrl} 
            alt={pet.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Icon className="w-24 h-24 text-muted-foreground/30" />
          </div>
        )}
        <Badge className="absolute top-3 right-3 bg-background/90 text-foreground">
          {petTypeTranslations[pet.type] || pet.type}
        </Badge>
      </div>
      
      <CardContent className="p-4 flex-1">
        <h3 className="font-semibold text-lg mb-1">{pet.name}</h3>
        {pet.breed && (
          <p className="text-sm text-muted-foreground mb-4">{pet.breed}</p>
        )}
        
        <div className="space-y-2 mb-4">
          {pet.owner_name && (
            <div className="flex items-center text-sm text-muted-foreground">
              <UserIcon className="w-4 h-4 mr-2 shrink-0" />
              <span className="truncate">{pet.owner_name}</span>
            </div>
          )}
          {pet.phone_number && (
            <div className="flex items-center text-sm text-muted-foreground">
              <Phone className="w-4 h-4 mr-2 shrink-0" />
              <span>{displayPhone}</span>
            </div>
          )}
        </div>

        <div className="flex items-center mt-auto pt-2 border-t border-border/50">
          <span className="font-mono text-xs text-muted-foreground">
            ID: <span className="font-semibold text-foreground">{pet.collar_id}</span>
          </span>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex gap-2 mt-auto">
        <Button variant="outline" size="sm" asChild className="flex-1">
          <Link to={`/pet/${pet.id}`}>
            <Edit className="w-4 h-4 mr-1" />
            Modifier
          </Link>
        </Button>
        <Button variant="outline" size="sm" asChild className="flex-1">
          <Link to={`/pet/${pet.id}/preview`}>
            <Eye className="w-4 h-4 mr-1" />
            Aperçu
          </Link>
        </Button>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onDelete(pet.id)}
          className="text-destructive hover:text-destructive hover:bg-destructive/10"
          title="Supprimer"
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}