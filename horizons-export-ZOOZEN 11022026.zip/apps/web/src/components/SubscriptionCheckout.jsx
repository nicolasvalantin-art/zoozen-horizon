import React, { useState } from 'react';
import { CreditCard, Loader2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import apiServerClient from '@/lib/apiServerClient';
import pb from '@/lib/pocketbaseClient';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext.jsx';

export default function SubscriptionCheckout({ planType, userId, phoneVisibility = 'visible', children }) {
  const [loading, setLoading] = useState(false);
  const { refreshUser } = useAuth();

  const handleCheckout = async () => {
    if (!userId) {
      toast.error('Vous devez être connecté pour vous abonner.');
      return;
    }

    if (!planType) {
      toast.error('Veuillez sélectionner un forfait valide.');
      return;
    }

    const normalizedPlanType = planType.toLowerCase();
    const validPlans = ['basique', 'standard', 'premium'];
    
    if (!validPlans.includes(normalizedPlanType)) {
      toast.error('Le forfait sélectionné n\'est pas valide.');
      return;
    }

    setLoading(true);

    try {
      // Save the phone visibility preference first for all checkouts
      await pb.collection('users').update(userId, {
        phone_visibility: phoneVisibility
      }, { $autoCancel: false });
      await refreshUser();
    } catch (error) {
      console.error('Failed to update phone visibility preference:', error);
      // We log the error but proceed with checkout
    }

    // Handle Free Plan (Basique) directly in PocketBase
    if (normalizedPlanType === 'basique') {
      try {
        // Create subscription record
        await pb.collection('subscriptions').create({
          user_id: userId,
          plan_type: 'basique',
          status: 'active',
          start_date: new Date().toISOString(),
        }, { $autoCancel: false });

        // Update user record
        await pb.collection('users').update(userId, {
          subscription_plan: 'basique',
          subscription_status: 'active',
        }, { $autoCancel: false });

        toast.success('Plan gratuit activé avec succès !');
        
        // Redirect to dashboard after a short delay
        setTimeout(() => {
          window.location.href = '/dashboard';
        }, 1500);
      } catch (error) {
        console.error('Free plan activation error:', error);
        toast.error('Erreur lors de l\'activation du plan gratuit.');
        setLoading(false);
      }
      return;
    }

    // Handle Paid Plans (Standard, Premium) via Stripe
    try {
      const response = await apiServerClient.fetch('/stripe/create-checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planType: normalizedPlanType,
          userId,
          successUrl: `${window.location.origin}/subscription?success=true&session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/plans?cancelled=true`
        })
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || errorData.message || 'Échec de la création de la session de paiement');
      }

      const data = await response.json();
      
      if (!data.url) {
        throw new Error('URL de paiement manquante dans la réponse');
      }
      
      // Open Stripe checkout in new tab (bypasses iframe restrictions)
      window.open(data.url, '_blank');
    } catch (error) {
      console.error('Checkout error:', error);
      toast.error(error.message || 'Échec de l\'initialisation du paiement. Veuillez réessayer.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button onClick={handleCheckout} disabled={loading} className="w-full">
      {loading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Traitement...
        </>
      ) : (
        <>
          {planType?.toLowerCase() === 'basique' ? (
            <Check className="w-4 h-4 mr-2" />
          ) : (
            <CreditCard className="w-4 h-4 mr-2" />
          )}
          {children || 'S\'abonner'}
        </>
      )}
    </Button>
  );
}