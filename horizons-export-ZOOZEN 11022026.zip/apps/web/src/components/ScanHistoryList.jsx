import React from 'react';
import { MapPin, Clock, Smartphone, Globe } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

export default function ScanHistoryList({ scans }) {
  if (!scans || scans.length === 0) {
    return (
      <div className="text-center py-12 bg-muted/30 rounded-2xl border border-dashed border-border mt-8">
        <MapPin className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-foreground">Aucun scan enregistré</h3>
        <p className="text-muted-foreground mt-2">Dès que quelqu'un scannera ce badge, l'historique apparaîtra ici.</p>
      </div>
    );
  }

  return (
    <div className="mt-8 space-y-4">
      <h3 className="text-xl font-semibold mb-4">Historique des scans</h3>
      <div className="grid gap-4">
        {scans.map((scan) => {
          const dateObj = new Date(scan.timestamp || scan.created);
          
          return (
            <Card key={scan.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 gap-4">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 p-3 rounded-full shrink-0">
                      <Clock className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium text-foreground">
                        {dateObj.toLocaleDateString('fr-FR', {
                          weekday: 'long',
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric'
                        })}
                      </p>
                      <p className="text-sm text-muted-foreground mt-0.5">
                        à {dateObj.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col sm:items-end gap-2 text-sm text-muted-foreground bg-muted/30 sm:bg-transparent p-3 sm:p-0 rounded-lg">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 shrink-0" />
                      <span>
                        {scan.latitude && scan.longitude 
                          ? `${scan.latitude.toFixed(4)}, ${scan.longitude.toFixed(4)}`
                          : 'Position non communiquée'}
                      </span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1.5" title="Appareil">
                        <Smartphone className="w-4 h-4" />
                        <span className="capitalize">{scan.deviceType || 'Inconnu'}</span>
                      </div>
                      <div className="flex items-center gap-1.5" title="Navigateur">
                        <Globe className="w-4 h-4" />
                        <span className="capitalize">{scan.browser || 'Inconnu'}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}