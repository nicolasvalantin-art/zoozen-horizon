import React from 'react';
import { motion } from 'framer-motion';
import { Infinity, Feather, Droplets, Smartphone } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const advantages = [
  {
    icon: Infinity,
    title: 'Ne nécessite aucune recharge',
    description: 'Identification permanente et sans entretien.',
    iconBg: 'bg-blue-500/10',
    iconColor: 'text-blue-600 dark:text-blue-400',
    hoverBg: 'from-blue-500/5 to-transparent'
  },
  {
    icon: Feather,
    title: 'Léger comme une plume',
    description: 'Quelques grammes - Aucune incidence sur le bien-être de votre animal.',
    iconBg: 'bg-emerald-500/10',
    iconColor: 'text-emerald-600 dark:text-emerald-400',
    hoverBg: 'from-emerald-500/5 to-transparent'
  },
  {
    icon: Droplets,
    title: 'Étanche et résistant',
    description: "Ne craint ni l'eau, ni le gel, ni les chocs du quotidien.",
    iconBg: 'bg-sky-500/10',
    iconColor: 'text-sky-600 dark:text-sky-400',
    hoverBg: 'from-sky-500/5 to-transparent'
  },
  {
    icon: Smartphone,
    title: 'Espace client intuitif',
    description: 'Configuration simple et gestion facile de vos animaux.',
    iconBg: 'bg-violet-500/10',
    iconColor: 'text-violet-600 dark:text-violet-400',
    hoverBg: 'from-violet-500/5 to-transparent'
  }
];

export default function ProductAdvantagesSection() {
  return (
    <section className="py-24 bg-gradient-to-b from-background to-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Conçu pour le quotidien
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Des médailles pensées pour le confort de votre animal et votre tranquillité d'esprit.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {advantages.map((adv, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="h-full"
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 overflow-hidden group bg-card relative z-10">
                <div className={`absolute inset-0 bg-gradient-to-br ${adv.hoverBg} opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10`} />
                <CardContent className="p-8 flex flex-col items-center text-center h-full">
                  <div className={`p-4 rounded-2xl ${adv.iconBg} mb-6 group-hover:scale-110 transition-transform duration-300 shadow-sm`}>
                    <adv.icon className={`w-8 h-8 ${adv.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-3 text-balance">
                    {adv.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {adv.description}
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}