import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { Check, Shield, Zap, Sparkles, CreditCard } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export default function SubscriptionManagementPage() {
  const { currentUser, refreshUser } = useAuth();
  const [subscription, setSubscription] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSubscription();
  }, [currentUser]);

  const fetchSubscription = async () => {
    try {
      const records = await pb.collection('subscriptions').getList(1, 1, {
        filter: `user_id="${currentUser.id}"`,
        sort: '-created',
        $autoCancel: false
      });
      
      if (records.items.length > 0) {
        setSubscription(records.items[0]);
      }
    } catch (err) {
      console.error('Failed to fetch subscription:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleUpgrade = () => {
    toast.success("Redirection vers la passerelle de paiement...");
    // Future integration with Stripe API server endpoints
  };

  const currentTier = currentUser?.subscription_tier || 'free';

  if (loading) {
    return (
      <div className="min-h-screen bg-muted/10">
        <Header />
        <main className="max-w-5xl mx-auto px-4 py-16">
          <Skeleton className="h-10 w-64 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Skeleton className="h-[500px] rounded-3xl" />
            <Skeleton className="h-[500px] rounded-3xl" />
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <Helmet><title>Mon Abonnement - Zoozen</title></Helmet>
      <Header />
      
      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h1 className="text-4xl font-extrabold tracking-tight text-foreground mb-4">Gérez votre protection</h1>
          <p className="text-lg text-muted-foreground">
            Actuellement sur l'abonnement <strong className="uppercase text-foreground">{currentTier}</strong>. 
            Débloquez le plein potentiel de votre médaille connectée avec Premium.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 max-w-5xl mx-auto">
          {/* FREE TIER CARD */}
          <Card className={`relative overflow-hidden rounded-3xl border-2 ${currentTier === 'free' ? 'border-primary shadow-lg shadow-primary/5' : 'border-border'}`}>
            {currentTier === 'free' && (
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-xs font-bold rounded-bl-xl">
                FORFAIT ACTUEL
              </div>
            )}
            <CardHeader className="p-8 pb-4 bg-muted/30">
              <Shield className="w-10 h-10 text-muted-foreground mb-4" />
              <CardTitle className="text-2xl font-bold">Essentiel (Gratuit)</CardTitle>
              <CardDescription className="text-base mt-2">La protection de base pour votre compagnon.</CardDescription>
              <div className="mt-4 flex items-baseline text-4xl font-extrabold">
                0€ <span className="text-lg text-muted-foreground font-medium ml-1">/ mois</span>
              </div>
            </CardHeader>
            <CardContent className="p-8 pt-6 space-y-4">
              <ul className="space-y-4 text-sm text-foreground">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Profil public pour votre animal</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Contact rapide par téléphone</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Dernière position GPS sur la carte</span>
                </li>
                <li className="flex items-start gap-3 opacity-50">
                  <div className="w-5 h-5 rounded-full border-2 border-muted-foreground shrink-0" />
                  <span className="line-through">Historique complet des positions</span>
                </li>
                <li className="flex items-start gap-3 opacity-50">
                  <div className="w-5 h-5 rounded-full border-2 border-muted-foreground shrink-0" />
                  <span className="line-through">Alertes SMS instantanées</span>
                </li>
              </ul>
            </CardContent>
          </Card>

          {/* PREMIUM TIER CARD */}
          <Card className={`relative overflow-hidden rounded-3xl border-2 ${currentTier === 'premium' ? 'border-primary shadow-lg shadow-primary/10' : 'border-border'}`}>
            {currentTier === 'premium' && (
              <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-4 py-1 text-xs font-bold rounded-bl-xl">
                FORFAIT ACTUEL
              </div>
            )}
            <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent pointer-events-none" />
            <CardHeader className="p-8 pb-4 relative z-10">
              <Sparkles className="w-10 h-10 text-primary mb-4" />
              <CardTitle className="text-2xl font-bold">Premium</CardTitle>
              <CardDescription className="text-base mt-2">La sérénité absolue, sans compromis.</CardDescription>
              <div className="mt-4 flex items-baseline text-4xl font-extrabold text-primary">
                3.99€ <span className="text-lg text-muted-foreground font-medium ml-1">/ mois</span>
              </div>
            </CardHeader>
            <CardContent className="p-8 pt-6 space-y-4 relative z-10">
              <ul className="space-y-4 text-sm font-medium text-foreground">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Toutes les fonctionnalités Essentiel</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Historique complet et détaillé des scans</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Alertes instantanées par SMS</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Génération de fiches "Perdu" PDF</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-primary shrink-0" />
                  <span>Support prioritaire 24/7</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter className="p-8 pt-0 relative z-10">
              {currentTier === 'premium' ? (
                <div className="w-full text-center space-y-2">
                  <div className="text-sm font-medium text-green-600 bg-green-50 py-2 rounded-lg">
                    Abonnement actif jusqu'au {subscription?.end_date ? new Date(subscription.end_date).toLocaleDateString() : 'renouvellement'}
                  </div>
                  <Button variant="outline" className="w-full mt-4">Gérer ma facturation</Button>
                </div>
              ) : (
                <Button 
                  onClick={handleUpgrade}
                  className="w-full py-6 text-lg rounded-xl shadow-xl shadow-primary/25 hover:-translate-y-0.5 transition-transform"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Passer en Premium
                </Button>
              )}
            </CardFooter>
          </Card>
        </div>

        {currentTier === 'premium' && subscription && (
          <div className="mt-16 max-w-2xl mx-auto bg-card border border-border rounded-2xl p-6 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
              <div className="bg-muted p-3 rounded-full">
                <CreditCard className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <h4 className="font-semibold">Détails de facturation</h4>
                <p className="text-sm text-muted-foreground">Paiement sécurisé via Stripe</p>
              </div>
            </div>
            <Button variant="ghost">Voir les factures</Button>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}