import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ProductsList from '@/components/ProductsList.jsx';

export default function ShopPage() {
  return (
    <div className="min-h-[100dvh] flex flex-col bg-slate-50">
      <Helmet>
        <title>Boutique - Zoozen</title>
        <meta name="description" content="Découvrez notre sélection de produits et accessoires pour vos animaux de compagnie." />
      </Helmet>
      
      <Header />
      
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-10">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 tracking-tight">Boutique</h1>
          <p className="text-lg text-slate-500 mt-3 max-w-2xl">
            Découvrez nos médailles connectées et accessoires exclusifs pour veiller sur vos compagnons à quatre pattes.
          </p>
        </div>
        
        <ProductsList />
      </main>
      
      <Footer />
    </div>
  );
}