import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

export default function TermsOfServicePage() {
  const lastUpdated = "21 Avril 2026";

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <Helmet>
        <title>Conditions Générales d'Utilisation | Zoozen.fr</title>
        <meta name="description" content="Lisez les conditions d'utilisation des services et produits Zoozen.fr." />
      </Helmet>

      <Header />

      <main className="flex-1 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <article className="prose prose-slate dark:prose-invert prose-headings:font-bold prose-h1:text-4xl prose-h1:tracking-tight prose-a:text-primary max-w-none">
          <h1 className="mb-4">Conditions Générales d'Utilisation</h1>
          <p className="text-muted-foreground mb-8">Dernière mise à jour : {lastUpdated}</p>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">1. Acceptation des conditions</h2>
            <p className="leading-relaxed">
              En accédant au site web Zoozen.fr, en créant un compte ou en utilisant nos médailles connectées, vous acceptez d'être lié par les présentes Conditions Générales d'Utilisation (CGU). 
              Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser nos services.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">2. Description du service</h2>
            <p className="leading-relaxed">
              Zoozen.fr propose un service d'identification d'animaux de compagnie basé sur des médailles physiques équipées de QR codes. 
              Le scan de la médaille permet d'afficher un profil public de l'animal et d'envoyer des notifications de localisation au propriétaire. 
              Les fonctionnalités avancées dépendent de l'abonnement souscrit.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">3. Responsabilités de l'utilisateur</h2>
            <p className="leading-relaxed">
              En tant qu'utilisateur, vous vous engagez à :
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>Fournir des informations exactes, complètes et à jour concernant votre identité et vos animaux.</li>
              <li>Maintenir la confidentialité de vos identifiants de connexion.</li>
              <li>Ne pas utiliser nos services à des fins illégales, trompeuses ou malveillantes.</li>
              <li>Vous assurer que les informations de contact que vous rendez publiques sur le profil de l'animal ne compromettent pas votre sécurité.</li>
            </ul>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">4. Conditions d'abonnement</h2>
            <p className="leading-relaxed">
              Certains services Premium nécessitent un abonnement payant. 
              Les abonnements sont renouvelés automatiquement à la fin de chaque période de facturation, sauf annulation de votre part avant la date de renouvellement. 
              L'annulation prendra effet à la fin de la période facturée en cours.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">5. Conditions de paiement</h2>
            <p className="leading-relaxed">
              Tous les paiements sont traités par notre prestataire sécurisé tiers. Vous acceptez de fournir des informations de paiement valides et de payer les frais applicables selon le plan choisi. 
              En cas de défaut de paiement, Zoozen.fr se réserve le droit de suspendre ou de rétrograder votre compte au plan Basique.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">6. Propriété intellectuelle</h2>
            <p className="leading-relaxed">
              Tous les contenus du site web, logos, designs, logiciels, et technologies constituant le service Zoozen.fr sont notre propriété exclusive ou celle de nos concédants de licence. 
              Vous vous engagez à ne pas reproduire, distribuer ou créer des œuvres dérivées sans notre autorisation expresse.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">7. Limitation de responsabilité</h2>
            <p className="leading-relaxed">
              Dans toute la mesure permise par la loi, Zoozen.fr ne saurait être tenu responsable des dommages indirects, accessoires, spéciaux ou punitifs résultant de l'utilisation ou de l'incapacité d'utiliser nos services. 
              Bien que nous fassions de notre mieux pour assurer un fonctionnement continu, nous ne garantissons pas que les notifications arriveront toujours instantanément ou que l'animal sera retrouvé.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">8. Exclusion de garanties</h2>
            <p className="leading-relaxed">
              Le service est fourni "en l'état" et "selon disponibilité". Zoozen.fr décline toute garantie explicite ou implicite concernant la fiabilité du scan QR par des tiers, la précision de la géolocalisation ou la disponibilité continue des serveurs de notification.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">9. Résiliation</h2>
            <p className="leading-relaxed">
              Nous nous réservons le droit de suspendre ou de résilier votre accès à nos services en cas de violation avérée de ces Conditions, de fraude ou de comportement abusif. Vous pouvez également résilier votre compte à tout moment via les paramètres du tableau de bord.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">10. Droit applicable</h2>
            <p className="leading-relaxed">
              Ces conditions sont régies et interprétées conformément aux lois en vigueur en France. Tout litige découlant de l'utilisation de nos services sera soumis à la compétence exclusive des tribunaux français compétents.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">11. Informations de contact</h2>
            <p className="leading-relaxed">
              Pour toute question concernant ces Conditions Générales d'Utilisation, vous pouvez nous contacter :
            </p>
            <address className="not-italic mt-4 p-4 bg-muted rounded-lg border border-border">
              <strong>Service Juridique Zoozen.fr</strong><br />
              Email : <a href="mailto:legal@zoozen.fr" className="text-primary hover:underline">legal@zoozen.fr</a><br />
              Adresse : 43 avenue Marceau Ginoux, 13330 Pélissanne, France
            </address>
          </section>
        </article>
      </main>

      <Footer />
    </div>
  );
}