import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Phone, MapPin, Heart, MessageCircle, Syringe, Scissors, AlertCircle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import ScanRecorder from '@/components/ScanRecorder.jsx';
import ScanNotificationModal from '@/components/ScanNotificationModal.jsx';
import LocationShareModal from '@/components/LocationShareModal.jsx';
import pb from '@/lib/pocketbaseClient';
import { maskPhoneNumber } from '@/utils/PhoneNumberMasker.js';

const petTypeTranslations = {
  dog: 'Chien',
  cat: 'Chat',
  rabbit: 'Lapin',
  bird: 'Oiseau',
  other: 'Autre'
};

export default function PublicScanPage() {
  const { collarId } = useParams();
  const [pet, setPet] = useState(null);
  const [loading, setLoading] = useState(true);
  const [errorType, setErrorType] = useState(null);
  const [notificationModalOpen, setNotificationModalOpen] = useState(false);
  const [locationModalOpen, setLocationModalOpen] = useState(false);

  useEffect(() => {
    fetchPetDetails();
  }, [collarId]);

  const fetchPetDetails = async () => {
    setLoading(true);
    setErrorType(null);
    
    try {
      console.log(`[Scan Debug] 1. Starting fetch chain for ID: ${collarId}`);
      
      let badgeRecord = null;
      try {
        badgeRecord = await pb.collection('badges').getFirstListItem(`badge_code="${collarId}"`, {
          $autoCancel: false
        });
      } catch (badgeErr) {
        console.log('[Scan Debug] 2. Badge not found by badge_code.');
      }

      if (badgeRecord) {
        if (!badgeRecord.pet_id) {
          setErrorType('unassigned');
          setLoading(false);
          return;
        }

        try {
          const petRecord = await pb.collection('pets').getOne(badgeRecord.pet_id, {
            expand: 'owner_id',
            $autoCancel: false
          });
          setPet(petRecord);
          setLoading(false);
          return;
        } catch (petErr) {
          console.error('[Scan Debug] 4. Failed to fetch pet details:', petErr);
          setErrorType('pet_fetch_error');
          setLoading(false);
          return;
        }
      }

      console.log(`[Scan Debug] 3. Falling back to direct collar_id search`);
      try {
        const petRecord = await pb.collection('pets').getFirstListItem(`collar_id="${collarId}"`, {
          expand: 'owner_id',
          $autoCancel: false
        });
        setPet(petRecord);
      } catch (fallbackErr) {
        setErrorType('not_found');
      }

    } catch (error) {
      console.error('[Scan Debug] Unexpected error:', error);
      setErrorType('not_found');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-slate-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl shadow-lg border-slate-200 rounded-2xl overflow-hidden">
          <Skeleton className="aspect-square w-full bg-slate-200" />
          <CardContent className="p-8 space-y-6">
            <Skeleton className="h-10 w-3/4 mx-auto bg-slate-200" />
            <Skeleton className="h-5 w-1/2 mx-auto bg-slate-200" />
            <Skeleton className="h-24 w-full bg-slate-200 mt-8" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (errorType || !pet) {
    return (
      <>
        <Helmet>
          <title>Information - Zoozen</title>
          <meta name="description" content="Information concernant ce badge Zoozen." />
        </Helmet>
        <div className="min-h-[100dvh] bg-slate-50 flex items-center justify-center p-4">
          <Card className="w-full max-w-md text-center p-8 shadow-lg border-slate-200 rounded-2xl">
            {errorType === 'unassigned' ? (
              <>
                <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Info className="w-10 h-10 text-blue-500" />
                </div>
                <h1 className="text-2xl font-bold text-slate-900 mb-3">Badge non assigné</h1>
                <p className="text-slate-600 leading-relaxed">
                  Ce badge Zoozen est valide mais n'a pas encore été associé à un animal par son propriétaire.
                </p>
              </>
            ) : errorType === 'pet_fetch_error' ? (
              <>
                <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-6">
                  <AlertCircle className="w-10 h-10 text-red-500" />
                </div>
                <h1 className="text-2xl font-bold text-slate-900 mb-3">Erreur de lecture</h1>
                <p className="text-slate-600 leading-relaxed">
                  Le badge a été reconnu, mais nous n'avons pas pu charger les informations de l'animal. Le profil a peut-être été supprimé.
                </p>
              </>
            ) : (
              <>
                <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <MessageCircle className="w-10 h-10 text-slate-400" />
                </div>
                <h1 className="text-2xl font-bold text-slate-900 mb-3">Animal introuvable</h1>
                <p className="text-slate-600 leading-relaxed">
                  Cet identifiant de médaille n'est pas enregistré dans notre système ou le code est incorrect.
                </p>
              </>
            )}
            <Button 
              variant="outline" 
              className="mt-8 w-full"
              onClick={() => window.location.href = '/'}
            >
              Retour à l'accueil
            </Button>
          </Card>
        </div>
      </>
    );
  }

  const photoUrl = pet.photos && pet.photos.length > 0 
    ? pb.files.getURL(pet, pet.photos[0])
    : null;

  const isPhoneVisible = Boolean(pet.phone_number && pet.expand?.owner_id?.phone_visibility !== 'hidden');
  
  return (
    <>
      <Helmet>
        <title>{`${pet.name} - Zoozen`}</title>
        <meta name="description" content={`Vous avez trouvé ${pet.name} ! Contactez le propriétaire pour les réunir.`} />
      </Helmet>
      
      <ScanRecorder collarId={collarId} />

      <div className="min-h-[100dvh] bg-slate-50 flex items-center justify-center p-4 py-12">
        <Card className="w-full max-w-2xl overflow-hidden shadow-xl border-slate-200 rounded-2xl bg-white">
          {/* Photo */}
          {photoUrl ? (
            <div className="aspect-square bg-slate-100 relative">
              <img 
                src={photoUrl} 
                alt={`Photo de ${pet.name}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            </div>
          ) : (
            <div className="aspect-square bg-slate-100 flex items-center justify-center">
              <Heart className="w-24 h-24 text-slate-300" />
            </div>
          )}

          <CardContent className="p-8 space-y-8 relative -mt-12 bg-white rounded-t-3xl">
            {/* Header */}
            <div className="text-center">
              <div className="flex items-center justify-center gap-3 mb-3">
                <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">{pet.name}</h1>
                <Badge className="bg-primary/10 text-primary hover:bg-primary/20 border-none text-sm px-3 py-1">
                  {petTypeTranslations[pet.type] || pet.type}
                </Badge>
              </div>
              <div className="flex items-center justify-center gap-2 text-lg text-slate-600 font-medium">
                {pet.breed && <span>{pet.breed}</span>}
                {pet.breed && pet.age && <span>•</span>}
                {pet.age && <span>{pet.age} ans</span>}
              </div>
            </div>

            {/* Personal Message */}
            {pet.personal_message && (
              <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5 shadow-sm">
                <div className="flex items-start">
                  <Heart className="w-6 h-6 text-amber-500 mr-3 flex-shrink-0 mt-0.5" />
                  <p className="text-amber-900 leading-relaxed font-medium">{pet.personal_message}</p>
                </div>
              </div>
            )}

            {/* Contact Info */}
            <div className="space-y-4 bg-slate-50 rounded-2xl p-6 border border-slate-100">
              <h2 className="font-bold text-xl text-slate-900 text-center mb-6">Contacter le propriétaire</h2>
              
              {isPhoneVisible ? (
                <div className="flex flex-col items-center justify-center gap-4">
                  <div className="flex items-center justify-center text-slate-700 bg-white p-4 rounded-xl shadow-sm border border-slate-200 w-full">
                    <Phone className="w-6 h-6 mr-4 text-primary flex-shrink-0" />
                    <span className="font-mono text-xl font-semibold tracking-wide">
                      {maskPhoneNumber(pet.phone_number)}
                    </span>
                  </div>
                  <Button 
                    asChild
                    className="w-full h-12 text-base font-semibold rounded-xl shadow-sm hover:shadow-md transition-all" 
                    variant="default"
                  >
                    <a href={`tel:${pet.phone_number}`}>
                      <Phone className="w-5 h-5 mr-2" />
                      Appeler le propriétaire
                    </a>
                  </Button>
                </div>
              ) : (
                <div className="text-center text-slate-500 italic bg-white p-4 rounded-xl border border-slate-200">
                  Le numéro de téléphone est masqué par le propriétaire.
                </div>
              )}

              {pet.adresse && !pet.hide_address && (
                <div className="flex items-start justify-center text-slate-600 mt-4 px-4">
                  <MapPin className="w-5 h-5 mr-3 text-slate-400 flex-shrink-0 mt-0.5" />
                  <span className="text-center leading-relaxed">{pet.adresse} {pet.code_postal} {pet.ville}</span>
                </div>
              )}
              {pet.ville && pet.hide_address && (
                <div className="flex items-start justify-center text-slate-600 mt-4 px-4">
                  <MapPin className="w-5 h-5 mr-3 text-slate-400 flex-shrink-0 mt-0.5" />
                  <span className="text-center leading-relaxed">{pet.ville}</span>
                </div>
              )}
            </div>

            {/* Health Info */}
            {(pet.vaccination_status !== 'unknown' || pet.sterilization_status !== 'unknown') && (
              <div className="space-y-4">
                <h2 className="font-bold text-lg text-slate-900 text-center">Informations de santé</h2>
                
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  {pet.vaccination_status !== 'unknown' && (
                    <div className="flex items-center text-slate-700 bg-slate-50 px-4 py-3 rounded-xl border border-slate-100 w-full sm:w-auto justify-center">
                      <Syringe className="w-5 h-5 mr-3 text-emerald-500 flex-shrink-0" />
                      <span className="font-medium">
                        Vaccins : {pet.vaccination_status === 'up_to_date' ? 'À jour' : 'En attente'}
                      </span>
                    </div>
                  )}

                  {pet.sterilization_status !== 'unknown' && (
                    <div className="flex items-center text-slate-700 bg-slate-50 px-4 py-3 rounded-xl border border-slate-100 w-full sm:w-auto justify-center">
                      <Scissors className="w-5 h-5 mr-3 text-blue-500 flex-shrink-0" />
                      <span className="font-medium">
                        Stérilisé : {pet.sterilization_status === 'yes' ? 'Oui' : 'Non'}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* CTA Buttons */}
            <div className="pt-4 space-y-3">
              <Button 
                className="w-full h-14 text-lg font-semibold rounded-xl shadow-md hover:shadow-lg transition-all active:scale-[0.98]" 
                size="lg"
                onClick={() => setNotificationModalOpen(true)}
              >
                <MessageCircle className="w-6 h-6 mr-2" />
                J'ai trouvé cet animal
              </Button>
              
              <Button 
                variant="outline"
                className="w-full h-14 text-lg font-semibold rounded-xl shadow-sm hover:shadow-md transition-all active:scale-[0.98] border-primary/20 text-primary hover:bg-primary/5" 
                size="lg"
                onClick={() => setLocationModalOpen(true)}
              >
                <MapPin className="w-6 h-6 mr-2" />
                Envoyer ma localisation
              </Button>
            </div>

            {/* Zoozen Branding */}
            <div className="text-center pt-8 border-t border-slate-100">
              <p className="text-sm text-slate-400 font-medium mb-3 uppercase tracking-wider">
                Protégé par
              </p>
              <div className="flex items-center justify-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center shadow-sm">
                  <span className="text-primary-foreground font-bold text-sm">Z</span>
                </div>
                <span className="font-bold text-xl text-slate-900 tracking-tight">Zoozen</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notification Modal */}
      <ScanNotificationModal
        isOpen={notificationModalOpen}
        onClose={() => setNotificationModalOpen(false)}
        petId={pet.id}
        petName={pet.name}
        ownerEmail={pet.expand?.owner_id?.email}
      />

      {/* Location Share Modal */}
      <LocationShareModal
        isOpen={locationModalOpen}
        onClose={() => setLocationModalOpen(false)}
        petName={pet.name}
        ownerPhone={pet.phone_number}
        ownerEmail={pet.expand?.owner_id?.email}
      />
    </>
  );
}