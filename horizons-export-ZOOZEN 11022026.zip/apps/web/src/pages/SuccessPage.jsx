import React from 'react';
import { Helmet } from 'react-helmet';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, ShoppingBag, ArrowRight } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';

export default function SuccessPage() {
  const [searchParams] = useSearchParams();
  const sessionId = searchParams.get('session_id');

  return (
    <div className="min-h-[100dvh] flex flex-col bg-slate-50">
      <Helmet>
        <title>Commande Réussie - ToutouTag</title>
      </Helmet>
      
      <Header />
      
      <main className="flex-grow flex items-center justify-center p-4 py-12">
        <div className="max-w-md w-full bg-white p-8 rounded-2xl shadow-sm border border-slate-200 text-center">
          <div className="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10" />
          </div>
          
          <h1 className="text-3xl font-bold text-slate-900 mb-3">Commande confirmée !</h1>
          
          <p className="text-slate-500 mb-8 leading-relaxed">
            Merci pour votre achat. Votre commande a été traitée avec succès et sera expédiée très prochainement.
            {sessionId && (
              <span className="block mt-4 text-xs text-slate-400 bg-slate-50 p-2 rounded-md break-all border border-slate-100">
                Réf: {sessionId}
              </span>
            )}
          </p>
          
          <div className="flex flex-col gap-3">
            <Button asChild className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-12 text-base">
              <Link to="/shop">
                <ShoppingBag className="w-5 h-5 mr-2" />
                Continuer vos achats
              </Link>
            </Button>
            <Button asChild variant="outline" className="w-full h-12 text-base text-slate-600">
              <Link to="/">
                Retour à l'accueil
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </Button>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}