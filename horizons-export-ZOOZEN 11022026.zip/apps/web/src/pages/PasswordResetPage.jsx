import React, { useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

export default function PasswordResetPage() {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const { requestPasswordReset, confirmPasswordReset } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const handleRequestReset = async (e) => {
    e.preventDefault();
    
    if (!email) {
      toast.error('Veuillez entrer votre e-mail');
      return;
    }

    setLoading(true);
    try {
      await requestPasswordReset(email);
      setEmailSent(true);
      toast.success('E-mail de réinitialisation envoyé');
    } catch (error) {
      console.error('Password reset request failed:', error);
      toast.success("Si un compte existe, un e-mail de réinitialisation a été envoyé");
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmReset = async (e) => {
    e.preventDefault();
    
    if (!password || !passwordConfirm) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    if (password.length < 8) {
      toast.error('Le mot de passe doit contenir au moins 8 caractères');
      return;
    }

    if (password !== passwordConfirm) {
      toast.error('Les mots de passe ne correspondent pas');
      return;
    }

    setLoading(true);
    try {
      await confirmPasswordReset(token, password, passwordConfirm);
      toast.success('Réinitialisation du mot de passe réussie');
      window.location.href = '/login';
    } catch (error) {
      console.error('Password reset failed:', error);
      toast.error('Lien de réinitialisation invalide ou expiré');
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Réinitialiser le mot de passe - Zoozen</title>
        <meta name="description" content="Réinitialisez le mot de passe de votre compte Zoozen." />
      </Helmet>
      <Header />
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">
              {token ? 'Définir un nouveau mot de passe' : 'Réinitialiser le mot de passe'}
            </CardTitle>
            <CardDescription>
              {token 
                ? 'Entrez votre nouveau mot de passe ci-dessous' 
                : emailSent 
                  ? 'Vérifiez vos e-mails pour les instructions de réinitialisation'
                  : 'Entrez votre e-mail pour recevoir les instructions de réinitialisation'
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {!token ? (
              emailSent ? (
                <div className="text-center space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Nous avons envoyé les instructions de réinitialisation à <strong>{email}</strong>
                  </p>
                  <Button variant="outline" asChild className="w-full">
                    <Link to="/login">Retour à la connexion</Link>
                  </Button>
                </div>
              ) : (
                <form onSubmit={handleRequestReset} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="vous@exemple.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="text-foreground"
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Envoi en cours...' : 'Envoyer le lien de réinitialisation'}
                  </Button>
                  <Button variant="outline" asChild className="w-full">
                    <Link to="/login">Retour à la connexion</Link>
                  </Button>
                </form>
              )
            ) : (
              <form onSubmit={handleConfirmReset} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Nouveau mot de passe</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={8}
                    className="text-foreground"
                  />
                  <p className="text-xs text-muted-foreground">
                    Au moins 8 caractères
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="passwordConfirm">Confirmer le nouveau mot de passe</Label>
                  <Input
                    id="passwordConfirm"
                    type="password"
                    placeholder="••••••••"
                    value={passwordConfirm}
                    onChange={(e) => setPasswordConfirm(e.target.value)}
                    required
                    className="text-foreground"
                  />
                </div>
                <Button type="submit" className="w-full" disabled={loading}>
                  {loading ? 'Réinitialisation...' : 'Réinitialiser le mot de passe'}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
      <Footer />
    </>
  );
}