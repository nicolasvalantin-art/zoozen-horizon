import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Shield, Plus, Trash2, RefreshCw, Tag, Download, Link as LinkIcon, Search, Link2, Link2Off } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient.js';
import { toast } from 'sonner';
import { QRCodeCanvas } from 'qrcode.react';

export default function BadgeManagementPage() {
  const [badges, setBadges] = useState([]);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Assign Modal State
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [selectedBadgeForAssign, setSelectedBadgeForAssign] = useState(null);
  const [assignPetId, setAssignPetId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetchBadges();
    fetchPets();
  }, []);

  const fetchBadges = async () => {
    setLoading(true);
    try {
      const records = await pb.collection('badges').getFullList({
        sort: '-created_at',
        expand: 'pet_id',
        $autoCancel: false
      });
      setBadges(records);
    } catch (error) {
      console.error('Failed to fetch badges:', error);
      toast.error('Erreur lors du chargement des badges');
    } finally {
      setLoading(false);
    }
  };

  const fetchPets = async () => {
    try {
      const response = await pb.collection('pets').getFullList({
        sort: 'name',
        $autoCancel: false
      });
      setPets(response);
    } catch (error) {
      console.error('Erreur de chargement des animaux:', error);
    }
  };

  const generateNewBadge = async () => {
    setGenerating(true);
    try {
      const response = await apiServerClient.fetch('/badges', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ count: 1, status: 'available' })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de la génération');
      }
      
      toast.success('Nouveau badge généré avec succès');
      fetchBadges();
    } catch (error) {
      console.error('Failed to generate badge:', error);
      toast.error(`Erreur: ${error.message}`);
    } finally {
      setGenerating(false);
    }
  };

  const deleteBadge = async (id) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer ce badge ?')) return;
    
    try {
      await pb.collection('badges').delete(id, { $autoCancel: false });
      toast.success('Badge supprimé');
      fetchBadges();
    } catch (error) {
      console.error('Failed to delete badge:', error);
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleAssignBadge = async (e) => {
    e.preventDefault();
    if (!selectedBadgeForAssign || !assignPetId) {
      toast.error('Veuillez sélectionner un animal.');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await apiServerClient.fetch(`/badges/${selectedBadgeForAssign.id}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pet_id: assignPetId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de l\'assignation');
      }

      toast.success('Badge assigné avec succès.');
      setIsAssignOpen(false);
      setSelectedBadgeForAssign(null);
      setAssignPetId('');
      fetchBadges();
    } catch (error) {
      console.error('Erreur assignation:', error);
      toast.error(`Erreur: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUnassignBadge = async (badgeId) => {
    if (!window.confirm('Voulez-vous vraiment désassigner ce badge ?')) return;
    
    try {
      const response = await apiServerClient.fetch(`/badges/${badgeId}/unassign`, {
        method: 'POST'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de la désassignation');
      }

      toast.success('Badge désassigné avec succès.');
      fetchBadges();
    } catch (error) {
      console.error('Erreur désassignation:', error);
      toast.error(`Erreur: ${error.message}`);
    }
  };

  const downloadQRCode = (badgeCode, url) => {
    const canvas = document.getElementById(`qr-${badgeCode}`);
    
    if (canvas) {
      try {
        const pngUrl = canvas.toDataURL("image/png");
        let downloadLink = document.createElement("a");
        downloadLink.href = pngUrl;
        downloadLink.download = `toutoutag-badge-${badgeCode}.png`;
        
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        toast.success('Code QR téléchargé avec succès');
      } catch (err) {
        console.error('[QR Download ERROR]', err);
        toast.error('Erreur lors du téléchargement');
      }
    } else {
      toast.error('Code QR introuvable');
    }
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'available': return 'bg-emerald-500/10 text-emerald-700 hover:bg-emerald-500/20';
      case 'used': return 'bg-amber-500/10 text-amber-700 hover:bg-amber-500/20';
      default: return 'bg-slate-500/10 text-slate-700 hover:bg-slate-500/20';
    }
  };

  const getStatusLabel = (status) => {
    switch(status) {
      case 'available': return 'Disponible';
      case 'used': return 'Utilisé';
      default: return status;
    }
  };

  const getBadgeUrl = (badgeCode) => {
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://toutoutag.com';
    return `${baseUrl}/badge/${badgeCode}`;
  };

  const openAssignModal = (badge) => {
    setSelectedBadgeForAssign(badge);
    setAssignPetId('');
    setIsAssignOpen(true);
  };

  const filteredBadges = badges.filter(badge => {
    const searchLower = searchQuery.toLowerCase();
    const codeMatch = badge.badge_code?.toLowerCase().includes(searchLower);
    const petMatch = badge.expand?.pet_id?.name?.toLowerCase().includes(searchLower);
    return codeMatch || petMatch;
  });

  return (
    <>
      <Helmet>
        <title>Gestion des Badges - Admin - ToutouTag</title>
      </Helmet>
      <Header />
      <main className="min-h-[100dvh] bg-slate-50 py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold tracking-tight text-slate-900 flex items-center">
                <Shield className="w-8 h-8 mr-3 text-primary" />
                Gestion des Badges
              </h1>
              <p className="text-slate-500 mt-1">
                Administration et génération des identifiants de médailles.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Button variant="outline" onClick={fetchBadges} disabled={loading} className="bg-white">
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Actualiser
              </Button>
              <Button onClick={generateNewBadge} disabled={generating} className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                {generating ? 'Génération...' : 'Générer un badge'}
              </Button>
            </div>
          </div>

          <Card className="shadow-md border-slate-200 rounded-2xl overflow-hidden bg-white">
            <CardHeader className="bg-slate-50 border-b border-slate-200 py-4 px-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <CardTitle className="flex items-center text-lg font-semibold text-slate-800">
                <Tag className="w-5 h-5 mr-2 text-primary" />
                Inventaire des badges
              </CardTitle>
              <div className="relative w-full sm:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  placeholder="Rechercher par code ou animal..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-white"
                />
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {loading ? (
                <div className="p-6 space-y-4">
                  {[1, 2, 3, 4].map(i => (
                    <Skeleton key={i} className="h-24 w-full rounded-xl bg-slate-100" />
                  ))}
                </div>
              ) : filteredBadges.length === 0 ? (
                <div className="text-center py-16 bg-slate-50/50">
                  <Tag className="w-16 h-16 mx-auto text-slate-300 mb-4" />
                  <h3 className="text-lg font-medium text-slate-900 mb-2">Aucun badge trouvé</h3>
                  <p className="text-slate-500 mb-6">
                    {searchQuery ? "Aucun résultat pour votre recherche." : "Commencez par générer votre premier badge."}
                  </p>
                  {!searchQuery && (
                    <Button onClick={generateNewBadge} disabled={generating} className="bg-primary text-primary-foreground hover:bg-primary/90">
                      Générer le premier badge
                    </Button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-slate-500 uppercase bg-slate-50/80 border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-4 font-semibold tracking-wide">Code du Badge</th>
                        <th className="px-6 py-4 font-semibold tracking-wide">QR Code & Lien NFC</th>
                        <th className="px-6 py-4 font-semibold tracking-wide">Statut & Assignation</th>
                        <th className="px-6 py-4 font-semibold tracking-wide text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredBadges.map((badge) => {
                        const badgeUrl = getBadgeUrl(badge.badge_code);
                        const petName = badge.expand?.pet_id?.name;

                        return (
                          <tr key={badge.id} className="hover:bg-slate-50/50 transition-colors group">
                            <td className="px-6 py-5 align-top">
                              <span className="font-mono font-bold text-sm bg-slate-100 border border-slate-200 px-2.5 py-1 rounded text-slate-800 tracking-wider">
                                {badge.badge_code}
                              </span>
                              <div className="text-xs text-slate-500 mt-2">
                                Créé le : {new Date(badge.created_at || badge.created).toLocaleDateString('fr-FR')}
                              </div>
                            </td>
                            <td className="px-6 py-5 align-top">
                              <div className="flex items-start gap-4">
                                <div className="bg-white p-3 rounded-xl shadow-sm border border-slate-200 shrink-0 flex items-center justify-center w-32 h-32">
                                  <QRCodeCanvas
                                    id={`qr-${badge.badge_code}`}
                                    value={badgeUrl}
                                    size={512}
                                    level={"H"}
                                    includeMargin={true}
                                    bgColor={"#FFFFFF"}
                                    fgColor={"#000000"}
                                    style={{ width: '100%', height: '100%' }}
                                  />
                                </div>
                                <div className="flex flex-col gap-3 min-w-[200px]">
                                  <div className="flex items-center text-xs text-slate-600 bg-slate-100 border border-slate-200 px-2.5 py-2 rounded-md font-mono w-max max-w-[260px]">
                                    <LinkIcon className="w-3 h-3 mr-2 shrink-0 text-slate-400" />
                                    <span className="truncate select-all" title={badgeUrl}>
                                      {badgeUrl}
                                    </span>
                                  </div>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="h-8 text-xs w-max bg-white shadow-sm hover:bg-slate-50 transition-all active:scale-[0.98]"
                                    onClick={() => downloadQRCode(badge.badge_code, badgeUrl)}
                                  >
                                    <Download className="w-3.5 h-3.5 mr-1.5" />
                                    Télécharger QR
                                  </Button>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-5 align-top">
                              <div className="flex flex-col items-start gap-2">
                                <Badge variant="outline" className={`font-medium border-transparent ${getStatusColor(badge.status)}`}>
                                  {getStatusLabel(badge.status)}
                                </Badge>
                                {badge.pet_id ? (
                                  <div className="text-xs text-slate-600 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                                    Lié à : <span className="font-semibold text-slate-900">{petName || badge.pet_id}</span>
                                  </div>
                                ) : (
                                  <div className="text-xs text-slate-400 italic">
                                    Non assigné
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="px-6 py-5 align-top text-right">
                              <div className="flex items-center justify-end gap-2">
                                {badge.pet_id ? (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleUnassignBadge(badge.id)}
                                    className="text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                                    title="Désassigner"
                                  >
                                    <Link2Off className="w-4 h-4 mr-1" />
                                    Désassigner
                                  </Button>
                                ) : (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => openAssignModal(badge)}
                                    className="text-primary hover:text-primary/90 hover:bg-primary/10"
                                    title="Assigner à un animal"
                                  >
                                    <Link2 className="w-4 h-4 mr-1" />
                                    Assigner
                                  </Button>
                                )}
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="text-slate-400 hover:text-destructive hover:bg-destructive/10 transition-colors"
                                  onClick={() => deleteBadge(badge.id)}
                                  title="Supprimer le badge"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </Button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Assign Modal */}
          <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Assigner le badge {selectedBadgeForAssign?.badge_code}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAssignBadge} className="space-y-6 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="assignPetId">Sélectionner un animal</Label>
                  <Select value={assignPetId} onValueChange={setAssignPetId} required>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Choisir un animal..." />
                    </SelectTrigger>
                    <SelectContent>
                      {pets.map(pet => (
                        <SelectItem key={pet.id} value={pet.id}>{pet.name} ({pet.id})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAssignOpen(false)} disabled={isSubmitting}>
                    Annuler
                  </Button>
                  <Button type="submit" disabled={isSubmitting || !assignPetId} className="bg-primary text-primary-foreground">
                    {isSubmitting ? 'Assignation...' : 'Assigner'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

        </div>
      </main>
      <Footer />
    </>
  );
}