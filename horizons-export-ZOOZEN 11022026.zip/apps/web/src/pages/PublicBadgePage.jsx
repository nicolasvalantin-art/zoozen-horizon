import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, MapPin, Phone, User, AlertCircle, Loader2 } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

export default function PublicBadgePage() {
  const { badgeId } = useParams();
  const [loading, setLoading] = useState(true);
  const [petData, setPetData] = useState(null);
  const [error, setError] = useState(null);
  const [locationStatus, setLocationStatus] = useState('pending');

  useEffect(() => {
    fetchBadgeData();
  }, [badgeId]);

  const fetchBadgeData = async () => {
    try {
      const result = await pb.collection('badges').getFirstListItem(`badge_id="${badgeId}"`, {
        expand: 'pet_id',
        $autoCancel: false
      });
      
      if (result.expand?.pet_id) {
        setPetData(result.expand.pet_id);
        captureAndRecordScan(result.expand.pet_id.id);
      } else {
        setError("Ce badge n'est pas encore assigné à un animal.");
      }
    } catch (err) {
      console.error(err);
      setError("Badge introuvable ou invalide.");
    } finally {
      setLoading(false);
    }
  };

  const captureAndRecordScan = (petId) => {
    const timestamp = new Date().toISOString();
    const deviceType = /Mobile|Android|iP(ad|hone|od)/.test(navigator.userAgent) ? 'mobile' : 'desktop';
    
    const recordScanFallback = async () => {
      try {
        await apiServerClient.fetch('/scans/record', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            badgeId,
            pet_id: petId,
            latitude: null,
            longitude: null,
            timestamp,
            deviceType,
            browser: navigator.userAgent.substring(0, 50)
          })
        });
        setLocationStatus('failed');
      } catch (e) {
        console.error('Failed to record fallback scan:', e);
      }
    };

    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          try {
            await apiServerClient.fetch('/scans/record', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                badgeId,
                pet_id: petId,
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                timestamp,
                deviceType,
                browser: navigator.userAgent.substring(0, 50)
              })
            });
            setLocationStatus('success');
            toast.success("Position enregistrée et notifiée au propriétaire.");
          } catch (e) {
            console.error('Failed to record scan with location:', e);
            setLocationStatus('failed');
          }
        },
        (geoError) => {
          console.warn("GPS Access Denied or unavailable:", geoError);
          recordScanFallback();
          toast.error("Impossible d'obtenir la position. Le propriétaire a été notifié du scan.");
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      recordScanFallback();
    }
  };

  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center rounded-3xl shadow-xl space-y-6">
          <Skeleton className="w-32 h-32 rounded-full mx-auto" />
          <Skeleton className="h-8 w-3/4 mx-auto" />
          <Skeleton className="h-4 w-1/2 mx-auto" />
          <div className="space-y-3 pt-6 border-t border-border">
            <Skeleton className="h-12 w-full rounded-xl" />
            <Skeleton className="h-12 w-full rounded-xl" />
          </div>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[100dvh] bg-muted/30 flex items-center justify-center p-4">
        <Helmet><title>Badge Invalide</title></Helmet>
        <Card className="w-full max-w-md p-8 text-center rounded-3xl shadow-xl border-t-4 border-t-destructive">
          <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Oups !</h1>
          <p className="text-muted-foreground mb-6">{error}</p>
          <Button asChild className="w-full">
            <Link to="/">Retour à l'accueil</Link>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-muted/30 py-12 px-4 flex flex-col items-center">
      <Helmet><title>Animal Trouvé : {petData.name}</title></Helmet>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md"
      >
        <Card className="rounded-3xl shadow-xl overflow-hidden bg-card border-0 ring-1 ring-border">
          <div className="bg-primary/5 p-8 text-center relative">
            <div className="absolute top-4 right-4">
              <Shield className="w-6 h-6 text-primary/40" />
            </div>
            
            {petData.photos && petData.photos.length > 0 ? (
              <img 
                src={pb.files.getUrl(petData, petData.photos[0])} 
                alt={`Photo de ${petData.name}`}
                className="w-40 h-40 object-cover rounded-full mx-auto border-4 border-background shadow-lg mb-6"
              />
            ) : (
              <div className="w-40 h-40 bg-background rounded-full mx-auto border-4 border-muted shadow-lg mb-6 flex items-center justify-center">
                <span className="text-5xl">🐾</span>
              </div>
            )}
            
            <h1 className="text-4xl font-extrabold tracking-tight text-foreground">{petData.name}</h1>
            <p className="text-lg text-muted-foreground mt-2 font-medium">
              {petData.type === 'dog' ? 'Chien' : petData.type === 'cat' ? 'Chat' : 'Animal'} 
              {petData.breed ? ` • ${petData.breed}` : ''}
            </p>
          </div>

          <div className="p-8 space-y-6">
            {locationStatus === 'pending' && (
              <div className="flex items-center justify-center gap-3 text-sm text-amber-600 bg-amber-50 p-4 rounded-xl">
                <Loader2 className="w-4 h-4 animate-spin" />
                <p>Acquisition de la position GPS pour alerter le propriétaire...</p>
              </div>
            )}

            {locationStatus === 'failed' && (
              <div className="flex items-center gap-3 text-sm text-destructive bg-destructive/10 p-4 rounded-xl">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <p>Position GPS refusée ou indisponible. Le propriétaire a été notifié du scan uniquement.</p>
              </div>
            )}

            {locationStatus === 'success' && (
              <div className="flex items-center gap-3 text-sm text-green-700 bg-green-50 p-4 rounded-xl">
                <MapPin className="w-5 h-5 shrink-0" />
                <p>Position transmise ! Le propriétaire sait où se trouve son animal.</p>
              </div>
            )}

            <div className="space-y-4 pt-2">
              <h3 className="font-semibold text-sm tracking-wider uppercase text-muted-foreground">Contact du propriétaire</h3>
              
              <div className="flex items-center gap-4 bg-muted/50 p-4 rounded-2xl">
                <div className="bg-background p-2.5 rounded-full shadow-sm">
                  <User className="w-5 h-5 text-foreground" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Propriétaire</p>
                  <p className="font-semibold text-foreground">{petData.owner_name}</p>
                </div>
              </div>

              <a 
                href={`tel:${petData.phone_number}`}
                className="flex items-center gap-4 bg-primary text-primary-foreground p-4 rounded-2xl hover:brightness-110 transition-all active:scale-[0.98] group shadow-md shadow-primary/20"
              >
                <div className="bg-primary-foreground/20 p-2.5 rounded-full">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm text-primary-foreground/80">Appeler maintenant</p>
                  <p className="font-bold text-lg">{petData.phone_number}</p>
                </div>
              </a>
            </div>

            {petData.personal_message && (
              <div className="pt-6 border-t border-border">
                <h3 className="font-semibold text-sm tracking-wider uppercase text-muted-foreground mb-3">Message médical / Notes</h3>
                <p className="text-foreground leading-relaxed p-4 bg-amber-50/50 border border-amber-100 rounded-2xl">
                  {petData.personal_message}
                </p>
              </div>
            )}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}