import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Save, ArrowLeft, Loader2, Search } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import PetPhotoUpload from '@/components/PetPhotoUpload.jsx';
import pb from '@/lib/pocketbaseClient';
import { generateCollarID, generateUniqueCollarID } from '@/utils/CollarIDGenerator.js';
import { toast } from 'sonner';

export default function PetProfileEditorPage() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const { currentUser } = useAuth();

  const isNew = location.pathname === '/pet/new' || id === 'new';
  const petId = isNew ? null : id;

  const [loading, setLoading] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [availableBadges, setAvailableBadges] = useState([]);
  const [fetchingBadges, setFetchingBadges] = useState(false);
  const [badgeSearch, setBadgeSearch] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    type: 'dog',
    breed: '',
    age: '',
    sex: 'unknown',
    owner_name: currentUser?.name || '',
    phone_number: '',
    adresse: '',
    ville: '',
    code_postal: '',
    hide_address: false,
    vet_name: '',
    vet_phone: '',
    vet_address: '',
    hide_vet_name: false,
    hide_vet_phone: false,
    hide_vet_address: false,
    personal_message: '',
    vaccination_status: 'unknown',
    sterilization_status: 'unknown',
    collar_id: '', // Will be generated on submit if empty
    badge_record_id: '' // Stores the actual record ID of the badge
  });
  const [photos, setPhotos] = useState([]);

  useEffect(() => {
    // Only fetch when currentUser is available to ensure authentication
    if (isNew && currentUser) {
      fetchAvailableBadges();
    } else if (currentUser && petId) {
      fetchPet();
    }
  }, [isNew, petId, currentUser]);

  const fetchAvailableBadges = async () => {
    if (!pb.authStore.isValid) return;
    
    setFetchingBadges(true);
    try {
      const records = await pb.collection('badges').getFullList({
        filter: 'status="available"',
        sort: '-created_at',
        $autoCancel: false
      });
      setAvailableBadges(records);
    } catch (error) {
      console.error('Failed to fetch badges. Details:', error.originalError || error);
      toast.error(`Erreur lors du chargement des badges disponibles: ${error.message}`);
    } finally {
      setFetchingBadges(false);
    }
  };

  const fetchPet = async () => {
    setIsFetching(true);
    try {
      const pet = await pb.collection('pets').getOne(petId, { $autoCancel: false });
      
      // Try to find the associated badge to display its ID
      let badgeRecordId = '';
      try {
        const badge = await pb.collection('badges').getFirstListItem(`pet_id="${pet.id}"`, { $autoCancel: false });
        badgeRecordId = badge.id;
        // Add it to available badges so it shows in the disabled select
        setAvailableBadges([badge]);
      } catch (e) {
        // Badge might not exist or not be linked properly, ignore
      }

      setFormData({
        name: pet.name || '',
        type: pet.type || 'dog',
        breed: pet.breed || '',
        age: pet.age ? String(pet.age) : '',
        sex: pet.sex || 'unknown',
        owner_name: pet.owner_name || '',
        phone_number: pet.phone_number || '',
        adresse: pet.adresse || '',
        ville: pet.ville || '',
        code_postal: pet.code_postal || '',
        hide_address: pet.hide_address || false,
        vet_name: pet.vet_name || '',
        vet_phone: pet.vet_phone || '',
        vet_address: pet.vet_address || '',
        hide_vet_name: pet.hide_vet_name || false,
        hide_vet_phone: pet.hide_vet_phone || false,
        hide_vet_address: pet.hide_vet_address || false,
        personal_message: pet.personal_message || '',
        vaccination_status: pet.vaccination_status || 'unknown',
        sterilization_status: pet.sterilization_status || 'unknown',
        collar_id: pet.collar_id || '',
        badge_record_id: badgeRecordId
      });
    } catch (error) {
      console.error('Failed to fetch pet:', error);
      toast.error('Échec du chargement de l\'animal');
      navigate('/dashboard');
    } finally {
      setIsFetching(false);
    }
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSelectChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!currentUser || !currentUser.id) {
      toast.error('Vous devez être connecté pour créer un profil d\'animal');
      navigate('/login');
      return;
    }

    if (!formData.name?.trim() || !formData.type || !formData.owner_name?.trim() || !formData.phone_number?.trim()) {
      toast.error('Veuillez remplir tous les champs obligatoires');
      return;
    }

    if (isNew && !formData.badge_record_id) {
      toast.error('Veuillez sélectionner un badge');
      return;
    }

    setLoading(true);

    try {
      if (isNew) {
        try {
          const badgeRecord = await pb.collection('badges').getOne(formData.badge_record_id, { $autoCancel: false });
          
          if (badgeRecord.status === 'used') {
            toast.error('Ce badge est déjà utilisé - veuillez en sélectionner un autre');
            setLoading(false);
            return;
          }
        } catch (error) {
          console.error('DEBUG: Error fetching badge:', error);
          if (error.status === 404) {
            toast.error('Badge introuvable - veuillez sélectionner parmi les badges disponibles');
          } else {
            toast.error('Erreur lors de la vérification du badge');
          }
          setLoading(false);
          return;
        }
      }

      const data = new FormData();
      data.append('owner_id', currentUser.id);

      // Ensure we pass the relation ID field explicitly expected by PocketBase schema
      if (formData.badge_record_id) {
        data.append('badge_id', formData.badge_record_id);
      }

      Object.keys(formData).forEach(key => {
        if (key === 'badge_record_id') return; // Handled above, don't pass this generic key
        
        if (key === 'age' && formData[key]) {
          const ageNum = parseFloat(formData[key]);
          if (!isNaN(ageNum)) {
            data.append(key, ageNum);
          }
        } else if (formData[key] !== null && formData[key] !== undefined && formData[key] !== '') {
          data.append(key, formData[key]);
        }
      });

      photos.forEach((photo) => {
        data.append('photos', photo);
      });

      let petRecord = null;

      if (isNew) {
        let petCreated = false;
        let attempts = 0;
        let currentCollarId = formData.collar_id || await generateUniqueCollarID(pb);

        while (!petCreated && attempts < 3) {
          try {
            data.set('collar_id', currentCollarId);
            petRecord = await pb.collection('pets').create(data, { $autoCancel: false });
            petCreated = true;
          } catch (err) {
            if (err.status === 400 && err.data?.data?.collar_id) {
              toast.error('ID de collier déjà existant - génération d\'un nouveau');
              currentCollarId = generateCollarID(); // Generate a fresh one for the next attempt
              attempts++;
            } else {
              throw err;
            }
          }
        }

        if (!petCreated) {
          throw new Error('Impossible de créer le profil après plusieurs tentatives.');
        }
        toast.success('Animal créé avec succès');
      } else {
        petRecord = await pb.collection('pets').update(petId, data, { $autoCancel: false });
        toast.success('Animal mis à jour avec succès');
      }

      // CRITICAL FIX: Update the badge record to save the correct database pet_id and mark it as 'used'
      if (formData.badge_record_id && petRecord && petRecord.id) {
        try {
          await pb.collection('badges').update(formData.badge_record_id, {
            pet_id: petRecord.id, // This uses the 15-character database ID correctly
            status: 'used'
          }, { $autoCancel: false });
        } catch (badgeErr) {
          console.error('Erreur lors de l\'association du badge:', badgeErr);
          toast.error('Le profil a été enregistré, mais l\'association du badge a échoué.');
        }
      }
      
      if (isNew) {
        navigate(`/pet/${petRecord.id}/preview`);
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      console.error('Submission error:', error);
      if (error.status === 400) {
        toast.error('Erreur de validation: Vérifiez tous les champs requis');
      } else {
        toast.error(`Erreur: ${error.message || 'Une erreur est survenue'}`);
      }
    } finally {
      setLoading(false);
    }
  };

  const filteredBadges = availableBadges.filter(badge => {
    // Always include the currently selected badge so the Select doesn't break
    if (badge.id === formData.badge_record_id) return true;
    if (!badgeSearch.trim()) return true;
    
    const searchTarget = `${badge.badge_code || ''} ${badge.badge_id || ''}`.toLowerCase();
    return searchTarget.includes(badgeSearch.toLowerCase());
  });

  if (isFetching && !isNew) {
    return (
      <>
        <Header />
        <div className="min-h-[100dvh] bg-background py-12">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <Skeleton className="h-10 w-48 mb-6" />
            <Card>
              <CardHeader>
                <Skeleton className="h-8 w-64" />
              </CardHeader>
              <CardContent className="space-y-6">
                <Skeleton className="h-32 w-full" />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-12 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${!isNew ? 'Modifier' : 'Ajouter'} un animal - Zoozen`}</title>
        <meta name="description" content="Créez ou modifiez le profil de votre animal avec Zoozen." />
      </Helmet>
      <Header />
      <div className="min-h-[100dvh] bg-slate-50 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" onClick={() => navigate('/dashboard')} className="mb-6 hover:bg-slate-200">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour au tableau de bord
          </Button>

          <Card className="shadow-lg border-slate-200">
            <CardHeader className="pb-4 border-b border-slate-100">
              <CardTitle className="text-2xl text-slate-900">
                {!isNew ? 'Modifier le profil' : 'Ajouter un animal'}
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Photos Section */}
                <div className="space-y-3">
                  <Label htmlFor="photos" className="block text-sm font-semibold text-slate-900">
                    Photos de l'animal
                  </Label>
                  <PetPhotoUpload 
                    photos={photos} 
                    onChange={setPhotos}
                    maxPhotos={currentUser?.subscription_plan === 'basique' ? 2 : 5}
                  />
                  <p className="block text-xs text-slate-500">
                    Jusqu'à {currentUser?.subscription_plan === 'basique' ? 2 : 5} photos (JPEG, PNG, GIF, WebP)
                  </p>
                </div>

                {/* Badge Selection Field */}
                <div className="space-y-4 bg-slate-100/50 p-5 rounded-xl border border-slate-200">
                  <div>
                    <Label className="block text-sm font-semibold text-slate-900 mb-2">
                      Sélection du Badge <span className="text-destructive">*</span>
                    </Label>
                    <p className="text-sm text-slate-600 mb-4">
                      {isNew ? "Associez un badge NFC/QR à cet animal pour l'identifier en cas de perte." : "Le badge ne peut pas être modifié une fois l'animal créé."}
                    </p>
                  </div>

                  {isNew && (
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                      <Input
                        placeholder="Search Badge Code (ex: ZOOZEN-...)"
                        value={badgeSearch}
                        onChange={(e) => setBadgeSearch(e.target.value)}
                        className="pl-9 bg-white"
                        disabled={fetchingBadges}
                      />
                    </div>
                  )}

                  <Select 
                    value={formData.badge_record_id} 
                    onValueChange={(value) => handleSelectChange('badge_record_id', value)}
                    disabled={!isNew || fetchingBadges}
                  >
                    <SelectTrigger id="badge_record_id" className="w-full bg-white">
                      <SelectValue placeholder={fetchingBadges ? "Chargement des badges..." : "Sélectionnez un badge"} />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredBadges.length === 0 && !fetchingBadges ? (
                        <SelectItem value="none" disabled>
                          {badgeSearch ? "Aucun badge correspondant trouvé" : "Aucun badge disponible"}
                        </SelectItem>
                      ) : (
                        filteredBadges.map((badge) => (
                          <SelectItem key={badge.id} value={badge.id}>
                            <span className="font-semibold">{badge.badge_code || badge.badge_id}</span>
                            <span className="text-slate-500 ml-2 text-xs">
                              ({badge.status === 'available' ? 'Disponible' : badge.status === 'sold' ? 'Vendu' : 'Utilisé'})
                            </span>
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {/* Basic Info Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="block text-sm font-semibold text-slate-900">
                      Nom de l'animal <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Ex: Milo, Bella, Rex"
                      required
                      className="w-full bg-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="type" className="block text-sm font-semibold text-slate-900">
                      Type d'animal <span className="text-destructive">*</span>
                    </Label>
                    <Select value={formData.type} onValueChange={(value) => handleSelectChange('type', value)}>
                      <SelectTrigger id="type" className="w-full bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dog">Chien</SelectItem>
                        <SelectItem value="cat">Chat</SelectItem>
                        <SelectItem value="rabbit">Lapin</SelectItem>
                        <SelectItem value="bird">Oiseau</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="breed" className="block text-sm font-semibold text-slate-900">
                      Race
                    </Label>
                    <Input
                      id="breed"
                      name="breed"
                      value={formData.breed}
                      onChange={handleChange}
                      placeholder="Ex: Labrador, Persan"
                      className="w-full bg-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="age" className="block text-sm font-semibold text-slate-900">
                      Âge
                    </Label>
                    <Input
                      id="age"
                      name="age"
                      type="text"
                      value={formData.age}
                      onChange={handleChange}
                      placeholder="Ex: 3 ans"
                      className="w-full bg-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="sex" className="block text-sm font-semibold text-slate-900">
                      Sexe
                    </Label>
                    <Select value={formData.sex} onValueChange={(value) => handleSelectChange('sex', value)}>
                      <SelectTrigger id="sex" className="w-full bg-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Mâle</SelectItem>
                        <SelectItem value="female">Femelle</SelectItem>
                        <SelectItem value="unknown">Inconnu</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Owner Info Section */}
                <div className="pt-8 border-t border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-5">
                    Informations sur le propriétaire
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="owner_name" className="block text-sm font-semibold text-slate-900">
                        Votre nom <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="owner_name"
                        name="owner_name"
                        value={formData.owner_name}
                        onChange={handleChange}
                        placeholder="Ex: Jean Dupont"
                        required
                        className="w-full bg-white"
                    />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone_number" className="block text-sm font-semibold text-slate-900">
                        Numéro de téléphone <span className="text-destructive">*</span>
                      </Label>
                      <Input
                        id="phone_number"
                        name="phone_number"
                        type="tel"
                        value={formData.phone_number}
                        onChange={handleChange}
                        placeholder="Ex: +33 6 12 34 56 78"
                        required
                        className="w-full bg-white"
                      />
                    </div>
                  </div>

                  <div className="space-y-4 mt-6">
                    <div className="space-y-2">
                      <Label htmlFor="adresse" className="block text-sm font-semibold text-slate-900">
                        Adresse
                      </Label>
                      <Input
                        id="adresse"
                        name="adresse"
                        value={formData.adresse}
                        onChange={handleChange}
                        placeholder="Ex: 123 Rue de la Paix"
                        className="w-full bg-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <Label htmlFor="code_postal" className="block text-sm font-semibold text-slate-900">
                          Code Postal
                        </Label>
                        <Input
                          id="code_postal"
                          name="code_postal"
                          value={formData.code_postal}
                          onChange={handleChange}
                          placeholder="Ex: 75000"
                          className="w-full bg-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ville" className="block text-sm font-semibold text-slate-900">
                          Ville
                        </Label>
                        <Input
                          id="ville"
                          name="ville"
                          value={formData.ville}
                          onChange={handleChange}
                          placeholder="Ex: Paris"
                          className="w-full bg-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 mt-6 bg-slate-50 p-4 rounded-lg">
                    <Switch
                      id="hide_address"
                      name="hide_address"
                      checked={formData.hide_address}
                      onCheckedChange={(checked) => handleSelectChange('hide_address', checked)}
                    />
                    <Label htmlFor="hide_address" className="text-sm font-medium text-slate-700 cursor-pointer">
                      Masquer l'adresse complète sur le profil public (seule la ville sera affichée)
                    </Label>
                  </div>
                </div>

                {/* Vet Info Section */}
                <div className="pt-8 border-t border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-2">
                    Vétérinaire traitant
                  </h3>
                  <p className="text-sm text-slate-500 mb-6">
                    Informations utiles en cas d'urgence médicale.
                  </p>

                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4 bg-slate-50 p-5 rounded-xl border border-slate-100">
                        <div className="space-y-2">
                          <Label htmlFor="vet_name" className="block text-sm font-semibold text-slate-900">Nom / Clinique</Label>
                          <Input
                            id="vet_name"
                            name="vet_name"
                            value={formData.vet_name}
                            onChange={handleChange}
                            placeholder="Ex: Dr. Martin"
                            className="bg-white"
                          />
                        </div>
                        <div className="flex items-center space-x-3 pt-2">
                          <Switch
                            id="hide_vet_name"
                            name="hide_vet_name"
                            checked={formData.hide_vet_name}
                            onCheckedChange={(checked) => handleSelectChange('hide_vet_name', checked)}
                          />
                          <Label htmlFor="hide_vet_name" className="text-sm font-medium text-slate-700 cursor-pointer">
                            Masquer sur le profil public
                          </Label>
                        </div>
                      </div>

                      <div className="space-y-4 bg-slate-50 p-5 rounded-xl border border-slate-100">
                        <div className="space-y-2">
                          <Label htmlFor="vet_phone" className="block text-sm font-semibold text-slate-900">Téléphone</Label>
                          <Input
                            id="vet_phone"
                            name="vet_phone"
                            type="tel"
                            value={formData.vet_phone}
                            onChange={handleChange}
                            placeholder="Ex: 01 23 45 67 89"
                            className="bg-white"
                          />
                        </div>
                        <div className="flex items-center space-x-3 pt-2">
                          <Switch
                            id="hide_vet_phone"
                            name="hide_vet_phone"
                            checked={formData.hide_vet_phone}
                            onCheckedChange={(checked) => handleSelectChange('hide_vet_phone', checked)}
                          />
                          <Label htmlFor="hide_vet_phone" className="text-sm font-medium text-slate-700 cursor-pointer">
                            Masquer sur le profil public
                          </Label>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4 bg-slate-50 p-5 rounded-xl border border-slate-100">
                      <div className="space-y-2">
                        <Label htmlFor="vet_address" className="block text-sm font-semibold text-slate-900">Adresse de la clinique</Label>
                        <Input
                          id="vet_address"
                          name="vet_address"
                          value={formData.vet_address}
                          onChange={handleChange}
                          placeholder="Ex: 10 Rue des Chiens, Paris"
                          className="bg-white"
                        />
                      </div>
                      <div className="flex items-center space-x-3 pt-2">
                        <Switch
                          id="hide_vet_address"
                          name="hide_vet_address"
                          checked={formData.hide_vet_address}
                          onCheckedChange={(checked) => handleSelectChange('hide_vet_address', checked)}
                        />
                        <Label htmlFor="hide_vet_address" className="text-sm font-medium text-slate-700 cursor-pointer">
                          Masquer sur le profil public
                        </Label>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Additional Info Section */}
                <div className="pt-8 border-t border-slate-200">
                  <h3 className="text-lg font-bold text-slate-900 mb-5">
                    Informations supplémentaires
                  </h3>
                  
                  <div className="space-y-2 mb-6">
                    <Label htmlFor="personal_message" className="block text-sm font-semibold text-slate-900">
                      Message personnel
                    </Label>
                    <Textarea
                      id="personal_message"
                      name="personal_message"
                      value={formData.personal_message}
                      onChange={handleChange}
                      rows={3}
                      placeholder="Ex: Animal très affectueux, a besoin de médicaments quotidiens..."
                      className="resize-none w-full bg-white"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="vaccination_status" className="block text-sm font-semibold text-slate-900">
                        Statut de vaccination
                      </Label>
                      <Select value={formData.vaccination_status} onValueChange={(value) => handleSelectChange('vaccination_status', value)}>
                        <SelectTrigger id="vaccination_status" className="w-full bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="up_to_date">À jour</SelectItem>
                          <SelectItem value="pending">En attente</SelectItem>
                          <SelectItem value="unknown">Inconnu</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="sterilization_status" className="block text-sm font-semibold text-slate-900">
                        Stérilisé/Castré
                      </Label>
                      <Select value={formData.sterilization_status} onValueChange={(value) => handleSelectChange('sterilization_status', value)}>
                        <SelectTrigger id="sterilization_status" className="w-full bg-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="yes">Oui</SelectItem>
                          <SelectItem value="no">Non</SelectItem>
                          <SelectItem value="unknown">Inconnu</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Submit Buttons */}
                <div className="flex gap-4 pt-8 border-t border-slate-200">
                  <Button type="submit" disabled={loading} className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Enregistrement...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        {!isNew ? 'Enregistrer les modifications' : 'Créer le profil'}
                      </>
                    )}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => navigate('/dashboard')} disabled={loading} className="bg-white hover:bg-slate-100">
                    Annuler
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </>
  );
}