import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import EmailNotificationForm from '@/components/EmailNotificationForm.jsx';

export default function MaintenancePage() {
  return (
    <>
      <Helmet>
        <title>Site en Maintenance - ToutouTag</title>
      </Helmet>
      
      <div className="relative min-h-[100dvh] flex flex-col items-center justify-center overflow-hidden bg-slate-950">
        {/* Background Image & Overlays */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1617451588899-7ac8679908c7"
            alt="Texture élégante sombre"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-slate-950/80 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-b from-slate-950/30 via-slate-950/60 to-slate-950/95" />
          {/* Subtle noise texture */}
          <div className="absolute inset-0 opacity-[0.03] mix-blend-soft-light pointer-events-none" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")' }}></div>
        </div>

        {/* Content */}
        <main className="relative z-10 container mx-auto px-4 py-16 flex flex-col items-center text-center max-w-4xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="flex flex-col items-center"
          >
            <div className="mb-8 inline-flex items-center rounded-full border border-white/10 bg-white/5 px-4 py-1.5 backdrop-blur-md shadow-sm">
              <span className="text-xs font-semibold uppercase tracking-[0.2em] text-white/80">
                Mise à jour en cours
              </span>
            </div>
            
            <h1 className="font-serif text-5xl md:text-6xl lg:text-7xl font-medium text-white tracking-tight mb-8 text-balance leading-tight">
              Site en Maintenance
            </h1>
            
            <p className="text-lg md:text-xl text-white/70 max-w-2xl text-balance leading-relaxed mb-6 font-light">
              Nous améliorons actuellement notre plateforme pour vous offrir une expérience encore plus exceptionnelle. Le site est temporairement indisponible.
            </p>
            
            <div className="inline-block border-b border-white/20 pb-1 mb-12">
              <p className="text-white/90 font-medium text-lg md:text-xl tracking-wide">
                Nous serons de retour le 25 avril 2026.
              </p>
            </div>

            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
              className="w-full max-w-2xl p-8 md:p-10 rounded-3xl bg-white/5 border border-white/10 backdrop-blur-md flex flex-col items-center shadow-2xl"
            >
              <h2 className="text-2xl font-serif font-medium text-white mb-3 text-balance">
                Restez informé
              </h2>
              <p className="text-base text-white/60 mb-2 text-balance">
                Laissez-nous votre email pour être prévenu dès notre retour en ligne.
              </p>
              
              <EmailNotificationForm />
            </motion.div>
          </motion.div>
        </main>
      </div>
    </>
  );
}