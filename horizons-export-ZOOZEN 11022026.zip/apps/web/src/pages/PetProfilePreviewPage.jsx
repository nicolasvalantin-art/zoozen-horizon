import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Edit, Phone, MapPin, Heart, Syringe, Scissors, Bell, Tag, Stethoscope } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient';
import { maskPhoneNumber } from '@/utils/PhoneNumberMasker.js';
import { toast } from 'sonner';

const petTypeTranslations = {
  dog: 'Chien',
  cat: 'Chat',
  rabbit: 'Lapin',
  bird: 'Oiseau',
  other: 'Autre'
};

export default function PetProfilePreviewPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [pet, setPet] = useState(null);
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [scansLoading, setScansLoading] = useState(true);
  
  // Ref to prevent duplicate fetches in React Strict Mode
  const fetchRef = useRef(false);

  useEffect(() => {
    console.log('🚀 PetProfilePreviewPage initialized: READ-ONLY mode active. ZERO mutations allowed.');

    if (!id || fetchRef.current) return;
    fetchRef.current = true;
    
    let isMounted = true;

    const loadPreviewData = async () => {
      try {
        setLoading(true);
        
        // 1. Fetch Pet Core Record (READ-ONLY: getOne) with owner expanded for privacy settings
        const petRecord = await pb.collection('pets').getOne(id, { 
          expand: 'owner_id',
          $autoCancel: false 
        });
        
        if (!isMounted) return;
        setPet(petRecord);

        // 2. Fetch related read-only data (Scans only)
        setScansLoading(true);
        try {
          const scansResult = await pb.collection('scans').getList(1, 10, {
            filter: `pet_id = "${petRecord.id}"`,
            sort: '-created',
            $autoCancel: false
          });
          if (isMounted) {
            setScans(scansResult.items);
          }
        } catch (scanError) {
          console.error('Safe Error - Scans fetch failed:', scanError);
          if (isMounted) setScans([]);
        }

      } catch (error) {
        console.error('Safe Error - Pet load failed:', error);
        if (isMounted) {
          toast.error('Échec du chargement du profil animal');
          navigate('/dashboard');
        }
      } finally {
        if (isMounted) {
          setLoading(false);
          setScansLoading(false);
        }
      }
    };

    loadPreviewData();

    return () => {
      isMounted = false;
    };
  }, [id, navigate]);

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen bg-background py-12">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <Skeleton className="h-10 w-32 mb-6" />
            <Card>
              <Skeleton className="aspect-square w-full" />
              <CardContent className="p-6 space-y-4">
                <Skeleton className="h-8 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-20 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  if (!pet) return null;

  // Use the correct PocketBase file URL method: pb.files.getURL (uppercase URL)
  const photoUrl = pet.photos && pet.photos.length > 0 
    ? pb.files.getURL(pet, pet.photos[0], { thumb: '800x800' })
    : null;

  const hasAddress = pet.adresse || pet.ville || pet.code_postal;
  
  // Check owner's phone visibility preference - Default to visible unless explicitly 'hidden'
  const phoneVisibility = pet.expand?.owner_id?.phone_visibility;
  const hasPhone = Boolean(pet.phone_number);
  const isPhoneVisible = phoneVisibility !== 'hidden';

  // Check vet visibility
  const showVetName = pet.vet_name && !pet.hide_vet_name;
  const showVetPhone = pet.vet_phone && !pet.hide_vet_phone;
  const showVetAddress = pet.vet_address && !pet.hide_vet_address;
  const hasVetInfo = showVetName || showVetPhone || showVetAddress;

  const handleCallClick = () => {
    window.location.href = `tel:${pet.phone_number}`;
  };
  
  const handleVetCallClick = () => {
    window.location.href = `tel:${pet.vet_phone}`;
  };

  return (
    <>
      <Helmet>
        <title>{`${pet.name || 'Animal'} - Aperçu - Zoozen`}</title>
        <meta name="description" content={`Aperçu du profil public de ${pet.name} sur Zoozen.`} />
      </Helmet>
      <Header />
      <div className="min-h-screen bg-background py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <Button variant="ghost" onClick={() => navigate('/dashboard')}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour au tableau de bord
            </Button>
            <Button asChild>
              <Link to={`/pet/${id}`}>
                <Edit className="w-4 h-4 mr-2" />
                Modifier le profil
              </Link>
            </Button>
          </div>

          <Card className="overflow-hidden shadow-lg rounded-2xl border-0 bg-card text-card-foreground">
            {/* Photo */}
            {photoUrl && (
              <div className="aspect-square bg-muted">
                <img 
                  src={photoUrl} 
                  alt={`Photo de ${pet.name}`}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            <CardContent className="p-6 space-y-8">
              {/* Header */}
              <div>
                <div className="flex items-start justify-between mb-2">
                  <h1 className="text-3xl font-bold">{pet.name}</h1>
                  <Badge variant="secondary" className="text-sm px-3 py-1">
                    {petTypeTranslations[pet.type] || pet.type}
                  </Badge>
                </div>
                {pet.breed && (
                  <p className="text-lg text-muted-foreground font-medium">{pet.breed}</p>
                )}
                {pet.age && (
                  <p className="text-muted-foreground">{pet.age} ans</p>
                )}
              </div>

              {/* Personal Message */}
              {pet.personal_message && (
                <div className="bg-primary/5 border border-primary/10 rounded-xl p-5">
                  <div className="flex items-start">
                    <Heart className="w-5 h-5 text-primary mr-3 flex-shrink-0 mt-0.5" />
                    <p className="text-sm leading-relaxed text-foreground/90">{pet.personal_message}</p>
                  </div>
                </div>
              )}

              {/* Contact Info */}
              <div className="space-y-4">
                <h2 className="font-semibold text-xl tracking-tight">Contacter le propriétaire</h2>
                
                {hasPhone && (
                  <div className="flex items-center text-muted-foreground bg-muted/50 p-3 rounded-lg">
                    <Phone className="w-5 h-5 mr-3 flex-shrink-0 text-foreground/70" />
                    <span className="font-mono text-foreground">
                      {isPhoneVisible ? pet.phone_number : maskPhoneNumber(pet.phone_number)}
                    </span>
                  </div>
                )}

                {hasAddress && !pet.hide_address && (
                  <div className="flex items-start text-muted-foreground bg-muted/50 p-3 rounded-lg">
                    <MapPin className="w-5 h-5 mr-3 flex-shrink-0 mt-0.5 text-foreground/70" />
                    <span className="text-foreground">
                      {[pet.adresse, pet.code_postal, pet.ville].filter(Boolean).join(', ')}
                    </span>
                  </div>
                )}
                
                {!hasPhone && (!hasAddress || pet.hide_address) && (
                  <p className="text-sm text-muted-foreground italic">
                    Les informations de contact ont été masquées par le propriétaire.
                  </p>
                )}

                {/* Contact Button - Only show when phone is visible */}
                {hasPhone && isPhoneVisible && (
                  <Button 
                    onClick={handleCallClick}
                    size="lg"
                    className="w-full mt-6 bg-primary text-primary-foreground hover:bg-primary/90 shadow-md transition-all active:scale-[0.98] h-12 text-base font-semibold"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    Contacter le propriétaire
                  </Button>
                )}
              </div>

              {/* Health Info */}
              {(pet.vaccination_status !== 'unknown' || pet.sterilization_status !== 'unknown') && (
                <div className="space-y-4 pt-6 border-t border-border/50">
                  <h2 className="font-semibold text-xl tracking-tight">Informations de santé</h2>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {pet.vaccination_status !== 'unknown' && (
                      <div className="flex items-center text-muted-foreground bg-muted/50 p-3 rounded-lg">
                        <Syringe className="w-5 h-5 mr-3 flex-shrink-0 text-foreground/70" />
                        <span className="text-foreground">
                          Vaccins : <span className="font-medium">{pet.vaccination_status === 'up_to_date' ? 'À jour' : 'En attente'}</span>
                        </span>
                      </div>
                    )}

                    {pet.sterilization_status !== 'unknown' && (
                      <div className="flex items-center text-muted-foreground bg-muted/50 p-3 rounded-lg">
                        <Scissors className="w-5 h-5 mr-3 flex-shrink-0 text-foreground/70" />
                        <span className="text-foreground">
                          Stérilisé : <span className="font-medium">{pet.sterilization_status === 'yes' ? 'Oui' : 'Non'}</span>
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Veterinarian Info */}
              {hasVetInfo && (
                <div className="space-y-4 pt-6 border-t border-border/50">
                  <h2 className="font-semibold text-xl tracking-tight flex items-center">
                    <Stethoscope className="w-5 h-5 mr-2 text-primary" />
                    Vétérinaire traitant
                  </h2>
                  
                  {(showVetName || showVetAddress) && (
                    <div className="space-y-3">
                      {showVetName && (
                        <div className="flex items-center text-muted-foreground bg-muted/50 p-3 rounded-lg">
                          <Stethoscope className="w-5 h-5 mr-3 flex-shrink-0 text-foreground/70" />
                          <span className="text-foreground font-medium">{pet.vet_name}</span>
                        </div>
                      )}
                      
                      {showVetAddress && (
                        <div className="flex items-start text-muted-foreground bg-muted/50 p-3 rounded-lg">
                          <MapPin className="w-5 h-5 mr-3 flex-shrink-0 mt-0.5 text-foreground/70" />
                          <span className="text-foreground">{pet.vet_address}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {showVetPhone && (
                    <Button 
                      onClick={handleVetCallClick}
                      size="lg"
                      variant="secondary"
                      className="w-full mt-6 bg-secondary text-secondary-foreground hover:bg-secondary/90 shadow-md transition-all active:scale-[0.98] h-12 text-base font-semibold"
                    >
                      <Phone className="w-5 h-5 mr-2" />
                      Contacter le vétérinaire
                    </Button>
                  )}
                </div>
              )}

              {/* Recent Scans */}
              <div className="pt-6 border-t border-border/50">
                <h2 className="font-semibold text-xl mb-4 flex items-center tracking-tight">
                  <Bell className="w-5 h-5 mr-2 text-primary" />
                  Scans récents
                </h2>
                
                {scansLoading ? (
                  <div className="space-y-3">
                    {[1, 2].map((i) => (
                      <Skeleton key={i} className="h-16 w-full rounded-xl" />
                    ))}
                  </div>
                ) : scans.length === 0 ? (
                  <div className="bg-muted/30 border border-dashed rounded-xl p-6 text-center">
                    <p className="text-muted-foreground text-sm">Aucun scan enregistré pour le moment</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {scans.map((scan) => (
                      <div key={scan.id} className="bg-muted/50 rounded-xl p-4 text-sm transition-colors hover:bg-muted/80">
                        <p className="font-medium text-foreground">
                          {new Date(scan.created).toLocaleString('fr-FR', {
                            month: 'long',
                            day: 'numeric',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                        {scan.scanner_location && (
                          <p className="text-muted-foreground mt-1 flex items-center">
                            <MapPin className="w-3 h-3 mr-1" />
                            {scan.scanner_location}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Identifiers */}
              <div className="pt-6 border-t border-border/50">
                <p className="text-sm font-medium text-muted-foreground mb-2 flex items-center">
                  <Tag className="w-4 h-4 mr-1.5" />
                  ID du Collier
                </p>
                <div className="bg-muted/50 px-4 py-2.5 rounded-lg inline-block">
                  <p className="font-mono text-lg font-semibold tracking-wider">{pet.collar_id}</p>
                </div>
              </div>

              {/* Preview Notice */}
              <div className="bg-secondary/50 rounded-xl p-4 mt-8">
                <p className="text-sm text-secondary-foreground/80 text-center">
                  Voici comment le profil de votre animal apparaîtra à toute personne qui scannera le code QR sur son collier. Cette page de prévisualisation est en lecture seule.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </>
  );
}