import React from 'react';
import { Helmet } from 'react-helmet';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

export default function PrivacyPolicyPage() {
  const lastUpdated = "21 Avril 2026";

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <Helmet>
        <title>Politique de Confidentialité | Zoozen</title>
        <meta name="description" content="Découvrez comment Zoozen protège vos données et votre vie privée." />
      </Helmet>

      <Header />

      <main className="flex-1 max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <article className="prose prose-slate dark:prose-invert prose-headings:font-bold prose-h1:text-4xl prose-h1:tracking-tight prose-a:text-primary max-w-none">
          <h1 className="mb-4">Politique de Confidentialité</h1>
          <p className="text-muted-foreground mb-8">Dernière mise à jour : {lastUpdated}</p>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">1. Introduction</h2>
            <p className="leading-relaxed">
              Chez Zoozen, nous prenons la confidentialité de vos données personnelles et celles de vos animaux très au sérieux. 
              Cette politique de confidentialité décrit quelles informations nous collectons, comment nous les utilisons, et quels sont vos droits concernant ces données lorsque vous utilisez notre site web, nos médailles connectées et nos services associés.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">2. Informations que nous collectons</h2>
            <p className="leading-relaxed">
              Nous collectons différentes catégories d'informations pour vous fournir nos services de manière optimale :
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Informations du compte :</strong> Nom, adresse e-mail, mot de passe, numéro de téléphone.</li>
              <li><strong>Informations sur l'animal :</strong> Nom, race, âge, photos, besoins médicaux, numéro de puce (optionnel).</li>
              <li><strong>Données de localisation :</strong> Lorsque la médaille QR de votre animal est scannée, nous enregistrons les coordonnées GPS (si le trouveur autorise le partage de sa position) pour vous notifier.</li>
              <li><strong>Informations de paiement :</strong> Gérées de manière sécurisée par nos prestataires tiers (Stripe) ; nous ne stockons pas les numéros de carte de crédit complets.</li>
            </ul>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">3. Comment nous utilisons les informations</h2>
            <p className="leading-relaxed">
              Les données que nous collectons sont utilisées exclusivement pour :
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>Faciliter la création et la gestion de vos profils d'animaux.</li>
              <li>Vous envoyer des alertes instantanées par e-mail ou SMS lorsqu'un animal est retrouvé et scanné.</li>
              <li>Gérer votre abonnement, la facturation et le support client.</li>
              <li>Améliorer la qualité de nos services et la sécurité de notre plateforme.</li>
            </ul>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">4. Sécurité des données</h2>
            <p className="leading-relaxed">
              Nous mettons en œuvre des mesures de sécurité techniques et organisationnelles conformes aux standards de l'industrie pour protéger vos données contre l'accès non autorisé, la modification, la divulgation ou la destruction. Cela inclut le chiffrement des données en transit et au repos, ainsi que des contrôles d'accès stricts.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">5. Partage des données</h2>
            <p className="leading-relaxed">
              Nous ne partageons vos données personnelles avec des tiers que dans les cas suivants :
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li><strong>Prestataires de services :</strong> Stripe pour les paiements, SendGrid pour les e-mails, Google Maps pour la localisation.</li>
              <li><strong>Conformité légale :</strong> Si la loi l'exige ou pour protéger nos droits légaux.</li>
              <li><strong>Consentement explicite :</strong> Uniquement si vous nous avez donné votre permission écrite.</li>
            </ul>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">6. Vos droits</h2>
            <p className="leading-relaxed">
              Conformément au Règlement Général sur la Protection des Données (RGPD), vous avez le droit de :
            </p>
            <ul className="list-disc pl-6 space-y-2 mt-4">
              <li>Accéder à vos données personnelles.</li>
              <li>Rectifier les données inexactes.</li>
              <li>Demander la suppression de vos données (droit à l'oubli).</li>
              <li>Limiter le traitement de vos données.</li>
              <li>Vous opposer au traitement de vos données.</li>
              <li>Demander la portabilité de vos données.</li>
            </ul>
            <p className="leading-relaxed mt-4">
              Pour exercer ces droits, veuillez nous contacter à contact@zoozen.com.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">7. Cookies et technologies de suivi</h2>
            <p className="leading-relaxed">
              Zoozen utilise des cookies essentiels pour maintenir votre session et améliorer votre expérience utilisateur. Nous n'utilisons pas de cookies de suivi publicitaire. Vous pouvez désactiver les cookies dans les paramètres de votre navigateur, mais cela peut affecter certaines fonctionnalités du site.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">8. Modifications de cette politique</h2>
            <p className="leading-relaxed">
              Nous nous réservons le droit de modifier cette politique de confidentialité à tout moment. Les modifications seront publiées sur cette page avec une date de mise à jour. Votre utilisation continue du service après les modifications constitue votre acceptation de la nouvelle politique.
            </p>
          </section>

          <section className="mb-10">
            <h2 className="text-2xl mt-8 mb-4">9. Contact</h2>
            <p className="leading-relaxed">
              Si vous avez des questions concernant cette politique de confidentialité ou nos pratiques en matière de protection des données, veuillez nous contacter :
            </p>
            <div className="bg-muted/50 p-6 rounded-xl mt-4 space-y-2">
              <p><strong>Zoozen</strong></p>
              <p>43 avenue Marceau Ginoux</p>
              <p>13330 Pélissanne, France</p>
              <p>E-mail : contact@zoozen.com</p>
              <p>Téléphone : +33 (0) 6 06 42 85 70</p>
            </div>
          </section>
        </article>
      </main>

      <Footer />
    </div>
  );
}