import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Shield, MapPin, Phone, User, AlertCircle, Loader2, CheckCircle2, Navigation, MessageSquare } from 'lucide-react';
import { MapContainer, TileLayer, Marker as LeafletMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
import iconRetina from 'leaflet/dist/images/marker-icon-2x.png';

import pb from '@/lib/pocketbaseClient';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import ScanNotificationModal from '@/components/ScanNotificationModal.jsx';

// Fix Leaflet's default icon path issues with bundlers
let DefaultIcon = L.icon({
  iconUrl: icon,
  iconRetinaUrl: iconRetina,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  tooltipAnchor: [16, -28],
  shadowSize: [41, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

export default function PublicQRScanPage() {
  const { badgeCode } = useParams();
  const [loading, setLoading] = useState(true);
  const [petData, setPetData] = useState(null);
  const [error, setError] = useState(null);
  const [locationStatus, setLocationStatus] = useState('loading'); // loading, success, denied, error
  const [coordinates, setCoordinates] = useState(null);
  const [notificationSent, setNotificationSent] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchBadgeData();
  }, [badgeCode]);

  const fetchBadgeData = async () => {
    try {
      const result = await pb.collection('badges').getOne(badgeCode, {
        expand: 'pet_id',
        $autoCancel: false
      });
      
      if (result.expand?.pet_id) {
        setPetData(result.expand.pet_id);
        requestGeolocation(result.expand.pet_id);
      } else {
        setError("Ce badge n'est pas encore assigné à un animal.");
        setLoading(false);
      }
    } catch (err) {
      console.error('Badge fetch error:', err);
      setError("Badge introuvable ou invalide. Veuillez vérifier le code.");
      setLoading(false);
    }
  };

  const requestGeolocation = (pet) => {
    setLocationStatus('loading');
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const coords = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
          setCoordinates(coords);
          setLocationStatus('success');
          setLoading(false);
          
          await createFoundNotification(pet.id, coords);
        },
        (geoError) => {
          console.warn('Geolocation denied or unavailable:', geoError);
          setLocationStatus('denied');
          setCoordinates(null);
          setLoading(false);
          toast.error("Impossible d'obtenir la position. Vous pouvez toujours contacter le propriétaire.");
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    } else {
      setLocationStatus('denied');
      setCoordinates(null);
      setLoading(false);
      toast.error("Géolocalisation non disponible sur cet appareil.");
    }
  };

  const createFoundNotification = async (petId, coords) => {
    if (!coords || coords.latitude === null || coords.longitude === null) return;
    
    try {
      const timestamp = new Date().toISOString();
      const address = `Scan automatique du badge ${badgeCode}`;
      
      await pb.collection('pet_found_notifications').create({
        petId: petId,
        latitude: coords.latitude,
        longitude: coords.longitude,
        address: address,
        timestamp: timestamp
      }, { $autoCancel: false });
      
      setNotificationSent(true);
      toast.success("Position partagée avec le propriétaire !");
    } catch (err) {
      console.error('Failed to create notification:', err);
      toast.error("Erreur lors de l'envoi de la notification automatique.");
    }
  };

  const retryGeolocation = () => {
    if (petData) {
      requestGeolocation(petData);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[100dvh] bg-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center rounded-3xl shadow-xl space-y-6">
          <Loader2 className="w-16 h-16 text-primary mx-auto animate-spin" />
          <div className="space-y-3">
            <Skeleton className="h-8 w-3/4 mx-auto" />
            <Skeleton className="h-4 w-1/2 mx-auto" />
          </div>
          <p className="text-sm text-muted-foreground">Chargement des informations...</p>
        </Card>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-[100dvh] bg-muted/30 flex items-center justify-center p-4">
        <Helmet><title>Badge Invalide</title></Helmet>
        <Card className="w-full max-w-md p-8 text-center rounded-3xl shadow-xl border-t-4 border-t-destructive">
          <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Badge invalide</h1>
          <p className="text-muted-foreground mb-6">{error}</p>
          <Button asChild className="w-full">
            <Link to="/">Retour à l'accueil</Link>
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] bg-muted/30 py-12 px-4">
      <Helmet><title>{`Animal Trouvé : ${petData.name}`}</title></Helmet>
      
      <div className="max-w-2xl mx-auto space-y-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="rounded-3xl shadow-xl overflow-hidden bg-card border-0 ring-1 ring-border">
            <div className="bg-primary/5 p-8 text-center relative">
              <div className="absolute top-4 right-4">
                <Shield className="w-6 h-6 text-primary/40" />
              </div>
              
              {petData.photos && petData.photos.length > 0 ? (
                <img 
                  src={pb.files.getUrl(petData, petData.photos[0])} 
                  alt={`Photo de ${petData.name}`}
                  className="w-40 h-40 object-cover rounded-full mx-auto border-4 border-background shadow-lg mb-6"
                />
              ) : (
                <div className="w-40 h-40 bg-background rounded-full mx-auto border-4 border-muted shadow-lg mb-6 flex items-center justify-center">
                  <span className="text-5xl">🐾</span>
                </div>
              )}
              
              <h1 className="text-4xl font-extrabold tracking-tight text-foreground">{petData.name}</h1>
              <p className="text-lg text-muted-foreground mt-2 font-medium">
                {petData.type === 'dog' ? 'Chien' : petData.type === 'cat' ? 'Chat' : 'Animal'} 
                {petData.breed ? ` • ${petData.breed}` : ''}
              </p>
            </div>

            <div className="p-8 space-y-6">
              {locationStatus === 'loading' && (
                <div className="flex items-center justify-center gap-3 text-sm text-amber-600 bg-amber-50 p-4 rounded-xl">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <p>Acquisition de votre position GPS...</p>
                </div>
              )}

              {locationStatus === 'denied' && (
                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-sm text-destructive bg-destructive/10 p-4 rounded-xl">
                    <AlertCircle className="w-5 h-5 shrink-0" />
                    <p>Position GPS refusée ou indisponible. Vous pouvez toujours contacter le propriétaire directement.</p>
                  </div>
                  <Button 
                    onClick={retryGeolocation}
                    variant="outline"
                    className="w-full"
                  >
                    <Navigation className="w-4 h-4 mr-2" />
                    Réessayer la géolocalisation
                  </Button>
                </div>
              )}

              {locationStatus === 'success' && notificationSent && (
                <div className="flex items-center gap-3 text-sm text-green-700 bg-green-50 p-4 rounded-xl">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <div>
                    <p className="font-semibold">Position partagée avec succès !</p>
                    <p className="text-green-600 mt-1">Le propriétaire a été notifié de votre position.</p>
                  </div>
                </div>
              )}

              <div className="space-y-4 pt-2">
                <h3 className="font-semibold text-sm tracking-wider uppercase text-muted-foreground">Contact du propriétaire</h3>
                
                <div className="flex items-center gap-4 bg-muted/50 p-4 rounded-2xl">
                  <div className="bg-background p-2.5 rounded-full shadow-sm">
                    <User className="w-5 h-5 text-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Propriétaire</p>
                    <p className="font-semibold text-foreground">{petData.owner_name}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <a 
                    href={`tel:${petData.phone_number}`}
                    className="flex items-center justify-center gap-3 bg-primary text-primary-foreground p-4 rounded-2xl hover:brightness-110 transition-all active:scale-[0.98] shadow-md shadow-primary/20"
                  >
                    <Phone className="w-5 h-5" />
                    <span className="font-bold">Appeler</span>
                  </a>
                  
                  <Button 
                    onClick={() => setIsModalOpen(true)}
                    variant="secondary"
                    className="h-auto p-4 rounded-2xl flex items-center justify-center gap-3 text-base"
                    disabled={locationStatus === 'loading'}
                  >
                    <MessageSquare className="w-5 h-5" />
                    <span className="font-bold">Envoyer un message</span>
                  </Button>
                </div>
              </div>

              {petData.personal_message && (
                <div className="pt-6 border-t border-border">
                  <h3 className="font-semibold text-sm tracking-wider uppercase text-muted-foreground mb-3">Message médical / Notes</h3>
                  <p className="text-foreground leading-relaxed p-4 bg-amber-50/50 border border-amber-100 rounded-2xl">
                    {petData.personal_message}
                  </p>
                </div>
              )}
            </div>
          </Card>
        </motion.div>

        {locationStatus === 'success' && coordinates && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="rounded-3xl shadow-xl overflow-hidden p-6">
              <div className="flex items-center gap-3 mb-4">
                <MapPin className="w-6 h-6 text-primary" />
                <div>
                  <h2 className="text-xl font-bold">Position de la découverte</h2>
                </div>
              </div>
              
              <div className="rounded-2xl overflow-hidden shadow-inner border border-border">
                <MapContainer 
                  center={[coordinates.latitude, coordinates.longitude]} 
                  zoom={15} 
                  scrollWheelZoom={true}
                  style={{ width: '100%', height: '400px' }}
                >
                  <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  />
                  <LeafletMarker position={[coordinates.latitude, coordinates.longitude]}>
                    <Popup>
                      {petData.name} a été trouvé(e) ici.
                    </Popup>
                  </LeafletMarker>
                </MapContainer>
              </div>
            </Card>
          </motion.div>
        )}
      </div>

      {petData && (
        <ScanNotificationModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)} 
          petId={petData.id} 
          petName={petData.name}
          initialLat={coordinates?.latitude || null}
          initialLng={coordinates?.longitude || null}
        />
      )}
    </div>
  );
}