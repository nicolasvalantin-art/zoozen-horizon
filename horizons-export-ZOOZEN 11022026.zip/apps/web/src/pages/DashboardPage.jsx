import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Crown, Calendar, Settings, Shield, User, Smartphone, Eye, EyeOff, Plus, AlertCircle, RefreshCw, Dog } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import pb from '@/lib/pocketbaseClient';
import PetCard from '@/components/PetCard.jsx';

export default function DashboardPage() {
  const { currentUser, refreshUser } = useAuth();
  const [updatingPhone, setUpdatingPhone] = useState(false);
  const [phoneVisibility, setPhoneVisibility] = useState(currentUser?.phone_visibility || 'visible');
  
  // Pets state
  const [pets, setPets] = useState([]);
  const [loadingPets, setLoadingPets] = useState(true);
  const [errorPets, setErrorPets] = useState(null);

  // Subscription Details mapping
  const getPlanDetails = (planType) => {
    switch(planType) {
      case 'premium': return { name: 'Premium', price: '14,99 €/mois' };
      case 'standard': return { name: 'Standard', price: '7,99 €/mois' };
      case 'basique': 
      default: return { name: 'Basique', price: 'Gratuit' };
    }
  };

  const planDetails = getPlanDetails(currentUser?.subscription_plan);
  const isPremium = currentUser?.subscription_plan === 'premium';

  // Fetch Pets
  const fetchPets = useCallback(async () => {
    if (!currentUser) return;
    setLoadingPets(true);
    setErrorPets(null);
    try {
      const records = await pb.collection('pets').getList(1, 50, {
        filter: `owner_id="${currentUser.id}"`,
        sort: '-created',
        $autoCancel: false
      });
      setPets(records.items);
    } catch (err) {
      console.error('Failed to fetch pets:', err);
      setErrorPets('Impossible de charger vos animaux. Veuillez réessayer.');
    } finally {
      setLoadingPets(false);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchPets();
  }, [fetchPets]);

  // Delete Pet Handler
  const handleDeletePet = async (petId) => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer ce profil ? Cette action est irréversible.')) {
      return;
    }
    
    try {
      await pb.collection('pets').delete(petId, { $autoCancel: false });
      setPets(prev => prev.filter(p => p.id !== petId));
      toast.success('Profil supprimé avec succès');
    } catch (err) {
      console.error('Failed to delete pet:', err);
      toast.error('Erreur lors de la suppression du profil');
    }
  };

  // Toggle Handler
  const handlePhoneVisibilityToggle = async (checked) => {
    const newValue = checked ? 'visible' : 'hidden';
    setPhoneVisibility(newValue);
    setUpdatingPhone(true);

    try {
      await pb.collection('users').update(currentUser.id, {
        phone_visibility: newValue
      }, { $autoCancel: false });
      
      await refreshUser();
      toast.success(newValue === 'visible' 
        ? 'Votre numéro est maintenant public.' 
        : 'Votre numéro est désormais masqué.'
      );
    } catch (error) {
      console.error('Update failed:', error);
      toast.error('Erreur lors de la mise à jour de la visibilité.');
      setPhoneVisibility(currentUser?.phone_visibility || 'visible'); // Revert
    } finally {
      setUpdatingPhone(false);
    }
  };

  // Helper for dates
  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('fr-FR', {
      year: 'numeric', month: 'long', day: 'numeric'
    });
  };

  return (
    <>
      <Helmet>
        <title>Tableau de bord - Zoozen</title>
      </Helmet>
      <Header />
      <main className="min-h-screen bg-background py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight text-foreground">
              Tableau de bord
            </h1>
            <p className="text-muted-foreground mt-2">
              Gérez votre compte, vos animaux et vos préférences de confidentialité.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column: User Profile & Privacy */}
            <div className="space-y-8 lg:col-span-1">
              
              {/* User Profile Card */}
              <Card className="shadow-sm border-border/50">
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <User className="w-5 h-5 mr-2 text-primary" />
                    Profil Utilisateur
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Avatar className="w-16 h-16 rounded-xl border-2 border-background shadow-sm">
                      <AvatarImage src={currentUser?.avatar ? pb.files.getURL(currentUser, currentUser.avatar) : ''} />
                      <AvatarFallback className="rounded-xl bg-primary/10 text-primary font-bold text-lg">
                        {currentUser?.name?.charAt(0).toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold text-lg">{currentUser?.name}</p>
                      <p className="text-sm text-muted-foreground">{currentUser?.email}</p>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full" asChild>
                    <Link to="/settings">
                      <Settings className="w-4 h-4 mr-2" />
                      Modifier le profil
                    </Link>
                  </Button>
                </CardContent>
              </Card>

              {/* Number Visibility Toggle */}
              <Card className="shadow-sm border-border/50 bg-secondary/10">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center text-xl">
                    <Shield className="w-5 h-5 mr-2 text-secondary-foreground" />
                    Confidentialité
                  </CardTitle>
                  <CardDescription>
                    Contrôlez qui peut voir vos coordonnées.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-background border rounded-xl flex items-start justify-between">
                    <div className="space-y-1 pr-4">
                      <Label htmlFor="phone-visibility" className="text-base font-semibold cursor-pointer">
                        Numéro de téléphone
                      </Label>
                      <p className="text-sm text-muted-foreground flex items-center">
                        {phoneVisibility === 'visible' ? (
                          <><Eye className="w-4 h-4 mr-1" /> Visible aux personnes scannant</>
                        ) : (
                          <><EyeOff className="w-4 h-4 mr-1" /> Masqué au public</>
                        )}
                      </p>
                    </div>
                    <div className="pt-1">
                      <Switch 
                        id="phone-visibility"
                        checked={phoneVisibility === 'visible'} 
                        onCheckedChange={handlePhoneVisibilityToggle}
                        disabled={updatingPhone}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

            </div>

            {/* Right Column: Subscription & Actions */}
            <div className="space-y-8 lg:col-span-2">
              
              {/* Subscription Status Card */}
              <Card className="shadow-sm border-border/50 relative overflow-hidden">
                {isPremium && (
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-bl-full -z-10" />
                )}
                <CardHeader>
                  <CardTitle className="flex items-center text-xl justify-between">
                    <div className="flex items-center">
                      <Crown className={`w-5 h-5 mr-2 ${isPremium ? 'text-primary' : 'text-muted-foreground'}`} />
                      Statut de l'abonnement
                    </div>
                    <Badge variant={currentUser?.subscription_status === 'active' ? 'default' : 'secondary'} className="uppercase">
                      {currentUser?.subscription_status || 'Inactif'}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Forfait Actuel</p>
                        <p className="text-2xl font-bold">{planDetails.name}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-muted-foreground">Prix</p>
                        <p className="text-lg">{planDetails.price}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <p className="text-sm font-medium text-muted-foreground flex items-center">
                          <Calendar className="w-4 h-4 mr-1" /> Date de renouvellement
                        </p>
                        <p className="text-lg">
                          {currentUser?.subscription_end_date 
                            ? formatDate(currentUser.subscription_end_date) 
                            : 'Aucune facturation prévue'}
                        </p>
                      </div>
                      <div className="pt-2">
                        <Button variant={isPremium ? "outline" : "default"} asChild>
                          <Link to="/plans">
                            {isPremium ? 'Gérer mon forfait' : 'Améliorer mon forfait'}
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Card className="shadow-sm hover:shadow-md transition-shadow bg-card hover:border-primary/50 group">
                  <Link to="/pet/new" className="block p-6">
                    <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <Smartphone className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-lg mb-1">Ajouter un animal</h3>
                    <p className="text-sm text-muted-foreground">Créez un nouveau profil numérique pour votre compagnon.</p>
                  </Link>
                </Card>
                <Card className="shadow-sm hover:shadow-md transition-shadow bg-card hover:border-primary/50 group">
                  <Link to="/settings" className="block p-6">
                    <div className="w-12 h-12 rounded-xl bg-secondary/10 text-secondary-foreground flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                      <Shield className="w-6 h-6" />
                    </div>
                    <h3 className="font-semibold text-lg mb-1">Paramètres du compte</h3>
                    <p className="text-sm text-muted-foreground">Gérez vos mots de passe, emails et notifications.</p>
                  </Link>
                </Card>
              </div>

            </div>
          </div>

          {/* Pets Section */}
          <div className="mt-16">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold tracking-tight text-foreground">Mes Animaux</h2>
                <p className="text-muted-foreground mt-1">Gérez les profils de vos compagnons</p>
              </div>
              <Button asChild>
                <Link to="/pet/new">
                  <Plus className="w-4 h-4 mr-2" />
                  Ajouter
                </Link>
              </Button>
            </div>

            {loadingPets ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-[320px] w-full rounded-2xl" />
                ))}
              </div>
            ) : errorPets ? (
              <div className="bg-destructive/10 border border-destructive/20 rounded-2xl p-8 text-center flex flex-col items-center">
                <AlertCircle className="w-10 h-10 text-destructive mb-3" />
                <p className="text-destructive font-medium mb-4">{errorPets}</p>
                <Button variant="outline" onClick={fetchPets}>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Réessayer
                </Button>
              </div>
            ) : pets.length === 0 ? (
              <div className="bg-muted/30 border border-dashed border-border rounded-2xl p-12 text-center flex flex-col items-center">
                <div className="w-16 h-16 bg-background rounded-full flex items-center justify-center mb-4 shadow-sm">
                  <Dog className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Aucun animal enregistré</h3>
                <p className="text-muted-foreground mb-6 max-w-md">
                  Vous n'avez pas encore ajouté d'animal à votre profil. Créez un profil pour votre compagnon pour le protéger dès maintenant.
                </p>
                <Button asChild>
                  <Link to="/pet/new">
                    <Plus className="w-4 h-4 mr-2" />
                    Ajouter mon premier animal
                  </Link>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {pets.map((pet) => (
                  <PetCard 
                    key={pet.id} 
                    pet={pet} 
                    onDelete={handleDeletePet} 
                  />
                ))}
              </div>
            )}
          </div>

        </div>
      </main>
      <Footer />
    </>
  );
}