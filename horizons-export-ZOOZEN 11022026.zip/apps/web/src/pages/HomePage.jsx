import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { QrCode, Bell, Shield, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import PlanCard from '@/components/PlanCard.jsx';
import ProductAdvantagesSection from '@/components/ProductAdvantagesSection.jsx';
import { plansData } from '@/data/plans.js';

export default function HomePage() {
  const features = [{
    icon: QrCode,
    title: 'Profil QR unique',
    description: 'Chaque animal reçoit un code QR unique lié à son profil complet avec photos et informations de contact.'
  }, {
    icon: Bell,
    title: 'Alertes instantanées',
    description: 'Recevez une notification immédiate dès que quelqu\'un scanne le code QR de votre animal perdu.'
  }, {
    icon: Shield,
    title: 'Données sécurisées',
    description: 'Vos informations personnelles sont protégées et ne sont partagées qu\'en cas de nécessité.'
  }];
  
  const steps = [{
    number: '01',
    title: 'Recevez votre badge',
    description: 'Attachez votre badge Zoozen au collier de votre animal. N\'importe qui peut le scanner avec son téléphone.',
    image: 'https://images.unsplash.com/photo-1695392158511-e293ed316d2c',
    imageAlt: 'Médaille d\'identification pour animal attachée à un collier'
  }, {
    number: '02',
    title: 'Créer votre profil',
    description: 'Inscrivez-vous et ajoutez les informations de votre animal avec des photos.',
    image: 'https://images.unsplash.com/photo-1690366063816-3231aa40343a',
    imageAlt: 'Interface de création de profil pour animal de compagnie sur smartphone'
  }, {
    number: '03',
    title: 'Restez connecté',
    description: 'Si votre animal se perd, vous serez alerté instantanément quand quelqu\'un scanne son code.',
    image: 'https://images.unsplash.com/photo-1643101807331-21a4a3f081d5',
    imageAlt: 'Personne recevant une notification sur son téléphone portable en extérieur'
  }];

  return (
    <>
      <Helmet>
        <title>Zoozen - Protégez vos animaux avec des codes QR intelligents</title>
        <meta name="description" content="Zoozen vous aide à retrouver vos animaux perdus grâce à des codes QR uniques et des alertes instantanées." />
      </Helmet>
      <Header />
      
      {/* Hero Section */}
      <section className="relative min-h-[100dvh] flex items-center justify-center bg-gradient-to-br from-primary/5 via-background to-secondary/5 overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,hsl(var(--primary)/0.1),transparent_50%),radial-gradient(circle_at_70%_80%,hsl(var(--secondary)/0.1),transparent_50%)]" />
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight mb-6 text-balance" style={{ letterSpacing: '-0.02em' }}>
              Ne perdez plus jamais<br />vos compagnons à quatre pattes
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed">
              Zoozen utilise des codes QR intelligents pour vous aider à retrouver vos animaux perdus en quelques minutes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="text-base">
                <Link to="/signup">
                  Commencer gratuitement
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg" className="text-base">
                <Link to="/plans">Voir les forfaits</Link>
              </Button>
            </div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, y: 40 }} 
            animate={{ opacity: 1, y: 0 }} 
            transition={{ duration: 0.6, delay: 0.2 }} 
            className="mt-16"
          >
            <div className="relative max-w-4xl mx-auto">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 blur-3xl rounded-full" />
              <img 
                src="https://horizons-cdn.hostinger.com/47c25bd4-6f6e-46b5-8c91-5800b9b716a9/labrador-yorkshire01-KTZWs.jpg" 
                alt="Chien heureux avec son propriétaire dans un parc ensoleillé" 
                className="relative rounded-2xl shadow-2xl w-full" 
              />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            whileInView={{ opacity: 1, y: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.5 }} 
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
              Pourquoi choisir Zoozen
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Une solution complète pour la sécurité de vos animaux de compagnie
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {features.map((feature, index) => (
              <motion.div 
                key={index} 
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }} 
                whileInView={{ opacity: 1, x: 0 }} 
                viewport={{ once: true }} 
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-8">
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-primary/10 rounded-xl">
                        <feature.icon className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold text-foreground mb-2">
                          {feature.title}
                        </h3>
                        <p className="text-muted-foreground leading-relaxed">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Product Advantages Section */}
      <ProductAdvantagesSection />

      {/* How It Works Section */}
      <section className="py-24 bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            whileInView={{ opacity: 1, y: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.5 }} 
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
              Comment ça marche
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Trois étapes simples pour protéger votre animal
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {steps.map((step, index) => (
              <motion.div 
                key={index} 
                initial={{ opacity: 0, y: 20 }} 
                whileInView={{ opacity: 1, y: 0 }} 
                viewport={{ once: true }} 
                transition={{ duration: 0.5, delay: index * 0.1 }} 
                className="relative flex flex-col items-center"
              >
                {/* Connecting Line (Hidden on Mobile) */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-8 left-[50%] w-full h-0.5 bg-border -z-0" />
                )}

                {/* Step Number */}
                <div className="relative z-10 inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground text-2xl font-bold mb-8 shadow-md ring-8 ring-muted/30">
                  {step.number}
                </div>

                {/* Step Card with Image */}
                <Card className="w-full h-full overflow-hidden border-none shadow-md hover:shadow-xl transition-all duration-300 group flex flex-col">
                  <div className="relative h-48 overflow-hidden bg-muted w-full shrink-0">
                    <img 
                      src={step.image} 
                      alt={step.imageAlt} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  </div>
                  <CardContent className="p-6 text-center flex-1 flex flex-col justify-center">
                    <h3 className="text-xl font-semibold text-foreground mb-3">
                      {step.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-24 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            whileInView={{ opacity: 1, y: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.5 }} 
            className="text-center mb-16"
          >
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
              Choisissez votre forfait
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Des plans adaptés à tous les besoins
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch">
            {plansData.map((plan, index) => (
              <motion.div 
                key={plan.id} 
                initial={{ opacity: 0, y: 20 }} 
                whileInView={{ opacity: 1, y: 0 }} 
                viewport={{ once: true }} 
                transition={{ duration: 0.5, delay: index * 0.1 }} 
                className="h-full"
              >
                <PlanCard 
                  plan={plan} 
                  isRecommended={index === 1} 
                  renderCheckout={() => (
                    <Button asChild className="w-full" variant={index === 1 ? 'default' : 'outline'}>
                      <Link to="/plans">Voir les forfaits</Link>
                    </Button>
                  )} 
                />
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }} 
            whileInView={{ opacity: 1, y: 0 }} 
            viewport={{ once: true }} 
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-6 text-balance">
              Prêt à protéger votre animal
            </h2>
            <p className="text-lg mb-8 opacity-90 leading-relaxed max-w-2xl mx-auto">
              Rejoignez des milliers de propriétaires qui ont déjà sécurisé leurs compagnons avec Zoozen
            </p>
            <Button asChild size="lg" variant="secondary" className="text-base">
              <Link to="/signup">
                Créer mon compte gratuitement
                <ArrowRight className="ml-2 w-5 h-5" />
              </Link>
            </Button>
          </motion.div>
        </div>
      </section>

      <Footer />
    </>
  );
}