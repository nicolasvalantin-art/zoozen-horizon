import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useJsApiLoader, GoogleMap, Marker } from '@react-google-maps/api';
import { Shield, ArrowLeft, Activity, Map, Lock, Crown } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';
import apiServerClient from '@/lib/apiServerClient';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ScanHistoryList from '@/components/ScanHistoryList.jsx';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

const mapContainerStyle = {
  width: '100%',
  height: '400px',
  borderRadius: '0.75rem'
};

const center = { lat: 46.2276, lng: 2.2137 }; // Default France center

export default function OwnerBadgeDashboard() {
  const { badgeId } = useParams();
  const { getSubscriptionTier, currentUser } = useAuth();
  const tier = getSubscriptionTier();
  
  const [badgeData, setBadgeData] = useState(null);
  const [scans, setScans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedScan, setSelectedScan] = useState(null);

  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  });

  useEffect(() => {
    fetchData();
  }, [badgeId]);

  const fetchData = async () => {
    setLoading(true);
    try {
      // 1. Fetch Badge + Pet
      const badge = await pb.collection('badges').getFirstListItem(`badge_id="${badgeId}"`, {
        expand: 'pet_id',
        $autoCancel: false
      });
      
      // Ensure current user owns the pet
      if (badge.expand?.pet_id?.owner_id !== currentUser?.id) {
        throw new Error("Unauthorized");
      }
      setBadgeData(badge);

      // 2. Fetch Scans via API Server
      try {
        const response = await apiServerClient.fetch(`/scans/${badgeId}`);
        if (response.ok) {
          const scanData = await response.json();
          // Assuming API returns array directly based on instructions
          setScans(Array.isArray(scanData) ? scanData : []);
        }
      } catch (apiErr) {
        console.error("Failed to fetch scans via API, falling back to SDK if possible", apiErr);
      }

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const mapCenter = scans.length > 0 && scans[0].latitude 
    ? { lat: scans[0].latitude, lng: scans[0].longitude }
    : center;

  if (loading) {
    return (
      <div className="min-h-screen bg-muted/10">
        <Header />
        <main className="max-w-7xl mx-auto px-4 py-12">
          <Skeleton className="h-8 w-64 mb-8" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <Skeleton className="h-[400px] w-full rounded-2xl" />
            </div>
            <div className="space-y-6">
              <Skeleton className="h-48 w-full rounded-2xl" />
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!badgeData) {
    return (
      <div className="min-h-screen bg-muted/10">
        <Header />
        <main className="max-w-3xl mx-auto px-4 py-24 text-center">
          <Shield className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
          <h1 className="text-2xl font-bold mb-2">Badge introuvable</h1>
          <p className="text-muted-foreground mb-8">Ce badge ne vous appartient pas ou n'existe pas.</p>
          <Button asChild>
            <Link to="/dashboard">Retour au tableau de bord</Link>
          </Button>
        </main>
      </div>
    );
  }

  const petName = badgeData.expand?.pet_id?.name || 'Votre animal';

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <Helmet><title>Activité du badge : {petName} - Zoozen</title></Helmet>
      <Header />
      
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 w-full">
        <div className="mb-8">
          <Link to="/dashboard" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-6">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Retour à mes animaux
          </Link>
          
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-balance">Activité du badge <span className="text-primary">{badgeData.badge_id}</span></h1>
              <p className="text-muted-foreground mt-2 text-lg">Assigné à {petName}</p>
            </div>
            
            <div className="flex items-center gap-2 bg-muted/50 px-4 py-2 rounded-xl">
              <Activity className="w-5 h-5 text-primary" />
              <span className="font-semibold">{scans.length} scans au total</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Map Content */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-card border border-border shadow-sm rounded-2xl p-2 relative overflow-hidden">
              {isLoaded ? (
                <GoogleMap
                  mapContainerStyle={mapContainerStyle}
                  center={mapCenter}
                  zoom={scans.length > 0 ? 14 : 5}
                  options={{
                    disableDefaultUI: false,
                    zoomControl: true,
                    mapTypeControl: false,
                    streetViewControl: false,
                  }}
                >
                  {scans.map((scan) => (
                    scan.latitude && scan.longitude && (
                      <Marker
                        key={scan.id}
                        position={{ lat: scan.latitude, lng: scan.longitude }}
                        onClick={() => setSelectedScan(scan)}
                      />
                    )
                  ))}
                </GoogleMap>
              ) : (
                <div className="w-full h-[400px] flex items-center justify-center bg-muted/20 rounded-xl">
                  <p className="text-muted-foreground flex items-center gap-2">
                    <Map className="w-5 h-5" /> Chargement de la carte...
                  </p>
                </div>
              )}
              
              {tier === 'free' && (
                <div className="absolute inset-x-0 bottom-0 p-6 bg-gradient-to-t from-background via-background/90 to-transparent flex flex-col items-center justify-end h-48 text-center">
                  <div className="bg-background/95 backdrop-blur-sm border border-border p-4 rounded-2xl shadow-lg max-w-md mx-auto">
                    <Crown className="w-6 h-6 text-amber-500 mx-auto mb-2" />
                    <h3 className="font-semibold mb-1">Passez à la version Premium</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Débloquez l'historique complet, les heures précises et les alertes instantanées.
                    </p>
                    <Button asChild size="sm" className="w-full bg-amber-500 hover:bg-amber-600 text-white">
                      <Link to="/subscription">Voir les offres</Link>
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {/* History List - Premium Only */}
            {tier === 'premium' ? (
              <ScanHistoryList scans={scans} />
            ) : (
              <div className="bg-muted/20 border border-dashed border-border rounded-2xl p-8 text-center flex flex-col items-center">
                <Lock className="w-10 h-10 text-muted-foreground/40 mb-3" />
                <h3 className="font-semibold text-foreground">Historique détaillé verrouillé</h3>
                <p className="text-sm text-muted-foreground mt-1 max-w-sm mx-auto">
                  Votre abonnement gratuit vous permet de voir la dernière position sur la carte. Le journal complet des scans est réservé aux membres Premium.
                </p>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <div className="bg-card border border-border shadow-sm rounded-2xl p-6">
              <h3 className="font-semibold text-lg mb-4 border-b pb-4">Détails du Badge</h3>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Identifiant NFC / QR</p>
                  <p className="font-mono bg-secondary text-secondary-foreground px-2 py-1 rounded inline-block text-sm">
                    {badgeData.badge_id}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Animal assigné</p>
                  <p className="font-medium text-foreground">{petName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Statut du badge</p>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Actif et protégé
                  </span>
                </div>
              </div>
            </div>
            
            <div className="bg-primary/5 border border-primary/20 rounded-2xl p-6">
              <Shield className="w-8 h-8 text-primary mb-3" />
              <h3 className="font-semibold text-foreground mb-2">Comment ça marche ?</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Lorsqu'une personne trouve votre animal et scanne la médaille avec son smartphone, sa position GPS est acquise et vous est immédiatement retransmise sur cette interface.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}