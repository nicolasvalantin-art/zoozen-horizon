import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Mail, Send, MapPin, Phone } from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import pb from '@/lib/pocketbaseClient.js';

export default function ContactPage() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      await pb.collection('contact_form').create({
        name: formData.name,
        email: formData.email,
        message: formData.message
      }, { $autoCancel: false });

      toast.success('Message envoyé avec succès ! Nous vous répondrons dans les plus brefs délais.');
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      console.error('Erreur lors de l\'envoi:', error);
      toast.error('Une erreur est survenue. Veuillez réessayer plus tard.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background text-foreground">
      <Helmet>
        <title>Contact | Zoozen</title>
        <meta name="description" content="Contactez l'équipe Zoozen pour toute question ou demande de support." />
      </Helmet>

      <Header />

      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-foreground mb-4">
            Contactez-nous
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Une question sur nos médailles, votre abonnement ou besoin d'aide avec un animal retrouvé ? Notre équipe est là pour vous aider.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Contact Information */}
          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 shadow-sm border border-border">
              <h2 className="text-2xl font-semibold mb-6">Informations directes</h2>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary mt-1">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-foreground">E-mail</h3>
                    <p className="text-muted-foreground">contact@zoozen.com</p>
                    <p className="text-sm text-muted-foreground mt-1">Nous répondons généralement sous 24h.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary mt-1">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-foreground">Téléphone</h3>
                    <p className="text-muted-foreground">+33 (0) 6 06 42 85 70</p>
                    <p className="text-sm text-muted-foreground mt-1">Du lundi au vendredi, 9h-18h.</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="flex-shrink-0 w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center text-primary mt-1">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="ml-4">
                    <h3 className="text-sm font-medium text-foreground">Siège social</h3>
                    <p className="text-muted-foreground">43 avenue Marceau Ginoux</p>
                    <p className="text-muted-foreground">13330 Pélissanne, France</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-card rounded-2xl p-8 shadow-lg border border-border">
            <h2 className="text-2xl font-semibold mb-6">Envoyez-nous un message</h2>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium text-foreground">
                  Nom complet
                </label>
                <Input
                  id="name"
                  name="name"
                  required
                  placeholder="Jean Dupont"
                  value={formData.name}
                  onChange={handleChange}
                  className="bg-background text-foreground"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-foreground">
                  Adresse e-mail
                </label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  required
                  placeholder="jean.dupont@exemple.com"
                  value={formData.email}
                  onChange={handleChange}
                  className="bg-background text-foreground"
                />
              </div>

              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-medium text-foreground">
                  Message
                </label>
                <Textarea
                  id="message"
                  name="message"
                  required
                  rows={5}
                  placeholder="Comment pouvons-nous vous aider ?"
                  value={formData.message}
                  onChange={handleChange}
                  className="resize-none bg-background text-foreground"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full h-12 text-base" 
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <span className="flex items-center">
                    Envoi en cours...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <Send className="w-4 h-4 mr-2" />
                    Envoyer le message
                  </span>
                )}
              </Button>
            </form>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}