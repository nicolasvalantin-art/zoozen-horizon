import React from 'react';
import { Helmet } from 'react-helmet';
import { useAuth } from '@/contexts/AuthContext.jsx';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import PlanCard from '@/components/PlanCard.jsx';
import SubscriptionCheckout from '@/components/SubscriptionCheckout.jsx';
import { Button } from '@/components/ui/button';
import { plansData } from '@/data/plans.js';

export default function SubscriptionPlansPage() {
  const { currentUser } = useAuth();

  return (
    <>
      <Helmet>
        <title>Tarifs - Zoozen</title>
        <meta name="description" content="Choisissez le forfait idéal pour protéger vos animaux avec les médailles intelligentes Zoozen." />
      </Helmet>
      <Header />
      <main className="min-h-screen bg-background py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-5xl font-extrabold mb-4" style={{ letterSpacing: '-0.02em' }}>
              Choisissez votre forfait
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Commencez avec notre forfait gratuit ou passez à la version supérieure pour des fonctionnalités avancées et des animaux illimités.
            </p>
          </div>

          {/* Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto items-stretch">
            {plansData.map((plan, index) => (
              <PlanCard
                key={plan.id}
                plan={plan}
                isRecommended={index === 1}
                currentPlan={currentUser?.subscription_plan}
                renderCheckout={(phoneVisibility) => (
                  currentUser ? (
                    <SubscriptionCheckout 
                      planType={plan.id} 
                      userId={currentUser.id}
                      phoneVisibility={phoneVisibility}
                    >
                      {plan.cta}
                    </SubscriptionCheckout>
                  ) : (
                    <Button 
                      onClick={() => window.location.href = '/signup'} 
                      className={`w-full ${index === 1 ? '' : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'}`}
                    >
                      {plan.cta}
                    </Button>
                  )
                )}
              />
            ))}
          </div>

          {/* FAQ */}
          <section className="mt-24 max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center mb-10">Foire aux questions</h2>
            <div className="space-y-8">
              <div className="bg-muted/50 p-6 rounded-2xl">
                <h3 className="font-semibold text-lg mb-2">Puis-je changer de forfait à tout moment ?</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Oui, vous pouvez modifier votre forfait à tout moment depuis les paramètres de votre compte. Les modifications prennent effet immédiatement.
                </p>
              </div>
              <div className="bg-muted/50 p-6 rounded-2xl">
                <h3 className="font-semibold text-lg mb-2">Que se passe-t-il si j'annule mon abonnement ?</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Les profils de vos animaux restent actifs jusqu'à la fin de votre période de facturation. Ensuite, vous passerez automatiquement au forfait gratuit.
                </p>
              </div>
            </div>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}