import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, LogOut, Plus, Trash2, Download, Link as LinkIcon, RefreshCw, QrCode, Layers, Link2, Link2Off } from 'lucide-react';
import { QRCodeCanvas } from 'qrcode.react';
import { toast } from 'sonner';

import pb from '@/lib/pocketbaseClient.js';
import apiServerClient from '@/lib/apiServerClient.js';
import { useAdminAuth } from '@/contexts/AdminAuthContext.jsx';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge as StatusBadge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';

export default function AdminDashboard() {
  const { logout, adminUser, isAdminAuthenticated } = useAdminAuth();
  const navigate = useNavigate();
  
  const [badges, setBadges] = useState([]);
  const [pets, setPets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // New Badge Form State
  const [newBadgeStatus, setNewBadgeStatus] = useState('available');
  const [newBadgePetId, setNewBadgePetId] = useState('');
  const [newBadgeCount, setNewBadgeCount] = useState(1);

  // Assign Badge State
  const [selectedBadgeForAssign, setSelectedBadgeForAssign] = useState(null);
  const [assignPetId, setAssignPetId] = useState('');

  useEffect(() => {
    if (isAdminAuthenticated) {
      fetchBadges();
      fetchPets();
    } else {
      setLoading(false);
    }
  }, [isAdminAuthenticated]);

  const fetchBadges = async () => {
    setLoading(true);
    
    if (!pb.authStore.isValid || !['admin', 'superadmin'].includes(pb.authStore.model?.role)) {
      toast.error('Session invalide ou privilèges insuffisants. Veuillez vous reconnecter.');
      setLoading(false);
      return;
    }

    try {
      const response = await pb.collection('badges').getList(1, 500, {
        sort: '-created_at',
        expand: 'pet_id',
        $autoCancel: false
      });
      
      setBadges(response.items);
    } catch (error) {
      console.error('Erreur de chargement des badges:', error);
      toast.error('Impossible de charger les badges. Vérifiez vos permissions et votre connexion.');
    } finally {
      setLoading(false);
    }
  };

  const fetchPets = async () => {
    try {
      const response = await pb.collection('pets').getFullList({
        sort: 'name',
        $autoCancel: false
      });
      setPets(response);
    } catch (error) {
      console.error('Erreur de chargement des animaux:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
    toast.success('Déconnexion réussie');
  };

  const handleCreateBadge = async (e) => {
    e.preventDefault();
    
    const count = parseInt(newBadgeCount, 10);
    
    if (isNaN(count) || count < 1 || count > 1000) {
      toast.error('Veuillez entrer un nombre valide entre 1 et 1000.');
      return;
    }

    if (count > 1 && newBadgePetId.trim() !== '') {
      toast.error('L\'assignation à un animal n\'est possible que pour la création d\'un seul badge.');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await apiServerClient.fetch('/badges', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          count,
          status: newBadgeStatus,
          pet_id: newBadgePetId.trim() || undefined
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de la création des badges');
      }

      const data = await response.json();
      
      toast.success(`${data.count} badge(s) créé(s) avec succès.`);
      setIsCreateOpen(false);
      setNewBadgeStatus('available');
      setNewBadgePetId('');
      setNewBadgeCount(1);
      fetchBadges();
    } catch (error) {
      console.error('Erreur lors de la création:', error);
      toast.error(`Erreur: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAssignBadge = async (e) => {
    e.preventDefault();
    if (!selectedBadgeForAssign || !assignPetId) {
      toast.error('Veuillez sélectionner un animal.');
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await apiServerClient.fetch(`/badges/${selectedBadgeForAssign.id}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pet_id: assignPetId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de l\'assignation');
      }

      toast.success('Badge assigné avec succès.');
      setIsAssignOpen(false);
      setSelectedBadgeForAssign(null);
      setAssignPetId('');
      fetchBadges();
    } catch (error) {
      console.error('Erreur assignation:', error);
      toast.error(`Erreur: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUnassignBadge = async (badgeId) => {
    if (!window.confirm('Voulez-vous vraiment désassigner ce badge ?')) return;
    
    try {
      const response = await apiServerClient.fetch(`/badges/${badgeId}/unassign`, {
        method: 'POST'
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erreur lors de la désassignation');
      }

      toast.success('Badge désassigné avec succès.');
      fetchBadges();
    } catch (error) {
      console.error('Erreur désassignation:', error);
      toast.error(`Erreur: ${error.message}`);
    }
  };

  const handleDeleteBadge = async (id) => {
    if (!window.confirm('Voulez-vous vraiment supprimer ce badge ? Cette action est irréversible.')) return;
    
    try {
      await pb.collection('badges').delete(id, { $autoCancel: false });
      toast.success('Badge supprimé.');
      fetchBadges();
    } catch (error) {
      console.error('Erreur suppression badge:', error);
      toast.error('Erreur lors de la suppression du badge.');
    }
  };

  const downloadQRCode = (badgeCode) => {
    const canvas = document.getElementById(`qr-${badgeCode}`);
    if (canvas) {
      try {
        const exportSize = 870;
        const padding = 85; 
        const qrSize = exportSize - (padding * 2);

        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = exportSize;
        tempCanvas.height = exportSize;
        
        const ctx = tempCanvas.getContext('2d');
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, exportSize, exportSize);
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(canvas, padding, padding, qrSize, qrSize);

        const pngUrl = tempCanvas.toDataURL("image/png");
        
        let downloadLink = document.createElement("a");
        downloadLink.href = pngUrl;
        downloadLink.download = `qr-badge-${badgeCode}.png`;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        toast.success('QR Code téléchargé avec succès');
      } catch (err) {
        console.error('Erreur téléchargement QR:', err);
        toast.error('Échec du téléchargement du QR Code.');
      }
    }
  };

  const getBadgeUrl = (badgeCode) => {
    const baseUrl = typeof window !== 'undefined' ? window.location.origin : 'https://toutoutag.com';
    return `${baseUrl}/scan/${badgeCode}`;
  };

  const formatStatus = (status) => {
    switch(status) {
      case 'available': return { label: 'Disponible', color: 'bg-emerald-100 text-emerald-800 border-emerald-200' };
      case 'used': return { label: 'Utilisé', color: 'bg-amber-100 text-amber-800 border-amber-200' };
      default: return { label: status, color: 'bg-slate-100 text-slate-800 border-slate-200' };
    }
  };

  const openAssignModal = (badge) => {
    setSelectedBadgeForAssign(badge);
    setAssignPetId('');
    setIsAssignOpen(true);
  };

  return (
    <>
      <Helmet>
        <title>Tableau de bord Admin - ToutouTag</title>
      </Helmet>
      
      <div className="min-h-[100dvh] bg-slate-50 text-slate-900">
        <header className="bg-slate-900 text-white sticky top-0 z-30 shadow-md">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-primary p-1.5 rounded-lg shadow-sm">
                <ShieldAlert className="w-5 h-5 text-primary-foreground" />
              </div>
              <span className="font-bold text-lg tracking-wide">Administration</span>
            </div>
            
            <div className="flex items-center gap-4">
              <span className="text-sm text-slate-400 hidden sm:inline-block">
                Connecté en tant que: <span className="text-slate-200">{adminUser?.email}</span>
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleLogout}
                className="text-slate-300 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Déconnexion
              </Button>
            </div>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div>
              <h1 className="text-2xl font-bold text-slate-900">Gestion des Badges NFC / QR</h1>
              <p className="text-slate-500 mt-1">Supervisez l'inventaire et générez de nouveaux identifiants de médailles automatiquement.</p>
            </div>
            
            <div className="flex items-center gap-3">
              <Button 
                variant="outline" 
                size="icon"
                onClick={fetchBadges} 
                disabled={loading}
                title="Actualiser"
                className="bg-white hover:bg-slate-50 transition-colors"
              >
                <RefreshCw className={`w-4 h-4 text-slate-600 ${loading ? 'animate-spin' : ''}`} />
              </Button>

              <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-sm transition-all active:scale-[0.98]">
                    <Layers className="w-4 h-4 mr-2" />
                    Générer des Badges
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Générer de nouveaux badges</DialogTitle>
                  </DialogHeader>
                  <form onSubmit={handleCreateBadge} className="space-y-6 pt-4">
                    <div className="bg-muted p-4 rounded-lg flex items-start gap-3">
                      <QrCode className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        Les codes séquentiels (ex: ZOOZEN-2026-0001) seront générés automatiquement.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="badgeCount">Nombre de badges</Label>
                        <Input
                          id="badgeCount"
                          type="number"
                          min="1"
                          max="1000"
                          value={newBadgeCount}
                          onChange={(e) => setNewBadgeCount(e.target.value)}
                          required
                          className="font-mono"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="badgeStatus">Statut initial</Label>
                        <Select value={newBadgeStatus} onValueChange={setNewBadgeStatus}>
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Sélectionner un statut" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="available">Disponible</SelectItem>
                            <SelectItem value="used">Utilisé</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="petId">Assigner à un animal (Optionnel)</Label>
                      <Select value={newBadgePetId} onValueChange={setNewBadgePetId} disabled={parseInt(newBadgeCount, 10) > 1}>
                        <SelectTrigger className="w-full">
                          <SelectValue placeholder="Sélectionner un animal" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Aucun</SelectItem>
                          {pets.map(pet => (
                            <SelectItem key={pet.id} value={pet.id}>{pet.name} ({pet.id})</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-slate-500">
                        {parseInt(newBadgeCount, 10) > 1 
                          ? "L'assignation à un animal n'est possible que pour la création d'un seul badge." 
                          : "Laissez vide si le badge n'est pas encore assigné à un animal."}
                      </p>
                    </div>

                    <DialogFooter>
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => setIsCreateOpen(false)}
                        disabled={isSubmitting}
                      >
                        Annuler
                      </Button>
                      <Button 
                        type="submit" 
                        disabled={isSubmitting}
                        className="bg-primary text-primary-foreground hover:bg-primary/90"
                      >
                        {isSubmitting ? 'Génération...' : `Générer ${newBadgeCount || 0} badge(s)`}
                      </Button>
                    </DialogFooter>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Assign Modal */}
          <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Assigner le badge {selectedBadgeForAssign?.badge_code}</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleAssignBadge} className="space-y-6 pt-4">
                <div className="space-y-2">
                  <Label htmlFor="assignPetId">Sélectionner un animal</Label>
                  <Select value={assignPetId} onValueChange={setAssignPetId} required>
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Choisir un animal..." />
                    </SelectTrigger>
                    <SelectContent>
                      {pets.map(pet => (
                        <SelectItem key={pet.id} value={pet.id}>{pet.name} ({pet.id})</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsAssignOpen(false)} disabled={isSubmitting}>
                    Annuler
                  </Button>
                  <Button type="submit" disabled={isSubmitting || !assignPetId} className="bg-primary text-primary-foreground">
                    {isSubmitting ? 'Assignation...' : 'Assigner'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>

          {/* Badges Table/List */}
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            {loading ? (
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between border-b pb-4">
                  <Skeleton className="h-6 w-[150px]" />
                  <Skeleton className="h-6 w-[100px]" />
                  <Skeleton className="h-6 w-[150px]" />
                  <Skeleton className="h-6 w-[80px]" />
                </div>
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center justify-between py-3">
                    <Skeleton className="h-12 w-[200px]" />
                    <Skeleton className="h-16 w-[150px]" />
                    <Skeleton className="h-8 w-[100px]" />
                    <Skeleton className="h-8 w-[40px]" />
                  </div>
                ))}
              </div>
            ) : badges.length === 0 ? (
              <div className="p-16 text-center flex flex-col items-center justify-center">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                  <QrCode className="w-8 h-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">Aucun badge dans l'inventaire</h3>
                <p className="text-slate-500 max-w-sm mb-6">
                  Générez votre premier badge pour commencer à équiper les animaux de la communauté ToutouTag.
                </p>
                <Button 
                  onClick={() => setIsCreateOpen(true)}
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                >
                  <Layers className="w-4 h-4 mr-2" />
                  Générer des Badges
                </Button>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50/80 border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500 font-semibold">
                      <th className="px-6 py-4">Code & Date</th>
                      <th className="px-6 py-4">Scan & QR Code</th>
                      <th className="px-6 py-4">Statut & Assignation</th>
                      <th className="px-6 py-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {badges.map((badge) => {
                      const badgeUrl = getBadgeUrl(badge.badge_code);
                      const statusInfo = formatStatus(badge.status);
                      const petName = badge.expand?.pet_id?.name;

                      return (
                        <tr key={badge.id} className="hover:bg-slate-50/50 transition-colors group">
                          <td className="px-6 py-5 align-top">
                            <div 
                              className="font-bold text-sm text-slate-900 mb-1"
                              title="Code Badge"
                            >
                              {badge.badge_code || <span className="text-slate-400 italic">Sans code</span>}
                            </div>
                            <div className="text-xs text-slate-500">
                              Créé le : {new Date(badge.created_at || badge.created).toLocaleDateString('fr-FR')}
                            </div>
                          </td>
                          
                          <td className="px-6 py-5 align-top">
                            <div className="flex items-start gap-4">
                              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm shrink-0 flex items-center justify-center w-28 h-28">
                                <QRCodeCanvas
                                  id={`qr-${badge.badge_code}`}
                                  value={badgeUrl}
                                  size={870}
                                  level={"H"}
                                  includeMargin={false}
                                  style={{ width: '100%', height: '100%' }}
                                />
                              </div>
                              <div className="flex flex-col items-start gap-2">
                                <a 
                                  href={badgeUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="inline-flex items-center text-xs font-medium text-primary hover:text-primary/80 hover:underline max-w-[250px] truncate"
                                  title={badgeUrl}
                                >
                                  <LinkIcon className="w-3 h-3 mr-1 shrink-0" />
                                  <span className="truncate">{badgeUrl}</span>
                                </a>
                                <Button 
                                  variant="outline" 
                                  size="sm" 
                                  className="h-7 text-xs px-2 shadow-sm hover:bg-slate-100 transition-colors"
                                  onClick={() => downloadQRCode(badge.badge_code)}
                                >
                                  <Download className="w-3 h-3 mr-1.5" />
                                  Télécharger
                                </Button>
                              </div>
                            </div>
                          </td>
                          
                          <td className="px-6 py-5 align-top">
                            <div className="flex flex-col items-start gap-2">
                              <StatusBadge variant="outline" className={`font-medium ${statusInfo.color}`}>
                                {statusInfo.label}
                              </StatusBadge>
                              {badge.pet_id ? (
                                <div className="text-xs text-slate-600 bg-slate-100 px-2 py-1 rounded border border-slate-200">
                                  Lié à : <span className="font-semibold text-slate-900">{petName || badge.pet_id}</span>
                                </div>
                              ) : (
                                <div className="text-xs text-slate-400 italic">
                                  Non assigné
                                </div>
                              )}
                            </div>
                          </td>
                          
                          <td className="px-6 py-5 align-top text-right">
                            <div className="flex items-center justify-end gap-2">
                              {badge.pet_id ? (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => handleUnassignBadge(badge.id)}
                                  className="text-amber-600 hover:text-amber-700 hover:bg-amber-50"
                                  title="Désassigner"
                                >
                                  <Link2Off className="w-4 h-4 mr-1" />
                                  Désassigner
                                </Button>
                              ) : (
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={() => openAssignModal(badge)}
                                  className="text-primary hover:text-primary/90 hover:bg-primary/10"
                                  title="Assigner à un animal"
                                >
                                  <Link2 className="w-4 h-4 mr-1" />
                                  Assigner
                                </Button>
                              )}
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                onClick={() => handleDeleteBadge(badge.id)}
                                className="text-slate-400 hover:text-destructive hover:bg-destructive/10 transition-colors"
                                title="Supprimer ce badge"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </main>
      </div>
    </>
  );
}