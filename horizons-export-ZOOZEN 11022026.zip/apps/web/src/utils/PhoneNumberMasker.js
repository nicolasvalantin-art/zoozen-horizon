export function maskPhoneNumber(phone) {
  if (!phone) return '';
  
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  if (digits.length < 4) return phone;
  
  // Show first 2 and last 2 digits, mask the rest
  const first = digits.slice(0, 2);
  const last = digits.slice(-2);
  const masked = 'X'.repeat(Math.max(0, digits.length - 4));
  
  // Format as +XX X XX XX XX XX
  const formatted = `+${first} ${masked.slice(0, 1)} ${masked.slice(1, 3)} ${masked.slice(3, 5)} ${masked.slice(5, 7)} ${last}`;
  
  return formatted.trim();
}