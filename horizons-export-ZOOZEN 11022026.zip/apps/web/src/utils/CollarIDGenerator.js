import { v4 as uuidv4 } from 'uuid';

/**
 * Generates a standard UUID v4 for use as a collar ID.
 * @returns {string} A UUID v4 string.
 */
export function generateCollarID() {
  return uuidv4();
}

/**
 * Generates a UUID v4 and verifies its uniqueness against the pets collection.
 * @param {object} pb - The PocketBase client instance.
 * @returns {Promise<string>} A unique collar ID.
 * @throws {Error} If a unique ID cannot be generated after multiple attempts.
 */
export async function generateUniqueCollarID(pb) {
  let isUnique = false;
  let newId = '';
  let attempts = 0;
  const maxAttempts = 10;

  while (!isUnique && attempts < maxAttempts) {
    newId = uuidv4();
    try {
      // Try to find a pet with this collar_id
      await pb.collection('pets').getFirstListItem(`collar_id="${newId}"`, { $autoCancel: false });
      // If we get here, the ID exists, so it's not unique
      attempts++;
    } catch (error) {
      // A 404 error means the ID was not found, which is what we want (it's unique)
      if (error.status === 404) {
        isUnique = true;
      } else {
        // Re-throw other errors (e.g., network issues)
        throw error;
      }
    }
  }

  if (!isUnique) {
    throw new Error('Failed to generate a unique collar ID after multiple attempts.');
  }

  return newId;
}