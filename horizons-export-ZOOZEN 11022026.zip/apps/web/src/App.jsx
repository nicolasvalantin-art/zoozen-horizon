import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from './components/ScrollToTop.jsx';

// Contexts
import { AuthProvider } from './contexts/AuthContext.jsx';
import { AdminAuthProvider } from './contexts/AdminAuthContext.jsx';
import { CartProvider } from '@/hooks/useCart.jsx';

// Protected Route Wrappers
import ProtectedRoute from './components/ProtectedRoute.jsx';
import AdminProtectedRoute from './components/AdminProtectedRoute.jsx';

// Public Pages
import HomePage from './pages/HomePage.jsx';
import LoginPage from './pages/LoginPage.jsx';
import SignupPage from './pages/SignupPage.jsx';
import PasswordResetPage from './pages/PasswordResetPage.jsx';
import SubscriptionPlansPage from './pages/SubscriptionPlansPage.jsx';
import PublicScanPage from './pages/PublicScanPage.jsx';
import PublicBadgePage from './pages/PublicBadgePage.jsx';
import PublicQRScanPage from './pages/PublicQRScanPage.jsx';
import PrivacyPolicyPage from './pages/PrivacyPolicyPage.jsx';
import TermsOfServicePage from './pages/TermsOfServicePage.jsx';
import ContactPage from './pages/ContactPage.jsx';

// E-commerce Pages
import ShopPage from './pages/ShopPage.jsx';
import ProductDetailPage from './pages/ProductDetailPage.jsx';
import SuccessPage from './pages/SuccessPage.jsx';

// User Protected Pages
import DashboardPage from './pages/DashboardPage.jsx';
import PetProfileEditorPage from './pages/PetProfileEditorPage.jsx';
import PetProfilePreviewPage from './pages/PetProfilePreviewPage.jsx';
import SubscriptionManagementPage from './pages/SubscriptionManagementPage.jsx';
import AccountSettingsPage from './pages/AccountSettingsPage.jsx';
import OwnerBadgeDashboard from './pages/OwnerBadgeDashboard.jsx';

// Admin Pages
import AdminLoginPage from './pages/AdminLoginPage.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';

function App() {
  return (
    <Router>
      <CartProvider>
        <AuthProvider>
          <AdminAuthProvider>
            <ScrollToTop />
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<HomePage />} />
              
              <Route path="/login" element={<LoginPage />} />
              <Route path="/signup" element={<SignupPage />} />
              <Route path="/reset-password" element={<PasswordResetPage />} />
              <Route path="/plans" element={<SubscriptionPlansPage />} />
              <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
              <Route path="/terms-of-service" element={<TermsOfServicePage />} />
              <Route path="/contact" element={<ContactPage />} />
              
              {/* E-commerce Routes */}
              <Route path="/shop" element={<ShopPage />} />
              <Route path="/product/:id" element={<ProductDetailPage />} />
              <Route path="/success" element={<SuccessPage />} />
              
              {/* Badge Scanning Routes - PUBLIC */}
              <Route path="/scan/:collarId" element={<PublicScanPage />} />
              <Route path="/scan/:badgeCode" element={<PublicQRScanPage />} />
              <Route path="/badge/:badgeId" element={<PublicBadgePage />} />

              {/* Admin Auth Route (Public but distinct) */}
              <Route path="/admin/login" element={<AdminLoginPage />} />

              {/* Admin Protected Routes */}
              <Route 
                path="/admin" 
                element={
                  <AdminProtectedRoute>
                    <AdminDashboard />
                  </AdminProtectedRoute>
                } 
              />

              {/* User Protected routes */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/owner/badges/:badgeId"
                element={
                  <ProtectedRoute>
                    <OwnerBadgeDashboard />
                  </ProtectedRoute>
                }
              />
              {/* CRITICAL: /pet/new MUST come BEFORE /pet/:id to match correctly */}
              <Route
                path="/pet/new"
                element={
                  <ProtectedRoute>
                    <PetProfileEditorPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/pet/:id"
                element={
                  <ProtectedRoute>
                    <PetProfileEditorPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/pet/:id/preview"
                element={
                  <ProtectedRoute>
                    <PetProfilePreviewPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/subscription"
                element={
                  <ProtectedRoute>
                    <SubscriptionManagementPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/settings"
                element={
                  <ProtectedRoute>
                    <AccountSettingsPage />
                  </ProtectedRoute>
                }
              />

              {/* 404 */}
              <Route
                path="*"
                element={
                  <div className="min-h-[100dvh] flex items-center justify-center bg-background">
                    <div className="text-center p-8 bg-card rounded-2xl shadow-lg border border-border">
                      <h1 className="text-6xl font-extrabold text-primary mb-4 tracking-tighter">404</h1>
                      <p className="text-xl text-foreground font-medium mb-2">Page introuvable</p>
                      <p className="text-muted-foreground mb-8">Désolé, la page que vous recherchez n'existe pas.</p>
                      <a href="/" className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-xl text-primary-foreground bg-primary hover:bg-primary/90 transition-colors">
                        Retour à l'accueil
                      </a>
                    </div>
                  </div>
                }
              />
            </Routes>
            <Toaster position="top-right" />
          </AdminAuthProvider>
        </AuthProvider>
      </CartProvider>
    </Router>
  );
}

export default App;