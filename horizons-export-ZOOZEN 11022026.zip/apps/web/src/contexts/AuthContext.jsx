import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import pb from '@/lib/pocketbaseClient';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [initialLoading, setInitialLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    if (pb.authStore.isValid && pb.authStore.model) {
      setCurrentUser(pb.authStore.model);
    }
    setInitialLoading(false);
  }, []);

  const login = async (email, password) => {
    const authData = await pb.collection('users').authWithPassword(email, password, { $autoCancel: false });
    setCurrentUser(authData.record);
    return authData.record;
  };

  const signup = async (email, password, passwordConfirm, name) => {
    const user = await pb.collection('users').create({
      email,
      password,
      passwordConfirm,
      name,
      subscription_tier: 'free'
    }, { $autoCancel: false });
    
    const authData = await pb.collection('users').authWithPassword(email, password, { $autoCancel: false });
    setCurrentUser(authData.record);
    return authData.record;
  };

  const logout = () => {
    pb.authStore.clear();
    setCurrentUser(null);
    navigate('/');
  };

  const requestPasswordReset = async (email) => {
    await pb.collection('users').requestPasswordReset(email, { $autoCancel: false });
  };

  const confirmPasswordReset = async (token, password, passwordConfirm) => {
    await pb.collection('users').confirmPasswordReset(token, password, passwordConfirm, { $autoCancel: false });
  };

  const refreshUser = async () => {
    if (currentUser) {
      const updated = await pb.collection('users').getOne(currentUser.id, { $autoCancel: false });
      setCurrentUser(updated);
    }
  };

  const getSubscriptionTier = () => {
    return currentUser?.subscription_tier || 'free';
  };

  const value = {
    currentUser,
    login,
    signup,
    logout,
    requestPasswordReset,
    confirmPasswordReset,
    refreshUser,
    getSubscriptionTier,
    isAuthenticated: !!currentUser,
    initialLoading
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
}