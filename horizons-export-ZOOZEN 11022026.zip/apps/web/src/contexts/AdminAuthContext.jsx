import React, { createContext, useContext, useState, useEffect } from 'react';
import pb from '@/lib/pocketbaseClient.js';

const AdminAuthContext = createContext(null);

export function AdminAuthProvider({ children }) {
  const [adminUser, setAdminUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check initial auth state from localStorage (via PocketBase SDK)
    if (pb.authStore.isValid && ['admin', 'superadmin'].includes(pb.authStore.model?.role)) {
      setAdminUser(pb.authStore.model);
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    // Authenticate with PocketBase
    const authData = await pb.collection('users').authWithPassword(email, password, { $autoCancel: false });
    
    // Verify admin or superadmin role
    if (!['admin', 'superadmin'].includes(authData.record.role)) {
      pb.authStore.clear(); // Clear so they don't persist as a normal user in admin context
      setAdminUser(null);
      throw new Error("Accès refusé : privilèges d'administrateur requis.");
    }
    
    setAdminUser(authData.record);
    return authData.record;
  };

  const logout = () => {
    pb.authStore.clear();
    setAdminUser(null);
  };

  const value = {
    adminUser,
    login,
    logout,
    isAdminAuthenticated: !!adminUser,
    loading
  };

  return <AdminAuthContext.Provider value={value}>{children}</AdminAuthContext.Provider>;
}

export function useAdminAuth() {
  const context = useContext(AdminAuthContext);
  if (!context) {
    throw new Error('useAdminAuth must be used within an AdminAuthProvider');
  }
  return context;
}