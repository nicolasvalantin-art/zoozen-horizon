import { Router } from 'express';
import healthCheck from './health-check.js';
import authRouter from './auth.js';
import stripeRouter from './stripe.js';
import petsRouter from './pets.js';
import subscriptionsRouter from './subscriptions.js';
import badgesRouter from './badges.js';
import scansRouter from './scans.js';
import integratedAiRouter from './integrated-ai.js';
import reverseGeocodeRouter from './reverse-geocode.js';

const router = Router();

export default () => {
  router.get('/health', healthCheck);
  router.use('/auth', authRouter);
  router.use('/stripe', stripeRouter);
  router.use('/pets', petsRouter);
  router.use('/subscriptions', subscriptionsRouter);
  router.use('/badges', badgesRouter);
  router.use('/scans', scansRouter);
  router.use('/integrated-ai', integratedAiRouter);
  router.use('/reverse-geocode', reverseGeocodeRouter);

  return router;
};