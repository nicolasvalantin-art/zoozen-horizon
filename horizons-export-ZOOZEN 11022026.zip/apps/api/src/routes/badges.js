import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// GET /badges/next-code
router.get('/next-code', async (req, res) => {
  try {
    // Query all badges and sort by created_at descending to find the highest sequence
    const badges = await pb.collection('badges').getFullList({
      sort: '-created_at',
      fields: 'badge_code',
    });

    let nextSequence = 1;

    // Parse existing badge codes to find the highest sequence number
    if (badges.length > 0) {
      for (const badge of badges) {
        if (!badge.badge_code) continue;
        const match = badge.badge_code.match(/^ZOOZEN-\d+-([0-9]+)$/);
        if (match) {
          const sequence = parseInt(match[1], 10);
          if (sequence >= nextSequence) {
            nextSequence = sequence + 1;
          }
        }
      }
    }

    const year = new Date().getFullYear();
    const paddedSequence = String(nextSequence).padStart(4, '0');
    const nextCode = `ZOOZEN-${year}-${paddedSequence}`;

    logger.info(`Generated next badge code: ${nextCode}`, { sequence: nextSequence });

    res.json({
      next_code: nextCode,
      sequence: nextSequence,
    });
  } catch (error) {
    logger.error('Error generating next badge code:', error);
    res.status(500).json({ error: 'Failed to generate next badge code' });
  }
});

// POST /badges
router.post('/', async (req, res) => {
  const { count, status, pet_id } = req.body;
  const authHeader = req.headers.authorization;

  // Validate authentication
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  // Validate count
  if (!count || typeof count !== 'number' || count <= 0) {
    return res.status(400).json({ error: 'Count must be a positive number' });
  }

  if (count > 1000) {
    return res.status(400).json({ error: 'Count cannot exceed 1000 per request' });
  }

  const badgeStatus = status || 'available';

  // Validate pet_id if provided
  if (pet_id) {
    if (typeof pet_id !== 'string') {
      return res.status(400).json({ error: 'pet_id must be a string' });
    }
    try {
      // Verify pet exists
      await pb.collection('pets').getOne(pet_id);
    } catch (error) {
      return res.status(404).json({ error: 'Pet not found' });
    }
  }

  try {
    // Get the starting sequence
    const badges = await pb.collection('badges').getFullList({
      sort: '-created_at',
      fields: 'badge_code',
    });

    let nextSequence = 1;
    if (badges.length > 0) {
      for (const badge of badges) {
        if (!badge.badge_code) continue;
        const match = badge.badge_code.match(/^ZOOZEN-\d+-([0-9]+)$/);
        if (match) {
          const sequence = parseInt(match[1], 10);
          if (sequence >= nextSequence) {
            nextSequence = sequence + 1;
          }
        }
      }
    }

    const year = new Date().getFullYear();
    const generated = [];

    // Create badge records
    for (let i = 0; i < count; i++) {
      const paddedSequence = String(nextSequence + i).padStart(4, '0');
      const badgeCode = `ZOOZEN-${year}-${paddedSequence}`;

      const badgeData = {
        badge_code: badgeCode,
        status: pet_id ? 'used' : badgeStatus,
      };

      if (pet_id) {
        badgeData.pet_id = pet_id;
      }

      const record = await pb.collection('badges').create(badgeData);

      generated.push({
        id: record.id,
        badge_code: record.badge_code,
        status: record.status,
        pet_id: record.pet_id || null,
        created_at: record.created_at,
      });
    }

    logger.info(`Created ${count} badges`, { pet_id: pet_id || null });

    res.status(201).json({
      success: true,
      generated,
      count: generated.length,
    });
  } catch (error) {
    logger.error('Error creating badges:', error);
    res.status(500).json({ error: 'Failed to create badges', details: error.message });
  }
});

// POST /badges/:id/assign
router.post('/:id/assign', async (req, res) => {
  const { id } = req.params;
  const { pet_id } = req.body;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  if (!pet_id) {
    return res.status(400).json({ error: 'pet_id is required' });
  }

  try {
    // Verify pet exists
    await pb.collection('pets').getOne(pet_id);
    
    // Update badge
    const updatedBadge = await pb.collection('badges').update(id, {
      pet_id: pet_id,
      status: 'used'
    });

    res.json({ success: true, badge: updatedBadge });
  } catch (error) {
    logger.error(`Error assigning badge ${id}:`, error);
    res.status(500).json({ error: 'Failed to assign badge', details: error.message });
  }
});

// POST /badges/:id/unassign
router.post('/:id/unassign', async (req, res) => {
  const { id } = req.params;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  try {
    // Update badge to clear pet_id and set status to available
    const updatedBadge = await pb.collection('badges').update(id, {
      pet_id: null,
      status: 'available'
    });

    res.json({ success: true, badge: updatedBadge });
  } catch (error) {
    logger.error(`Error unassigning badge ${id}:`, error);
    res.status(500).json({ error: 'Failed to unassign badge', details: error.message });
  }
});

export default router;