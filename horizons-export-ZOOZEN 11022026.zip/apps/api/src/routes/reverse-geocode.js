import express from 'express';
import logger from '../utils/logger.js';

const router = express.Router();

// GET /reverse-geocode?latitude=48.8566&longitude=2.3522
router.get('/', async (req, res) => {
  const { latitude, longitude } = req.query;

  // Validate required parameters
  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ error: 'latitude and longitude query parameters are required' });
  }

  // Parse and validate coordinates
  const lat = parseFloat(latitude);
  const lon = parseFloat(longitude);

  if (isNaN(lat) || isNaN(lon)) {
    return res.status(400).json({ error: 'latitude and longitude must be valid numbers' });
  }

  if (lat < -90 || lat > 90) {
    return res.status(400).json({ error: 'latitude must be between -90 and 90' });
  }

  if (lon < -180 || lon > 180) {
    return res.status(400).json({ error: 'longitude must be between -180 and 180' });
  }

  // Call Nominatim API
  const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}`;

  const response = await fetch(url, {
    headers: {
      'User-Agent': 'ZooZen-API/1.0',
    },
  });

  if (!response.ok) {
    throw new Error(`Nominatim API error: ${response.status} ${response.statusText}`);
  }

  const data = await response.json();

  logger.info('Reverse geocode successful', { latitude: lat, longitude: lon, address: data.address?.road });

  // Extract address components from Nominatim response
  const address = data.address || {};
  const fullAddress = data.display_name || 'Unknown location';
  const city = address.city || address.town || address.village || 'Unknown';
  const country = address.country || 'Unknown';

  res.json({
    address: fullAddress,
    city,
    country,
  });
});

export default router;