import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// POST /auth/register
router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Email, password, and name are required' });
  }

  try {
    const user = await pb.collection('users').create({
      email,
      password,
      passwordConfirm: password,
      name,
    });

    const token = await pb.collection('users').authWithPassword(email, password);

    res.status(201).json({
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
      },
      token: token.token,
    });
  } catch (error) {
    if (error.message && error.message.includes('duplicate')) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    throw error;
  }
});

// POST /auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required' });
  }

  try {
    const authData = await pb.collection('users').authWithPassword(email, password);

    res.json({
      user: {
        id: authData.record.id,
        email: authData.record.email,
        name: authData.record.name,
        subscription_plan: authData.record.subscription_plan || null,
      },
      token: authData.token,
    });
  } catch (error) {
    if (error.status === 401 || error.message.includes('invalid')) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }
    throw error;
  }
});

// POST /auth/password-reset
router.post('/password-reset', async (req, res) => {
  const { email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  try {
    await pb.collection('users').requestPasswordReset(email);
  } catch (error) {
    // Do NOT throw error if email not found (security)
    logger.warn(`Password reset requested for non-existent email: ${email}`);
  }

  res.json({ message: 'Password reset email sent' });
});

// POST /auth/confirm-password-reset
router.post('/confirm-password-reset', async (req, res) => {
  const { token, password, passwordConfirm } = req.body;

  if (!token || !password || !passwordConfirm) {
    return res.status(400).json({ error: 'Token, password, and passwordConfirm are required' });
  }

  try {
    await pb.collection('users').confirmPasswordReset(token, password, passwordConfirm);
    res.json({ message: 'Password reset successful' });
  } catch (error) {
    if (error.status === 400 || error.message.includes('invalid')) {
      return res.status(400).json({ error: 'Invalid or expired reset token' });
    }
    throw error;
  }
});

export default router;