import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// POST /pets/:collarId/scan
router.post('/:collarId/scan', async (req, res) => {
  const { collarId } = req.params;
  const { message, latitude, longitude } = req.body;

  if (!collarId) {
    return res.status(400).json({ error: 'Collar ID is required' });
  }

  try {
    // Fetch pet by collar_id
    const pets = await pb.collection('pets').getList(1, 1, {
      filter: `collar_id = "${collarId}"`,
    });

    if (pets.items.length === 0) {
      return res.status(404).json({ error: 'Pet not found' });
    }

    const pet = pets.items[0];

    // Create scan record
    await pb.collection('scans').create({
      pet_id: pet.id,
      scan_timestamp: new Date().toISOString(),
      message: message || null,
      scanner_location: latitude && longitude ? `${latitude},${longitude}` : null,
    });

    res.json({ message: 'Scan recorded' });
  } catch (error) {
    logger.error('Scan creation error:', error.message);
    throw error;
  }
});

// POST /pets/:collarId/found
router.post('/:collarId/found', async (req, res) => {
  const { collarId } = req.params;
  const { message } = req.body;

  if (!collarId) {
    return res.status(400).json({ error: 'Collar ID is required' });
  }

  if (!message) {
    return res.status(400).json({ error: 'Message is required' });
  }

  try {
    // Fetch pet by collar_id
    const pets = await pb.collection('pets').getList(1, 1, {
      filter: `collar_id = "${collarId}"`,
    });

    if (pets.items.length === 0) {
      return res.status(404).json({ error: 'Pet not found' });
    }

    const pet = pets.items[0];

    // Fetch owner
    const owner = await pb.collection('users').getOne(pet.owner_id);

    // Send email to owner (via PocketBase hooks)
    // Note: Email sending is handled by PocketBase hooks, not here
    // This is a placeholder for the notification logic
    logger.info(`Pet found notification: ${pet.name} - Owner: ${owner.email}`);

    res.json({ message: 'Notification sent to owner' });
  } catch (error) {
    logger.error('Pet found notification error:', error.message);
    throw error;
  }
});

export default router;