import express from 'express';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

const ADMIN_EMAIL = 'superadmin@indigo-sparrow-115502.hostingersite.com';

/**
 * POST /email/send-pet-owner-email
 * Sends an email directly to a pet owner using PocketBase's native email client
 * Request body: { ownerEmail, subject, message }
 */
router.post('/send-pet-owner-email', async (req, res) => {
  const { ownerEmail, subject, message } = req.body;

  // VALIDATION: Check required fields
  if (!ownerEmail) {
    return res.status(400).json({ error: 'ownerEmail is required' });
  }

  if (!subject) {
    return res.status(400).json({ error: 'subject is required' });
  }

  if (!message) {
    return res.status(400).json({ error: 'message is required' });
  }

  // VALIDATION: Validate email format
  if (!isValidEmail(ownerEmail)) {
    return res.status(400).json({ error: 'Invalid owner email format' });
  }

  // Send email using PocketBase's native email client
  const mailClient = pb.newMailClient();

  const emailMessage = {
    from: {
      address: 'noreply@zoozen.fr',
      name: 'ZooZen',
    },
    to: [{ address: ownerEmail }],
    subject: subject,
    html: message,
  };

  await mailClient.send(emailMessage);

  logger.info('Email sent to pet owner', {
    to: ownerEmail,
    subject: subject,
  });

  res.status(200).json({
    success: true,
    message: 'Email sent',
  });
});

/**
 * POST /email/send-location-email
 * Sends a location alert email directly to admin using PocketBase's native email client
 * Request body: { subject, message }
 */
router.post('/send-location-email', async (req, res) => {
  const { subject, message } = req.body;

  // VALIDATION: Check required fields
  if (!subject) {
    return res.status(400).json({ error: 'subject is required' });
  }

  if (!message) {
    return res.status(400).json({ error: 'message is required' });
  }

  // Send email using PocketBase's native email client
  const mailClient = pb.newMailClient();

  const emailMessage = {
    from: {
      address: 'noreply@zoozen.fr',
      name: 'ZooZen',
    },
    to: [{ address: ADMIN_EMAIL }],
    subject: subject,
    html: message,
  };

  await mailClient.send(emailMessage);

  logger.info('Location alert email sent to admin', {
    to: ADMIN_EMAIL,
    subject: subject,
  });

  res.status(200).json({
    success: true,
    message: 'Email sent',
  });
});

/**
 * Validates email format using a simple regex
 * @param {string} email - Email to validate
 * @returns {boolean} - True if valid email format
 */
function isValidEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export default router;