import express from 'express';
import STRIPE_PLANS from '../constants/stripe-config.js';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Helper function to extract user ID from Bearer token
function extractUserIdFromToken(token) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid token format');
    }
    const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
    return payload.id;
  } catch (error) {
    throw new Error('Invalid authentication token');
  }
}

// GET /subscriptions/:user_id (requires authentication)
router.get('/:user_id', async (req, res) => {
  const { user_id } = req.params;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);
  const authenticatedUserId = extractUserIdFromToken(token);

  // Verify user can only view their own subscription
  if (authenticatedUserId !== user_id) {
    throw new Error('Unauthorized: Cannot access other users subscriptions');
  }

  // Attempt to fetch subscription for this user
  let subscription;
  try {
    subscription = await pb.collection('subscriptions').getFirstListItem(`user_id="${user_id}"`);
  } catch (error) {
    // If no subscription exists, return default free tier
    if (error.status === 404) {
      logger.info(`No subscription found for user ${user_id}, returning default free tier`);
      return res.json({
        tier: 'free',
        status: 'active',
        start_date: null,
        end_date: null,
        subscription_id: null,
      });
    }
    throw error;
  }

  logger.info(`Fetched subscription for user ${user_id}`, { subscription_id: subscription.id, tier: subscription.tier });

  res.json({
    tier: subscription.tier,
    status: subscription.status,
    start_date: subscription.start_date,
    end_date: subscription.end_date,
    subscription_id: subscription.id,
  });
});

// POST /subscriptions (requires authentication)
router.post('/', async (req, res) => {
  const { user_id, plan_type } = req.body;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);
  const authenticatedUserId = extractUserIdFromToken(token);

  // Verify user can only create their own subscription
  if (authenticatedUserId !== user_id) {
    throw new Error('Unauthorized: Cannot create subscription for other users');
  }

  // Validate plan_type
  if (!plan_type) {
    return res.status(400).json({ error: 'plan_type is required' });
  }

  if (!STRIPE_PLANS[plan_type]) {
    return res.status(400).json({ error: `Invalid plan_type: ${plan_type}. Valid types are: ${Object.keys(STRIPE_PLANS).join(', ')}` });
  }

  const plan = STRIPE_PLANS[plan_type];

  // Check if subscription already exists for this user
  let existingSubscription;
  try {
    existingSubscription = await pb.collection('subscriptions').getFirstListItem(`user_id="${user_id}"`);
  } catch (error) {
    if (error.status !== 404) {
      throw error;
    }
  }

  const startDate = new Date().toISOString().split('T')[0];
  let record;

  const subscriptionData = {
    plan_type,
    status: 'active',
    start_date: startDate,
    stripe_subscription_id: null,
    stripe_customer_id: null,
    stripe_price_id: plan.stripePriceId,
  };

  if (existingSubscription) {
    // Update existing subscription
    record = await pb.collection('subscriptions').update(existingSubscription.id, subscriptionData);
    logger.info(`Updated subscription for user ${user_id}`, { subscription_id: record.id, plan_type });
  } else {
    // Create new subscription
    record = await pb.collection('subscriptions').create({
      user_id,
      ...subscriptionData,
    });
    logger.info(`Created new subscription for user ${user_id}`, { subscription_id: record.id, plan_type });
  }

  res.status(201).json({
    subscription_id: record.id,
    plan_type: record.plan_type,
    status: record.status,
    start_date: record.start_date,
    end_date: null,
  });
});

// GET /subscriptions/:user_id/tier (requires authentication)
router.get('/:user_id/tier', async (req, res) => {
  const { user_id } = req.params;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);
  const authenticatedUserId = extractUserIdFromToken(token);

  // Verify user can only check their own tier
  if (authenticatedUserId !== user_id) {
    throw new Error('Unauthorized: Cannot access other users subscription tier');
  }

  // Attempt to fetch subscription for this user
  let subscription;
  try {
    subscription = await pb.collection('subscriptions').getFirstListItem(`user_id="${user_id}"`);
  } catch (error) {
    // If no subscription exists, return default (not premium)
    if (error.status === 404) {
      logger.info(`No subscription found for user ${user_id}, returning default tier check`);
      return res.json({
        is_premium: false,
      });
    }
    throw error;
  }

  logger.info(`Checked subscription tier for user ${user_id}`, { is_premium: subscription.plan_type === 'premium' });

  res.json({
    is_premium: subscription.plan_type === 'premium',
  });
});

export default router;