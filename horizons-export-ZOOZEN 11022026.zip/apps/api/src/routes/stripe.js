import 'dotenv/config';
import express from 'express';
import Stripe from 'stripe';
import STRIPE_PLANS from '../constants/stripe-config.js';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

// Validate Stripe API key on startup
router.get('/validate-key', async (req, res) => {
  const account = await stripe.accounts.retrieve();
  logger.info('Stripe API key validated successfully', { accountId: account.id });
  res.json({
    valid: true,
    accountId: account.id,
    email: account.email,
    country: account.country,
  });
});

// POST /stripe/create-checkout
router.post('/create-checkout', async (req, res) => {
  const { planType, userId, successUrl, cancelUrl } = req.body;

  if (!planType || !userId || !successUrl || !cancelUrl) {
    return res.status(400).json({ error: 'planType, userId, successUrl, and cancelUrl are required' });
  }

  if (!STRIPE_PLANS[planType]) {
    return res.status(400).json({ error: `Invalid plan type: ${planType}. Valid types are: ${Object.keys(STRIPE_PLANS).join(', ')}` });
  }

  const plan = STRIPE_PLANS[planType];
  const user = await pb.collection('users').getOne(userId);

  // Handle free basique plan - no Stripe checkout needed
  if (planType === 'basique') {
    // Create subscription record directly for free plan
    await pb.collection('subscriptions').create({
      user_id: userId,
      plan_type: planType,
      status: 'active',
      stripe_subscription_id: null,
      stripe_customer_id: null,
      stripe_price_id: null,
    });

    // Update user subscription plan
    await pb.collection('users').update(userId, {
      subscription_plan: planType,
      subscription_status: 'active',
    });

    return res.json({ success: true, url: null });
  }

  // Handle paid plans (standard, premium)
  if (!plan.stripePriceId) {
    throw new Error(`Stripe price ID not configured for plan: ${planType}`);
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    customer_email: user.email,
    line_items: [
      {
        price: plan.stripePriceId,
        quantity: 1,
      },
    ],
    mode: 'subscription',
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      userId,
      planType,
    },
  });

  // Store session ID in user record for webhook matching
  await pb.collection('users').update(userId, {
    stripe_session_id: session.id,
  });

  res.json({ url: session.url });
});

// POST /stripe/webhook
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!webhookSecret) {
    logger.warn('STRIPE_WEBHOOK_SECRET not configured');
    return res.json({ received: true });
  }

  let event;

  event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object;
        const { userId, planType } = session.metadata;

        if (userId && planType) {
          const plan = STRIPE_PLANS[planType];
          // Create subscription record
          await pb.collection('subscriptions').create({
            user_id: userId,
            plan_type: planType,
            status: 'active',
            stripe_subscription_id: session.subscription,
            stripe_customer_id: session.customer,
            stripe_price_id: plan.stripePriceId,
          });

          // Update user subscription plan
          await pb.collection('users').update(userId, {
            subscription_plan: planType,
            subscription_status: 'active',
          });
        }
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object;
        const records = await pb.collection('subscriptions').getList(1, 1, {
          filter: `stripe_subscription_id = "${subscription.id}"`,
        });

        if (records.items.length > 0) {
          const subRecord = records.items[0];
          const endDate = new Date(subscription.current_period_end * 1000).toISOString();

          await pb.collection('subscriptions').update(subRecord.id, {
            status: subscription.status,
            end_date: endDate,
          });

          // Update user subscription status
          await pb.collection('users').update(subRecord.user_id, {
            subscription_status: subscription.status,
          });
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object;
        const records = await pb.collection('subscriptions').getList(1, 1, {
          filter: `stripe_subscription_id = "${subscription.id}"`,
        });

        if (records.items.length > 0) {
          const subRecord = records.items[0];

          await pb.collection('subscriptions').update(subRecord.id, {
            status: 'cancelled',
          });

          // Update user subscription status
          await pb.collection('users').update(subRecord.user_id, {
            subscription_status: 'cancelled',
          });
        }
        break;
      }

      default:
        logger.debug(`Unhandled event type: ${event.type}`);
    }
  } catch (error) {
    logger.error('Webhook processing error:', error.message);
  }

  res.json({ received: true });
});

// GET /stripe/session/:sessionId
router.get('/session/:sessionId', async (req, res) => {
  const { sessionId } = req.params;

  if (!sessionId) {
    return res.status(400).json({ error: 'Session ID is required' });
  }

  const session = await stripe.checkout.sessions.retrieve(sessionId);

  res.json({
    id: session.id,
    status: session.payment_status,
    amountTotal: session.amount_total,
    customerEmail: session.customer_details?.email,
    subscription_id: session.subscription,
  });
});

export default router;