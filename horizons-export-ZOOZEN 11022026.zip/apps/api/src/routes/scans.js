import express from 'express';
import rateLimit from 'express-rate-limit';
import pb from '../utils/pocketbaseClient.js';
import logger from '../utils/logger.js';

const router = express.Router();

// Rate limit: 10 requests per IP per hour
const scanRateLimit = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many scan requests, please try again later' },
  validate: { trustProxy: false },
});

// POST /scans (public, no auth required)
router.post('/', scanRateLimit, async (req, res) => {
  const { badge_id, latitude, longitude, device_type, browser } = req.body;
  const ipAddress = req.ip;

  // Validate badge_id
  if (!badge_id || typeof badge_id !== 'string' || badge_id.trim() === '') {
    return res.status(400).json({ error: 'badge_id must be a non-empty string' });
  }

  // Validate latitude and longitude
  if (latitude === undefined || longitude === undefined) {
    return res.status(400).json({ error: 'latitude and longitude are required' });
  }

  const lat = parseFloat(latitude);
  const lon = parseFloat(longitude);

  if (isNaN(lat) || isNaN(lon)) {
    return res.status(400).json({ error: 'latitude and longitude must be valid numbers' });
  }

  if (lat < -90 || lat > 90) {
    return res.status(400).json({ error: 'latitude must be between -90 and 90' });
  }

  if (lon < -180 || lon > 180) {
    return res.status(400).json({ error: 'longitude must be between -180 and 180' });
  }

  // Verify badge exists by fetching it
  const badge = await pb.collection('badges').getOne(badge_id);

  // Create scan record
  const record = await pb.collection('scans').create({
    badge_id,
    latitude: lat,
    longitude: lon,
    device_type: device_type || null,
    browser: browser || null,
    ip_address: ipAddress,
  });

  logger.info(`Scan recorded for badge ${badge_id}`, { scan_id: record.id, ip: ipAddress });

  res.status(201).json({
    success: true,
    scan_id: record.id,
    message: 'Scan recorded',
  });
});

// GET /scans/:badge_id (requires authentication)
router.get('/:badge_id', async (req, res) => {
  const { badge_id } = req.params;
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);

  // Verify token and get authenticated user ID
  let authenticatedUserId;
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      throw new Error('Invalid token format');
    }
    const payload = JSON.parse(Buffer.from(parts[1], 'base64').toString());
    authenticatedUserId = payload.id;
  } catch (error) {
    throw new Error('Invalid authentication token');
  }

  // Fetch badge to verify it exists and check ownership
  const badge = await pb.collection('badges').getOne(badge_id);

  // Verify current user is the badge owner
  if (badge.user_id !== authenticatedUserId) {
    throw new Error('Unauthorized: You do not own this badge');
  }

  // Fetch all scans for this badge
  const scans = await pb.collection('scans').getFullList({
    filter: `badge_id="${badge_id}"`,
    sort: '-timestamp',
  });

  logger.info(`Fetched scans for badge ${badge_id}`, { count: scans.length, user_id: authenticatedUserId });

  // Return scans with specific fields
  const formattedScans = scans.map(scan => ({
    id: scan.id,
    latitude: scan.latitude,
    longitude: scan.longitude,
    timestamp: scan.timestamp || scan.created,
    device_type: scan.device_type,
    browser: scan.browser,
  }));

  res.json(formattedScans);
});

export default router;