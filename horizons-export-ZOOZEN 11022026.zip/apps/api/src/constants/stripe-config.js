import 'dotenv/config';

const STRIPE_PLANS = {
  basique: {
    name: 'Basique',
    price: 0,
    currency: 'eur',
    interval: 'month',
    description: 'Free plan',
    stripeProductId: null,
    stripePriceId: null,
  },
  standard: {
    name: 'Standard',
    price: 499,
    currency: 'eur',
    interval: 'month',
    description: 'Standard subscription',
    stripeProductId: process.env.STRIPE_STANDARD_PRODUCT_ID,
    stripePriceId: process.env.STRIPE_STANDARD_PRICE_ID,
  },
  premium: {
    name: 'Premium',
    price: 999,
    currency: 'eur',
    interval: 'month',
    description: 'Premium subscription',
    stripeProductId: process.env.STRIPE_PREMIUM_PRODUCT_ID,
    stripePriceId: process.env.STRIPE_PREMIUM_PRICE_ID,
  },
};

export default STRIPE_PLANS;