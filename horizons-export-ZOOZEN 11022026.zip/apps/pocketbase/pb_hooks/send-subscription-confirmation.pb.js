/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  const userId = e.record.get("user_id");
  const user = $app.findRecordById("users", userId);
  
  const planType = e.record.get("plan_type");
  const startDate = e.record.get("start_date");
  const endDate = e.record.get("end_date") || "Not specified";
  
  let features = "";
  if (planType === "basique") {
    features = "<li>Basic pet profile</li><li>Collar ID tracking</li>";
  } else if (planType === "standard") {
    features = "<li>Standard pet profile</li><li>Collar ID tracking</li><li>Scan notifications</li><li>Up to 5 pets</li>";
  } else if (planType === "premium") {
    features = "<li>Premium pet profile</li><li>Collar ID tracking</li><li>Scan notifications</li><li>Unlimited pets</li><li>Priority support</li><li>Advanced analytics</li>";
  }
  
  const htmlContent = "<h2>Subscription Confirmation</h2>" +
    "<p>Thank you for subscribing to the <strong>" + planType + "</strong> plan!</p>" +
    "<p><strong>Plan Details:</strong></p>" +
    "<ul>" +
    "<li><strong>Plan:</strong> " + planType + "</li>" +
    "<li><strong>Start Date:</strong> " + startDate + "</li>" +
    "<li><strong>End Date:</strong> " + endDate + "</li>" +
    "</ul>" +
    "<p><strong>Features Included:</strong></p>" +
    "<ul>" + features + "</ul>" +
    "<p>If you have any questions, please contact our support team.</p>";
  
  const mailMessage = new MailerMessage({
    from: {
      address: $app.settings().meta.senderAddress,
      name: $app.settings().meta.senderName
    },
    to: [{ address: user.get("email") }],
    subject: "Subscription Confirmation - " + planType + " Plan",
    html: htmlContent
  });
  
  $app.newMailClient().send(mailMessage);
  e.next();
}, "subscriptions");