/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  const recipientEmail = e.record.get("recipient_email");
  const subject = e.record.get("subject");
  const message = e.record.get("message");

  try {
    const mailMessage = new MailerMessage({
      from: {
        address: $app.settings().meta.senderAddress,
        name: $app.settings().meta.senderName
      },
      to: [{ address: recipientEmail }],
      subject: subject,
      html: message
    });

    $app.newMailClient().send(mailMessage);

    // Update the record to mark it as sent
    e.record.set("sent", true);
    $app.save(e.record);
  } catch (error) {
    console.error("Failed to send email for record " + e.record.id + ": " + error.message);
  }

  e.next();
}, "email_queue");