/// <reference path="../pb_data/types.d.ts" />
onRecordCreate((e) => {
  // Log incoming data for debugging
  console.log("=== SCAN CREATION DEBUG ===");
  console.log("Record ID:", e.record.id);
  console.log("Pet ID:", e.record.get("pet_id"));
  console.log("Badge ID:", e.record.get("badge_id"));
  console.log("Latitude:", e.record.get("latitude"), "Type:", typeof e.record.get("latitude"));
  console.log("Longitude:", e.record.get("longitude"), "Type:", typeof e.record.get("longitude"));
  console.log("Device Type:", e.record.get("device_type"));
  console.log("Browser:", e.record.get("browser"));
  console.log("IP Address:", e.record.get("ip_address"));
  
  // Validate required fields
  const petId = e.record.get("pet_id");
  const badgeId = e.record.get("badge_id");
  
  if (!petId || petId === "") {
    throw new BadRequestError("pet_id is required");
  }
  
  if (!badgeId || badgeId === "") {
    throw new BadRequestError("badge_id is required");
  }
  
  // Validate latitude/longitude if provided
  const lat = e.record.get("latitude");
  const lng = e.record.get("longitude");
  
  if (lat !== null && lat !== undefined && lat !== "") {
    const latNum = parseFloat(lat);
    if (isNaN(latNum) || latNum < -90 || latNum > 90) {
      throw new BadRequestError("latitude must be a valid number between -90 and 90");
    }
  }
  
  if (lng !== null && lng !== undefined && lng !== "") {
    const lngNum = parseFloat(lng);
    if (isNaN(lngNum) || lngNum < -180 || lngNum > 180) {
      throw new BadRequestError("longitude must be a valid number between -180 and 180");
    }
  }
  
  console.log("=== VALIDATION PASSED ===");
  e.next();
}, "scans");