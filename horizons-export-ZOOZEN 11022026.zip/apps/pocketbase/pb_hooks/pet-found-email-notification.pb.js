/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  try {
    // Get the pet ID from the notification record
    const petId = e.record.get('petId');
    
    if (!petId) {
      throw new BadRequestError('Pet ID is missing from notification');
    }
    
    // Get the pet record
    const pet = $app.dao().findRecordById('pets', petId);
    
    if (!pet) {
      throw new BadRequestError('Pet record not found');
    }
    
    // Get the owner's email via expand
    const ownerEmail = pet.expand('owner_id').email;
    
    if (!ownerEmail) {
      throw new BadRequestError('Owner email not found');
    }
    
    // Get pet details
    const petName = pet.get('name');
    const latitude = e.record.get('latitude');
    const longitude = e.record.get('longitude');
    const address = e.record.get('address');
    
    // Build the HTML body
    let htmlBody = '<h2>Votre animal ' + petName + ' a été trouvé!</h2>';
    htmlBody += '<p>Bonne nouvelle! Votre animal a été localisé.</p>';
    htmlBody += '<h3>Détails de localisation:</h3>';
    htmlBody += '<ul>';
    htmlBody += '<li><strong>Nom de l\'animal:</strong> ' + petName + '</li>';
    if (latitude && longitude) {
      htmlBody += '<li><strong>Coordonnées GPS:</strong> ' + latitude + ', ' + longitude + '</li>';
    }
    if (address) {
      htmlBody += '<li><strong>Adresse:</strong> ' + address + '</li>';
    }
    htmlBody += '</ul>';
    htmlBody += '<p>Veuillez contacter le service de localisation pour plus de détails.</p>';
    
    // Create the email message
    const message = new MailerMessage({
      from: {
        address: $app.settings().meta.senderAddress,
        name: $app.settings().meta.senderName
      },
      to: [{ address: ownerEmail }],
      subject: 'Votre animal ' + petName + ' a été trouvé!',
      html: htmlBody
    });
    
    // Send the email
    $app.newMailClient().send(message);
    
    // Continue execution
    e.next();
  } catch (error) {
    throw new BadRequestError('Error sending pet found notification: ' + error.message);
  }
}, 'pet_found_notifications');