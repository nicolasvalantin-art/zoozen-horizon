/// <reference path="../pb_data/types.d.ts" />

// Hook to clean up badge when a pet is deleted
// Sets badge status back to 'available' and clears the pet_id relation

onRecordAfterDeleteSuccess((e) => {
  try {
    // Get the badge_id from the deleted pet record
    const badgeId = e.record.get("badge_id");
    
    // If the pet had a badge associated, clean it up
    if (badgeId) {
      // Find the badge record
      const badge = $app.findRecordById("badges", badgeId);
      
      if (badge) {
        // Reset badge to available and clear pet association
        badge.set("status", "available");
        badge.set("pet_id", null);
        
        // Save the updated badge
        $app.save(badge);
      }
    }
  } catch (error) {
    // Log error but don't block the deletion
    console.error("Error cleaning up badge after pet deletion:", error);
  }
  
  e.next();
}, "pets");