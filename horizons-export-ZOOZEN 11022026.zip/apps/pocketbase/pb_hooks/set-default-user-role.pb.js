/// <reference path="../pb_data/types.d.ts" />
onRecordCreate((e) => {
  // Only set role to 'user' if it's not already set
  if (!e.record.get("role")) {
    e.record.set("role", "user");
  }
  e.next();
}, "users");