/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  try {
    // Log the scan creation for debugging
    console.log("Scan created successfully");
    console.log("Scan ID: " + e.record.id);
    
    // Safely access latitude and longitude with null checks
    const latitude = e.record.get("latitude");
    const longitude = e.record.get("longitude");
    
    console.log("Latitude: " + latitude);
    console.log("Longitude: " + longitude);
    
    // Only process coordinates if both are present
    if (latitude !== null && latitude !== undefined && longitude !== null && longitude !== undefined) {
      console.log("Valid GPS coordinates detected: " + latitude + ", " + longitude);
      // Add any coordinate-based logic here
    } else {
      console.log("No GPS coordinates provided for this scan");
    }
    
    // Continue execution
    e.next();
  } catch (error) {
    console.log("Error in scan notification hook: " + error.message);
    console.log("Error stack: " + error.toString());
    // Continue execution even if there's an error
    e.next();
  }
}, "scans");