/// <reference path="../pb_data/types.d.ts" />
// This is a verification hook - it logs the current state of the badges collection
// and helps identify any issues with badge creation

onRecordCreateRequest((e) => {
  // Log the incoming request for debugging
  console.log("Badge creation request received");
  console.log("Auth user:", e.auth ? e.auth.id : "none");
  console.log("Auth role:", e.auth ? e.auth.get("role") : "none");
  console.log("Record data:", e.record);
  
  // Continue to next handler
  e.next();
}, "badges");