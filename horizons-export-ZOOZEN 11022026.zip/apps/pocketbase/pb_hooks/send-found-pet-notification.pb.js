/// <reference path="../pb_data/types.d.ts" />
onRecordAfterCreateSuccess((e) => {
  try {
    // Fetch the pet record
    const pet = $app.dao().findRecordById('pets', e.record.get('petId'));
    if (!pet) {
      throw new BadRequestError('Pet record not found');
    }

    // Fetch the owner record
    const owner = $app.dao().findRecordById('users', pet.get('owner_id'));
    if (!owner) {
      throw new BadRequestError('Owner record not found');
    }

    // Get GPS coordinates
    const latitude = e.record.get('latitude');
    const longitude = e.record.get('longitude');

    // Call reverse geocoding endpoint
    let locationAddress = 'Unknown location';
    try {
      const geoResponse = $http.send({
        url: 'http://localhost:3001/reverse-geocode?latitude=' + latitude + '&longitude=' + longitude,
        method: 'GET'
      });
      if (geoResponse.statusCode === 200) {
        const geoData = JSON.parse(geoResponse.raw);
        locationAddress = geoData.address || 'Unknown location';
      }
    } catch (geoError) {
      console.log('Reverse geocoding failed, using default address');
    }

    // Format timestamp
    const timestamp = e.record.get('created') || new Date().toISOString();

    // Format email body
    const emailBody = '<h2>Pet Found Alert</h2>' +
      '<p><strong>Pet Name:</strong> ' + pet.get('name') + '</p>' +
      '<p><strong>Pet Type:</strong> ' + pet.get('type') + '</p>' +
      '<p><strong>Owner Name:</strong> ' + owner.get('name') + '</p>' +
      '<p><strong>Owner Phone:</strong> ' + pet.get('phone_number') + '</p>' +
      '<p><strong>GPS Coordinates:</strong> ' + latitude + ', ' + longitude + '</p>' +
      '<p><strong>Location Address:</strong> ' + locationAddress + '</p>' +
      '<p><strong>Timestamp:</strong> ' + timestamp + '</p>' +
      '<p><strong>Notification Message:</strong> ' + e.record.get('notificationMessage') + '</p>';

    // Send email
    const message = new MailerMessage({
      from: {
        address: $app.settings().meta.senderAddress,
        name: 'ZooZen'
      },
      to: [{
        address: 'superadmin@zoozen.fr'
      }],
      subject: 'Pet Found: ' + pet.get('name'),
      html: emailBody
    });

    $app.newMailClient().send(message);

    // Update record status to 'sent'
    e.record.set('notificationStatus', 'sent');
    $app.dao().saveRecord(e.record);

    e.next();
  } catch (error) {
    // Set status to 'failed' on error
    e.record.set('notificationStatus', 'failed');
    try {
      $app.dao().saveRecord(e.record);
    } catch (saveError) {
      console.log('Failed to update record status to failed');
    }
    throw new BadRequestError('Failed to send pet found notification: ' + error.message);
  }
}, 'pet_found_notifications');