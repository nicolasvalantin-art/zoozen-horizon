/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pets");

  const existing = collection.fields.getByName("hide_vet_phone");
  if (existing) {
    if (existing.type === "bool") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("hide_vet_phone"); // exists with wrong type, remove first
  }

  collection.fields.add(new BoolField({
    name: "hide_vet_phone",
    required: false
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("pets");
    collection.fields.removeByName("hide_vet_phone");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})