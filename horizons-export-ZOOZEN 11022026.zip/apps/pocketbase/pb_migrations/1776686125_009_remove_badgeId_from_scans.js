/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("scans");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_scans_badgeId"));
  collection.fields.removeByName("badgeId");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("scans");
  collection.fields.add(new TextField({
    name: "badgeId",
    required: true
  }));
  collection.indexes.push("CREATE INDEX idx_scans_badgeId ON scans (badgeId)");
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})