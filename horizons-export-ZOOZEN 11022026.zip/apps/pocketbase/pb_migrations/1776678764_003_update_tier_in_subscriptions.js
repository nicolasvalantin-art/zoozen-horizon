/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("subscriptions");
  const field = collection.fields.getByName("tier");
  field.required = true;
  field.values = ["free", "premium"];
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("subscriptions");
  const field = collection.fields.getByName("tier");
  if (!field) { console.log("Field not found, skipping revert"); return; }
  field.required = false;
  field.values = ["free", "premium", "standard"];
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection or field not found, skipping revert");
      return;
    }
    throw e;
  }
})