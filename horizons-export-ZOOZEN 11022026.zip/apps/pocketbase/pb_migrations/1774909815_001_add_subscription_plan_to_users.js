/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("users");

  const existing = collection.fields.getByName("subscription_plan");
  if (existing) {
    if (existing.type === "select") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("subscription_plan"); // exists with wrong type, remove first
  }

  collection.fields.add(new SelectField({
    name: "subscription_plan",
    required: false,
    values: ["basique", "standard", "premium"]
  }));

  return app.save(collection);
}, (app) => {
  const collection = app.findCollectionByNameOrId("users");
  collection.fields.removeByName("subscription_plan");
  return app.save(collection);
})