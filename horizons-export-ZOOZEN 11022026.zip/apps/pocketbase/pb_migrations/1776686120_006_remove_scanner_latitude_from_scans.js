/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("scans");
  collection.fields.removeByName("scanner_latitude");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("scans");
  collection.fields.add(new NumberField({
    name: "scanner_latitude",
    required: false
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})