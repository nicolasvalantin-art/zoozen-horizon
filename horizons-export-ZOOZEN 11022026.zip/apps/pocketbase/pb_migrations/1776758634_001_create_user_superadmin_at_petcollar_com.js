/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("users");
  const record = new Record(collection);
  record.set("email", "superadmin@petcollar.com");
  record.setPassword("SuperAdmin@2026!");
  record.set("name", "Super Administrator");
  record.set("role", "admin");
  record.set("subscription_plan", "premium");
  record.set("subscription_status", "active");
  record.set("subscription_tier", "premium");
  record.set("subscription_start_date", "2026-04-21");
  record.set("subscription_end_date", "2027-04-21");
  try {
    return app.save(record);
  } catch (e) {
    if (e.message.includes("Value must be unique")) {
      console.log("Record with unique value already exists, skipping");
      return;
    }
    throw e;
  }
}, (app) => {
  try {
    const record = app.findFirstRecordByData("users", "email", "superadmin@petcollar.com");
    app.delete(record);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Auth record not found, skipping rollback");
      return;
    }
    throw e;
  }
})