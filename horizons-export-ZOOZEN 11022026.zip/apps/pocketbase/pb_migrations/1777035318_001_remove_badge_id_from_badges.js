/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("badges");
  collection.indexes = collection.indexes.filter(idx => !idx.includes("idx_badges_badge_id"));
  collection.fields.removeByName("badge_id");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("badges");
  collection.fields.add(new TextField({
    name: "badge_id",
    required: true
  }));
  collection.indexes.push("CREATE UNIQUE INDEX idx_badges_badge_id ON badges (badge_id)");
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})