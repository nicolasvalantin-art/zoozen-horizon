/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("badges");
  collection.fields.removeByName("user_id");
  return app.save(collection);
}, (app) => {
  try {

  const _pb_users_auth_Collection = app.findCollectionByNameOrId("_pb_users_auth_");
  const collection = app.findCollectionByNameOrId("badges");
  collection.fields.add(new RelationField({
    name: "user_id",
    required: true,
    collectionId: _pb_users_auth_Collection.id
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})