/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const badgesCollection = app.findCollectionByNameOrId("badges");
  const collection = app.findCollectionByNameOrId("scans");

  const existing = collection.fields.getByName("badge_id");
  if (existing) {
    if (existing.type === "relation") {
      return; // field already exists with correct type, skip
    }
    collection.fields.removeByName("badge_id"); // exists with wrong type, remove first
  }

  collection.fields.add(new RelationField({
    name: "badge_id",
    required: true,
    collectionId: badgesCollection.id,
    maxSelect: 1
  }));

  return app.save(collection);
}, (app) => {
  try {
    const collection = app.findCollectionByNameOrId("scans");
    collection.fields.removeByName("badge_id");
    return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})