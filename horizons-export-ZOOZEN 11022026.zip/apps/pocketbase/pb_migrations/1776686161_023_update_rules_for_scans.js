/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("scans");
  collection.listRule = "badge_id.user_id = @request.auth.id";
  collection.viewRule = "badge_id.user_id = @request.auth.id";
  collection.createRule = "";
  collection.updateRule = "badge_id.user_id = @request.auth.id";
  collection.deleteRule = "badge_id.user_id = @request.auth.id";
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("scans");
  collection.createRule = "";
  collection.listRule = "pet_id.owner_id = @request.auth.id";
  collection.viewRule = "pet_id.owner_id = @request.auth.id";
  collection.updateRule = "pet_id.owner_id = @request.auth.id";
  collection.deleteRule = "pet_id.owner_id = @request.auth.id";
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})