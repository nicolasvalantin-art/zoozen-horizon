/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("scans");
  collection.listRule = "pet_id.owner_id = @request.auth.id";
  collection.viewRule = "pet_id.owner_id = @request.auth.id";
  collection.createRule = "";
  collection.updateRule = "pet_id.owner_id = @request.auth.id";
  collection.deleteRule = "pet_id.owner_id = @request.auth.id";
  return app.save(collection);
}, (app) => {
  try {
  const collection = app.findCollectionByNameOrId("scans");
  collection.listRule = "pet_id.owner_id = @request.auth.id";
  collection.viewRule = "pet_id.owner_id = @request.auth.id";
  collection.createRule = "@request.auth.id != '' || @request.auth.id = ''";
  collection.updateRule = "pet_id.owner_id = @request.auth.id";
  collection.deleteRule = "pet_id.owner_id = @request.auth.id";
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})