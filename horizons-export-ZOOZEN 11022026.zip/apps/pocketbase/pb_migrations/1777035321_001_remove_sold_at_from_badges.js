/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("badges");
  collection.fields.removeByName("sold_at");
  return app.save(collection);
}, (app) => {
  try {

  const collection = app.findCollectionByNameOrId("badges");
  collection.fields.add(new DateField({
    name: "sold_at",
    required: false
  }));
  return app.save(collection);
  } catch (e) {
    if (e.message.includes("no rows in result set")) {
      console.log("Collection not found, skipping revert");
      return;
    }
    throw e;
  }
})